import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { DesignTargetStatus, Prisma, UserRole } from '@prisma/client';

import { localMidnightOf, nextLocalMidnight } from '../agent/util/dhaka-time';
import { AuditService } from '../audit/audit.service';
import type { SessionUser } from '../auth/types';
import { PrismaService } from '../prisma/prisma.service';
import { targetHistoryContext, targetWrite } from './target-history.context';
import {
  dailyCompletionCap,
  designTargetOf,
  hasDesignTarget,
} from '../summary/design.rules';
import { FileTraceService } from './file-trace.service';
import {
  allocationSizes,
  amazonUrl,
  canUseTargets,
  DESIGN_WORK_STAFF_TYPES,
  type DropReason,
  fileSecOf,
  parseBulk,
  POOL_PER_DESIGNER,
  MAX_ISSUED_PER_DAY,
  topUpSize,
  UPLOAD_QUEUE_FROM,
  type RejectedLine,
} from './targets.rules';

/**
 * ⭐⭐ 'YYYY-MM-DD' → ওই দিনের **ঢাকার মধ্যরাত**।
 *
 * ⚠️ মডিউল-স্তরে রাখা হয়েছে ইচ্ছাকৃতভাবে: `list()`-এর ছাঁকনি আর
 * `stats()`-এর গণনা — দুটোকে **হুবহু এক তারিখ** ধরতে হয়। চিপে ১৩২ লিখে
 * ক্লিক করার পর ৯০টা এলে কেউ আর কোনো সংখ্যাই বিশ্বাস করবে না, আর এই
 * প্রকল্পে ঠিক এভাবেই একই সূত্র দুই জায়গায় লেখা হয়ে বাগ জন্মেছে।
 */
const dhakaStart = (day: string): Date => new Date(`${day}T00:00:00+06:00`);
const nextDay = (day: string): Date =>
  new Date(dhakaStart(day).getTime() + 86_400_000);

/**
 * ⭐ দুটো `'YYYY-MM-DD'`-র মধ্যে পরেরটা।
 *
 * ⚠️ লেখার তুলনাই যথেষ্ট — ISO তারিখে অক্ষরের ক্রম আর সময়ের ক্রম এক।
 */
const laterDay = (a: string, b: string): string => (a >= b ? a : b);

/**
 * ⭐ ওই মুহূর্তটা **ঢাকার কোন দিনে** পড়ে — `'YYYY-MM-DD'`।
 *
 * ⚠️ `toISOString().slice(0,10)` লিখলে UTC-র দিন আসত, আর ঢাকায় ভোর ৬টার
 * আগে সেটা **গতকাল** দেখাত। রাত ১১টায় Complete চেপে ভুল ধরলে Undo-টা
 * তখন "গতকালের কাজ" বলে আটকে যেত।
 */
const workDateStr = (at: Date): string =>
  new Date(at.getTime() + 6 * 3_600_000).toISOString().slice(0, 10);

/**
 * ⚠️⚠️ পর্দায় সর্বোচ্চ কতগুলো বাদ-পড়া লাইন দেখানো হবে *(২৩ আগস্ট ২০২৬)*।
 *
 * ছাদ তোলার পর ৪৫,০০০ লাইন পেস্ট করা সম্ভব। কেউ ভুল ফাইল পেস্ট করলে
 * **সবগুলোই** বাদ পড়ত, আর তখন গোটা তালিকা ব্রাউজারে পাঠালে উত্তরটা কয়েক
 * MB হতো আর পর্দায় ৪৫,০০০ সারির টেবিল বসত — ব্রাউজার জমে যেত।
 *
 * ⭐ সংখ্যাটা (`rejectedTotal`) **সত্যি থাকে**, কেবল তালিকাটা ছাঁটা হয়।
 * ২০০টা দেখলেই ভুলের ধরনটা বোঝা যায়; ২০১তম সারি নতুন কিছু বলে না।
 */
export const REJECTED_SHOWN = 200;

export interface BulkResult {
  /** নতুন করে যতগুলো ঢুকল */
  added: number;
  /** ⚠️ আগে থেকেই ছিল — ভুল নয়, কিন্তু জানা দরকার */
  alreadyKnown: number;
  /** ⚠️ সর্বোচ্চ `REJECTED_SHOWN`টা — আসল সংখ্যা `rejectedTotal`-এ */
  rejected: RejectedLine[];
  /** ⭐ কতগুলো সত্যিই বাদ পড়েছে — তালিকা ছাঁটা হলেও এটা পুরো সংখ্যা */
  rejectedTotal: number;
  /** পুলে এখন কতগুলো অপেক্ষায় */
  poolSize: number;
}

/**
 * ⚠️ এক পাতায় ৫০টা — বেশি দিলে ৩৯ হাজারের টেবিলে স্ক্রল করাই কষ্ট হতো,
 * কম দিলে গবেষককে বারবার "পরের পাতা" চাপতে হতো।
 */
export const TARGET_PAGE_SIZE = 50;
export const DAILY_AUTOMATIC_SKIPS = 3;

/**
 * ⚠️ এক ডাকে সর্বোচ্চ কতগুলো মোছা যাবে। পর্দায় এক পাতায় ৫০টা, তাই
 * বাস্তবে কেউ এর কাছেও পৌঁছাবেন না — ছাদটা মানুষকে নয়, দুর্ঘটনা ও
 * বেঢপ কোয়েরি আটকাতে (`BulkDto`-র ছাদের একই যুক্তি)।
 */
export const DELETE_MAX = 500;

export interface DeleteResult {
  /** কতগুলো সত্যিই `deleted` হলো */
  deleted: number;
  /**
   * ⚠️⚠️ **শেষ হয়ে যাওয়া বলে যেগুলো ছোঁয়া হয়নি।** সংখ্যাটা ফেরত যায়
   * বলেই পর্দা সত্যি কথাটা বলতে পারে — নইলে ৫০টা বেছে ৪৮টা মুছত আর
   * কেউ জানত না বাকি দুটোর কী হলো।
   */
  keptDone: number;
}

/**
 * ⭐⭐ **Design Pool-এ খোঁজার শর্ত** *(৬ সেপ্টেম্বর ২০২৬)* — ASIN, নাকি
 * Job নম্বর, নাকি দুটোই।
 *
 * ⚠️ শুধু-অঙ্ক লেখা হলে `OR` — কিছু ASIN পুরোপুরি সংখ্যায় হয়, আর তখন
 *    কেবল Job নম্বর খুঁজলে ওই সারিটা নীরবে হারিয়ে যেত।
 */
type TargetSearchMatch =
  | { asin: { contains: string } }
  | { OR: [{ jobNumber: number }, { asin: { contains: string } }] };

export interface TargetRow {
  skipReviewPending: boolean;
  skipRequestedAt: string | null;
  id: number;
  asin: string;
  url: string;
  status: DesignTargetStatus;
  jobNumber: number | null;
  /** ⚠️ ছেড়ে যাওয়া কর্মীর সারিতে `null` — নামটা `sourceNote`-এ */
  assignedTo: { empCode: string; fullName: string } | null;
  assignedAt: string | null;
  /** ⭐ ফাইলটা প্রথমবার খোলা হয়েছে — "কাজ চলছে" */
  startedAt: string | null;
  completedAt: string | null;
  completedVia: string | null;

  /**
   * ⭐⭐ **ওই জব-নম্বরের ফাইল ডিজাইন-অ্যাপে মোট কত সেকেন্ড পর্দায় ছিল**
   * *(৯ সেপ্টেম্বর ২০২৬)*।
   *
   * ⚠️⚠️ **তিনটে অবস্থা** — `> 0` মাপা হয়েছে · `0` **শেষ বলা হয়েছে
   * অথচ কখনো খোলা হয়নি** · `null` বলার মতো কিছু নেই। মাঝেরটা কেবল
   * শেষ-বলা সারিতেই বসে: হাতে থাকা কাজের ফাইল এখনো খোলা না হওয়া
   * স্বাভাবিক, আর সেখানে `no trace` লেখা মানে **অভিযোগ সেখানে যেখানে
   * কোনো দাবিই করা হয়নি**। নিয়মটা [`fileSecOf`](./targets.rules.ts)-এ।
   *
   * ⚠️ এটা "কাজ হয়েছে কি না" নয় — সেভ না করা বা নাম বদলানো ফাইল
   * এখানে ধরা পড়ে না। সংখ্যাটা **প্রসঙ্গ, রায় নয়**।
   */
  fileSec: number | null;
  /** পুরোনো Excel-এর কাঁচা লেখা — "Hafiz-24-05-2026" */
  sourceNote: string | null;

  /**
   * ⭐⭐ **কেন সারিটা কাজের বাইরে গেল** *(৩১ আগস্ট ২০২৬)* — `not_found` ·
   * `copyright` · `events`।
   *
   * ⚠️ `skipped` ও `deleted` **দুটোতেই** থাকে; বাকি অবস্থায় `null`।
   * পর্দায় লেখাটা `DROP_REASON_LABELS` থেকে আসে, এই মান থেকে নয় —
   * তাই লেখাটা বদলালেও জমা ডেটা অক্ষত থাকে।
   */
  dropReason: string | null;

  /**
   * ⭐⭐ **মালিক/ম্যানেজার এটা দেখে নিয়েছেন** *(৩১ আগস্ট ২০২৬)* — `null`
   * মানে এখনো কিউতে আছে।
   *
   * ⚠️ কেবল বাদ-যাওয়া সারিতেই অর্থবহ; বাকি সব সারিতে চিরকাল `null`।
   */
  reviewedAt: string | null;
  reviewedBy: { fullName: string; role: string } | null;

  /**
   * ⚠️⚠️ নিচের ঘরগুলো `list()` **আগে থেকেই ফেরত দিত**, কিন্তু এই টাইপে
   * লেখা ছিল না — অর্থাৎ চুক্তিটা বাস্তবের চেয়ে ছোট ছিল, আর TypeScript
   * সেটা ধরত না (`.map()`-এর ফল কাঠামোগতভাবে assignable)। ⭐ ২৫ আগস্ট
   * বানান-যাচাইয়ের ঘর যোগ করতে গিয়ে ধরা পড়ল; একসাথে সবগুলো লেখা হলো।
   */
  completedBy: { fullName: string; role: string } | null;

  /**
   * ⭐⭐ **কে টার্গেটটা এনেছেন** *(মালিকের চাওয়া, ২৫ আগস্ট ২০২৬:
   * "Design Pool e ke target list add koreche seta ami dekhote cai")*।
   *
   * ⚠️ `assignedTo`-র সাথে গুলিয়ে ফেলবেন না — ওটা **কর্মী** (যিনি ডিজাইন
   * করবেন), এটা **ব্যবহারকারী** (যিনি লিঙ্কটা এনেছেন)। দুটো আলাদা id-র
   * জগৎ: `assigned_to_id → employees`, `added_by_id → users`।
   *
   * ⚠️ `null` হয় না — কলামটা `NOT NULL`, প্রতিটা সারির একজন উৎস আছে।
   * তবু টাইপে `| null` রাখা হয়েছে **নয়**, কারণ মিথ্যা ঐচ্ছিকতা পর্দায়
   * অকারণ `?? '—'` ডেকে আনত।
   */
  addedBy: { fullName: string; role: string };
  /** ⭐ কবে এসেছে — একই ব্যাচের সারিগুলো এক মুহূর্তে বসে */
  addedAt: string;
  /** ⭐ বানান দেখা হয়েছে — `null` = এখনো দেখা হয়নি (ADR-038) */
  checkedAt: string | null;
  /** ⭐ ভুল পাওয়া গেছে — `null` **আর** `checkedAt` বসানো = ঠিক ছিল */
  errorFoundAt: string | null;
  /** ⭐ ভুলটা ঠিক করা হয়েছে */
  fixedAt: string | null;
  uploadedAt: string | null;
  liveAt: string | null;
  liveAsin: string | null;
}

export interface MyTarget {
  skipReviewPending: boolean;
  skipRequestedAt: string | null;
  id: number;
  asin: string;
  url: string;
  jobNumber: number | null;
  assignedAt: string | null;
  /** ⭐ ফাইলটা খোলা হয়েছে — পর্দায় "কাজ চলছে" */
  startedAt: string | null;
  /**
   * ⭐⭐ **আজ শেষ করা হয়েছে** *(মালিকের রিপোর্ট, ২৫ আগস্ট)*।
   *
   * ⚠️⚠️ `null` = এখনো হাতে আছে। এই ঘরটাই ঠিক করে সারিটা পর্দার কোন
   * ভাগে বসবে আর Undo বোতামটা ওঠে কি না।
   *
   * ⚠️ **আজকের** বাইরের কিছু এখানে আসেই না (`mine()` দেখুন), তাই
   * মান থাকা মানেই "আজ শেষ করা, এখনো ফেরানো যায়"।
   */
  completedAt: string | null;
}

/**
 * **ডিজাইন-টার্গেট** *(২২ আগস্ট ২০২৬)* — জমা, বণ্টন, আর শেষ হওয়া।
 *
 * ⭐ গবেষকেরা রোজ ~৫০০টা Amazon URL জমা করেন; সকালে র‍্যান্ডম বণ্টন হয়;
 * ডিজাইনার একটা করে নিয়ে কাজ করেন।
 */
@Injectable()
export class TargetsService {
  private readonly logger = new Logger(TargetsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
    private readonly trace: FileTraceService,
  ) {}

  /**
   * ⭐⭐ **কে টার্গেট দেখতে ও জমা দিতে পারবেন** — মালিক · ম্যানেজার ·
   * **গবেষক** *(২৩ আগস্ট; রোল-ভিত্তিক হলো ২৫ আগস্ট)*।
   *
   * ⚠️ পড়া ও লেখার পাহারা **একটাই**, আর সেটা ইচ্ছাকৃত: পুরো তালিকায়
   * দেখা যায় গোটা দলের কাজ কোথায় দাঁড়িয়ে — সেটা ডিজাইনারের দেখার
   * জিনিস নয়। ⭐ তিনি নিজের ৩০টা দেখেন `/me/targets`-এ।
   *
   * ### ⚠️⚠️ এখানে আগে যা লেখা ছিল, আর কেন সেটা আর সত্যি নয়
   *
   * পুরোনো টীকা বলত: *"গবেষককে `@Roles()` দিয়ে আটকানো যায় না — পোর্টালের
   * রোল তিনটে (owner · manager · employee), আর গবেষক ঢোকেন `employee`
   * হিসেবে"*। তাই অনুমতিটা **অন্য টেবিলের** `staff_type` ধরে নিতে হতো,
   * প্রতি রিকোয়েস্টে একটা করে ডাটাবেস কল খরচ করে।
   *
   * ⭐⭐ ২৫ আগস্ট মালিক ওই ভিতটাই সরিয়ে দিলেন — *"researcher and designer
   * same kaj kore na, tai eder access o same hobe na"*। `UserRole`-এ এখন
   * `researcher` আছে, তাই প্রশ্নটা আর দুই টেবিলে ভাগ নয়।
   *
   * ফল তিনটে, আর তিনটেই লাভ:
   *   · ডাটাবেস কল **উধাও** — ফাংশনটা এখন সমার্থক (sync)
   *   · সাইডবারের `roles: [...] + when: canAddTargets` হ্যাকটা **মুছে গেল**
   *   · অনুমতি **এক জায়গায়** — আর দুই টেবিলে ভাগ থাকাটাই ২৪ আগস্টের
   *     গণ্ডগোলটা সম্ভব করেছিল (ADR-038)
   *
   * ⚠️ পুরোনো টীকার আরেকটা আশঙ্কা ছিল — *"টোকেনে ধরনটা বসালে মালিক ধরন
   * বদলানোর পরেও পুরোনো টোকেন পুরোনো অনুমতি নিয়ে ঘুরত"*। সেটাও আর খাটে
   * না: `JwtAuthGuard` প্রতি ৫ মিনিটে ভূমিকাটা **ডাটাবেস থেকে নতুন করে
   * পড়ে** (সেখানকার টীকা দেখুন)। রোল বদলালে কাউকে লগআউট করতে হয় না।
   */
  assertCanUse(actor: SessionUser): void {
    if (canUseTargets(actor.role)) return;

    throw new ForbiddenException(
      'Only researchers, managers and the owner can add design targets.',
    );
  }

  /**
   * ⭐⭐ **কে বানান যাচাই করতে পারেন** — মালিক · ম্যানেজার · গবেষক।
   *
   * ### ⚠️⚠️ এই ফাংশনটা এক দিনে দুবার বদলেছে, আর ইতিহাসটা কাজে লাগে
   *
   * **২৫ আগস্ট, সকাল** — মালিক: *"ami chai ei access ami manager and
   * sumaiya pak"*। তখন এটা ছিল `employees.can_proofread` টিক-ঘর ধরে,
   * অর্থাৎ **ব্যক্তি ধরে**।
   *
   * **২৫ আগস্ট, পরে** — মালিক: *"sob researcher ra sei access gula pabe...
   * researcher and designer same kaj kore na, tai eder access o same hobe
   * na"*। অর্থাৎ প্রশ্নটা কখনোই *"কোন মানুষ"* ছিল না, ছিল *"কোন কাজ"*।
   * ⭐ তাই টিক-ঘরটা তুলে দেওয়া হয়েছে আর রোলই অধিকারটা বহন করে।
   *
   * ⚠️⚠️ **সূত্রটা আজ `assertCanUse`-এর হুবহু সমান, তবু ফাংশন দুটো আলাদা**
   * — আর এটা ইচ্ছাকৃত, এই কোডবেসের নিয়ম মেনেই (`App.tsx`-এ
   * `mayOpenSettings` কেন `isOwner || isManager` নয়, সেই একই কারণ)।
   * শর্তের **নাম** থাকলে ভবিষ্যতে একটা বদলাতে গিয়ে অন্যটা খুঁজে বেড়াতে
   * হয় না। মিলে যাওয়া সমান হওয়া নয়।
   */
  assertCanProofread(actor: SessionUser): void {
    if (canUseTargets(actor.role)) return;

    throw new ForbiddenException(
      'Only researchers, managers and the owner can check spelling.',
    );
  }

  /**
   * ⭐⭐ **একবারে ৫০০টা URL।**
   *
   * ⚠️⚠️ **ডুপ্লিকেট দুই স্তরে ছাঁকা হয়:** পেস্টের ভেতরে (`parseBulk`) আর
   * ডাটাবেসের বিপরীতে (`skipDuplicates`)। দ্বিতীয়টা ছাড়া `createMany`
   * পুরো ব্যাচটাই বাতিল করত — অর্থাৎ ৫০০টার মধ্যে একটা পুরোনো ASIN
   * থাকলেই গবেষকের গোটা দিনের কাজ জমা হতো না।
   *
   * ⚠️ কতগুলো **সত্যিই** ঢুকল সেটা `createMany`-র `count` থেকে নেওয়া হয়,
   * অনুমান করে নয় — "৫০০টা জমা হয়েছে" বলে ৪৩৭টা ঢোকাটা নীরব মিথ্যা।
   */
  async bulkAdd(actor: SessionUser, text: string, ip: string): Promise<BulkResult> {
    await this.assertCanUse(actor);

    const { accepted, rejected } = parseBulk(text);

    /**
     * ⭐⭐ **কাজের নম্বর বসে জমা দেওয়ার মুহূর্তেই** *(২৩ আগস্ট, মালিকের
     * চাওয়া: "every target er job no thakobe")*।
     *
     * ⚠️ আগে নম্বরটা বসত **বরাদ্দের সময়**, যাতে কখনো বরাদ্দ না হওয়া
     * সারি সিরিয়াল না খায়। কিন্তু তাতে পুলে পড়ে থাকা সারির কোনো পরিচয়
     * থাকত না — মালিক তালিকায় একটা সারি দেখিয়ে বলতে পারতেন না "এই
     * নম্বরটা"। ⭐ সিরিয়াল ৪ বাইটের int, তাই ৩৯ হাজার নয়, ২০০ কোটি
     * পর্যন্ত চলে; খরচটা কল্পিত ছিল।
     *
     * ⚠️ `createMany` দিয়ে `nextval` ডাকা যায় না, তাই raw insert —
     * কিন্তু `ON CONFLICT DO NOTHING` রাখা হয়েছে, নইলে ৫০০টার মধ্যে
     * একটা পুরোনো ASIN থাকলেই গোটা ব্যাচ বাতিল হতো।
     */
    const created =
      accepted.length === 0
        ? { count: 0 }
        : {
            count: await this.prisma.$executeRaw`
              INSERT INTO design_targets (asin, added_by_id, job_number)
              SELECT a, ${actor.userId}, nextval('design_job_number_seq')
              FROM unnest(${accepted.map((t) => t.asin)}::text[]) AS a
              ON CONFLICT (asin) DO NOTHING
            `,
          };

    const poolSize = await this.prisma.designTarget.count({
      where: { status: DesignTargetStatus.pool },
    });

    await this.audit.record({
      userId: actor.userId,
      action: 'change_setting',
      targetType: 'design_targets',
      targetId: 'bulk',
      ipAddress: ip,
      // ⚠️ ASIN-গুলো audit-এ যায় না — পাঁচশো আইডি লগে বসিয়ে লাভ নেই,
      //    আর তালিকাটা টেবিলেই আছে
      meta: {
        added: created.count,
        rejected: rejected.length,
        pasted: accepted.length + rejected.length,
      },
    });

    return {
      added: created.count,
      alreadyKnown: accepted.length - created.count,
      // ⚠️ ছাঁটাটা এখানে, `parseBulk()`-এ নয় — ওই ফাংশনের কাজ সত্যি বলা,
      //    পর্দার সুবিধা দেখা নয়। ছাদটা সীমান্তে বসে (audit-এও পুরো সংখ্যাই যায়)।
      rejected: rejected.slice(0, REJECTED_SHOWN),
      rejectedTotal: rejected.length,
      poolSize,
    };
  }

  /**
   * ⭐⭐ **রোজকার বণ্টন — র‍্যান্ডম, কিন্তু ন্যায্য।**
   *
   * ⚠️⚠️ **বাছাই র‍্যান্ডম হয় ডাটাবেসেই** (`ORDER BY random()`), মেমরিতে
   * নয়। গোটা পুল (হাজার হাজার সারি) টেনে এনে জাভাস্ক্রিপ্টে মেশানো
   * যেত, কিন্তু পুল বড় হলে সেটা রোজ সকালে একটা অকারণ বোঝা হতো।
   *
   * ⚠️⚠️ **এক লেনদেনে দাবি করা হয়** — `status = 'pool'` শর্তসহ update।
   * দুটো রান একসাথে চললে (মালিক বোতাম চাপলেন আর জবও চলল) দুজনের হাতে
   * একই টার্গেট পড়ে যেত। শর্তটাই আসল পাহারা।
   *
   * ⚠️ কখনো throw করে না — বণ্টন ব্যর্থ হলে কাল আবার চেষ্টা হবে; এর
   * জন্য সার্ভার নামা চলবে না।
   */
  async distribute(now: Date = new Date(), userId: number | null = null): Promise<{ assigned: number }> {
    let assigned = 0;

    try {
      const designers = await this.prisma.employee.findMany({
        // ⭐ কারা পান সেটা এক জায়গায় লেখা — `DESIGN_WORK_STAFF_TYPES`-এর
        //    টীকায় কারণসহ (২৬ আগস্ট: ম্যানেজারও ডিজাইন করেন)
        where: {
          status: 'active',
          staffType: { in: [...DESIGN_WORK_STAFF_TYPES] },
        },
        select: { id: true, empCode: true },
        // ⚠️ কর্মী-কোড ধরে — পুলে ঘাটতি থাকলে কে আগে পাবে সেটা **অনুমেয়**
        //    থাকা দরকার; র‍্যান্ডম হলে রোজ আলাদা লোক বঞ্চিত হতেন আর কেউ
        //    কারণ বলতে পারত না। (বাছাই র‍্যান্ডম, ক্রম নয়।)
        orderBy: { empCode: 'asc' },
      });
      if (designers.length === 0) return { assigned: 0 };

      const open = await this.prisma.designTarget.groupBy({
        by: ['assignedToId'],
        where: {
          status: DesignTargetStatus.assigned,
          assignedToId: { in: designers.map((d) => d.id) },
        },
        _count: { _all: true },
      });
      const openBy = new Map(open.map((o) => [o.assignedToId, o._count._all]));

      const poolSize = await this.prisma.designTarget.count({
        where: { status: DesignTargetStatus.pool },
      });

      const sizes = allocationSizes(
        designers.map((d) => ({
          employeeId: d.id,
          openCount: openBy.get(d.id) ?? 0,
        })),
        poolSize,
      );

      for (const [employeeId, size] of sizes) {
        assigned += await this.claimFor(employeeId, size, now, userId, 'distribution');
      }

      if (assigned > 0) {
        this.logger.log(
          `Design targets distributed · ${assigned} to ${sizes.size} designers`,
        );
      }
    } catch (err) {
      this.logger.error(
        `Could not distribute design targets: ${
          err instanceof Error ? err.message : String(err)
        }`,
      );
    }

    return { assigned };
  }

  /**
   * একজনের জন্য `size`টা টার্গেট পুল থেকে দাবি করা।
   *
   * ⚠️⚠️ `WHERE status = 'pool'` শর্তটা update-এর ভেতরেই — দুটো রান
   * একসাথে চললেও একই সারি দুজনের হাতে পড়তে পারে না।
   *
   * ⭐ কাজের নম্বর বসে **এখানেই**, বরাদ্দের মুহূর্তে — পুলে পড়ে থাকা
   * টার্গেটের নম্বর থাকে না। নইলে কখনো বরাদ্দ না হওয়া হাজারখানেক
   * টার্গেট সিরিয়াল খেয়ে ফেলত।
   */
  private async claimFor(
    employeeId: number,
    size: number,
    now: Date,
    userId: number | null = null,
    source = 'top_up',
  ): Promise<number> {
    return targetWrite(this.prisma, userId, source, async tx => {
      // Recheck capacity after waiting: concurrent skips/top-ups must not grant
      // the same vacant slots twice. Pending skips are still assigned here.
      await tx.$queryRaw`SELECT pg_advisory_xact_lock(260927, ${employeeId}::int)::text`;
      const open = await tx.designTarget.count({ where: { assignedToId: employeeId, status: 'assigned' } });
      let available = Math.min(size, Math.max(0, POOL_PER_DESIGNER - open));
      if (source === 'top_up') {
        const issued = await tx.designTarget.count({ where: {
          assignedToId: employeeId, assignedAt: { gte: localMidnightOf(now), lt: nextLocalMidnight(now) },
        } });
        available = Math.min(available, Math.max(0, MAX_ISSUED_PER_DAY - issued));
      }
      if (available === 0) return 0;
      return tx.$executeRaw`
        WITH picked AS (
          SELECT id FROM design_targets WHERE status = 'pool'
          ORDER BY random() LIMIT ${available} FOR UPDATE SKIP LOCKED
        )
        UPDATE design_targets
        SET status = 'assigned',
            assigned_to_id = ${employeeId},
            assigned_at = ${now},
            -- ⚠️⚠️ COALESCE — পুল থেকে **ফিরে আসা** টার্গেটের নম্বর
            --    ইতিমধ্যেই আছে, আর নম্বরটা ASIN-এর, বরাদ্দের নয়।
            --    আবার বসালে সিরিয়াল অকারণে ফুরাত, আর পুরোনো ফাইলের
            --    নাম কোনোদিন কিছুর সাথে মিলত না।
            job_number = COALESCE(job_number, nextval('design_job_number_seq'))
        WHERE id IN (SELECT id FROM picked) AND status = 'pool'
      `;
    }, { maxWait: 30_000, timeout: 30_000 });
  }

  /**
   * ⭐⭐ **দিন শেষে না-করা টার্গেট পুলে ফেরত** *(মালিকের নিয়ম, ২২ আগস্ট:
   * "din sheshe baki design gula amar main list e back asbe")*।
   *
   * কাউকে ৩০টা দেওয়া হলো, তিনি ১৫টা করলেন — বাকি ১৫টা পুলে ফিরে যায়,
   * আর ভবিষ্যতে আবার বিলি হয়। ⭐ এতে কোনো টার্গেট কারো হাতে **আটকে
   * থাকে না**; পুল সবসময় সত্যিকারের বাকি কাজটাই দেখায়।
   *
   * ⚠️⚠️ **যেটা আজ ছোঁয়া হয়েছে সেটা ফেরত যায় না — আর এটাই এখানকার
   * সবচেয়ে জরুরি শর্ত।** কেউ একটা ডিজাইন খুলে কাজ শুরু করেছেন কিন্তু
   * আজ শেষ করতে পারেননি — সরল নিয়মে ওটাও ফিরে যেত, আর কাল অন্য কারো
   * হাতে পড়ত। দুজনের শ্রম নষ্ট, আর কেউ বুঝতই না কেন।
   * ⭐ "ছোঁয়া" মানে ফাইলটা খোলা হয়েছে, অর্থাৎ নম্বরটা আজকের
   * `design_credits`-এ আছে — একই সংকেত যা দিয়ে "শেষ হয়েছে" ধরা হয়।
   *
   * ⚠️ **কাজের নম্বর মুছে ফেলা হয় না।** নম্বরটা ASIN-এর, বরাদ্দের নয় —
   * একবার বসলে চিরকাল ওটাই। মুছে দিলে (ক) সিরিয়াল অকারণে ফুরাত,
   * (খ) পুরোনো ফাইলের নাম কোনোদিন কিছুর সাথে মিলত না।
   *
   * ⚠️ কখনো throw করে না।
   */
  async returnUnworked(workDate: Date): Promise<{ returned: number }> {
    try {
      /**
       * ⚠️ আজ যে নম্বরগুলো কারো ফাইলে দেখা গেছে — কর্মী ধরে।
       * ⭐ `design_credits.design_id` টেক্সট, আর `job_number` সংখ্যা;
       * মেলানোটা তাই টেক্সটেই করা হয় (নম্বরের রূপ এক, `1000042`)।
       */
      const touched = await this.prisma.designCredit.findMany({
        where: { firstWorkDate: workDate },
        select: { employeeId: true, designId: true },
      });

      const keep = new Set(touched.map((t) => `${t.employeeId}:${t.designId}`));

      const open = await this.prisma.designTarget.findMany({
        where: { status: DesignTargetStatus.assigned, skipReviewPending: false },
        select: { id: true, assignedToId: true, jobNumber: true, startedAt: true },
      });

      const ids = open
        // ⚠️⚠️ **শুরু হওয়া টার্গেট ফেরত যায় না** — `startedAt` বসা মানে
        //    ফাইলটা কোনো একদিন খোলা হয়েছে, অর্থাৎ কাজ চলছে। আজকের
        //    ক্রেডিট দেখাটা তার চেয়ে সংকীর্ণ ছিল: তিন দিন ধরে চলা কাজ
        //    যেদিন কেউ ফাইলটা খোলেনি, সেদিনই ফেরত চলে যেত।
        .filter((t) => t.startedAt === null)
        .filter((t) => !keep.has(`${t.assignedToId}:${t.jobNumber}`))
        .map((t) => t.id);
      if (ids.length === 0) return { returned: 0 };

      // Recheck start and credit eligibility at the write, including credits
      // committed since the initial selection. A concurrent start on this row
      // makes PostgreSQL re-evaluate started_at after waiting for its lock.
      const count = await targetWrite(this.prisma, null, 'end_of_day', tx => tx.$executeRaw`
        UPDATE design_targets AS target
        SET status = 'pool', assigned_to_id = NULL, assigned_at = NULL
        WHERE target.id IN (${Prisma.join(ids)})
          AND target.status = 'assigned' AND target.started_at IS NULL
          AND NOT target.skip_review_pending
          AND NOT EXISTS (
            SELECT 1 FROM design_credits AS credit
            WHERE credit.employee_id = target.assigned_to_id
              AND credit.design_id = target.job_number::text
              AND credit.first_work_date = ${workDate}::date
          )
      `);

      if (count > 0) this.logger.log(`Design targets returned to the pool · ${count}`);

      return { returned: count };
    } catch (err) {
      this.logger.error(
        `Could not return targets: ${err instanceof Error ? err.message : String(err)}`,
      );
      return { returned: 0 };
    }
  }

  /**
   * ⭐ ডিজাইনারের নিজের তালিকা — হাতে থাকা, **আর আজ শেষ করা**।
   *
   * ### ⚠️⚠️ কেন আজকেরগুলোও আসে *(মালিকের রিপোর্ট, ২৫ আগস্ট)*
   *
   * মালিক: *"onek somoy vule kew colplete press kore felole byak anote
   * paren na"*। কারণটা এখানেই ছিল — শর্তটা ছিল কেবল `assigned`, তাই
   * Complete চাপার সাথে সাথে সারিটা **পর্দা থেকেই উধাও** হতো।
   * ⭐ ফেরানোর বোতাম দূরে থাক, জিনিসটাই আর দেখা যেত না।
   *
   * ⚠️ আজকের বাইরে যাওয়া হয়নি: গতকালের Complete ফেরালে **গতকালের
   * সংখ্যাও** বদলে যেত, আর তখন কেউ চাইলে খারাপ দিনের কাজ ভালো দিনে
   * সরিয়ে নিতে পারতেন। পুরোনোগুলো মালিক ফেরাতে পারেন।
   *
   * ⚠️ "আজ" মানে **ঢাকার দিন** — রিপোর্ট যেভাবে গোনে, হুবহু সেভাবেই।
   */
  async mine(employeeId: number): Promise<MyTarget[]> {
    const rows = await this.prisma.designTarget.findMany({
      where: {
        assignedToId: employeeId,
        OR: [
          { status: DesignTargetStatus.assigned },
          {
            status: DesignTargetStatus.done,
            completedAt: { gte: dhakaStart(workDateStr(new Date())) },
          },
        ],
      },
      select: {
        id: true,
        asin: true,
        jobNumber: true,
        assignedAt: true,
        startedAt: true,
        completedAt: true,
        skipReviewPending: true,
        skipRequestedAt: true,
      },
      // ⚠️ যেটা আগে এসেছে সেটা আগে — নইলে পুরোনো টার্গেট চিরকাল তলায়
      //    পড়ে থাকত আর কেউ ধরত না
      orderBy: { assignedAt: 'asc' },
    });

    return rows.map((r) => ({
      skipReviewPending: r.skipReviewPending,
      skipRequestedAt: r.skipRequestedAt?.toISOString() ?? null,
      id: r.id,
      asin: r.asin,
      url: amazonUrl(r.asin),
      jobNumber: r.jobNumber,
      assignedAt: r.assignedAt?.toISOString() ?? null,
      startedAt: r.startedAt?.toISOString() ?? null,
      completedAt: r.completedAt?.toISOString() ?? null,
    }));
  }

  /**
   * ⭐⭐ **"শেষ" ফিরিয়ে নেওয়া** *(মালিকের রিপোর্ট, ২৫ আগস্ট)*।
   *
   * ⚠️⚠️ `completedAt` · `completedVia` · `completedById` — **তিনটেই**
   * মুছতে হয়, কেবল `status` ফেরালে হয় না। কারণ কিউগুলো `status` ধরে
   * নয়, **`completedAt` ধরে** চলে (`to_check`, `to_upload`) — শুধু
   * অবস্থা ফেরালে সারিটা "হাতে আছে" দেখাত অথচ আপলোডের কিউতে বসে
   * থাকত। ⭐ পুলে-ফেরত পাঠানোর ডালটাও ঠিক এই তিনটেই মোছে।
   *
   * ⚠️ কিন্তু `assignedToId`/`assignedAt`/`startedAt` **ছোঁয়া হয় না** —
   * কাজটা যাঁর ছিল তাঁরই থাকে। ওগুলো মুছলে সারিটা পুলে ফিরে যেত, আর
   * ডিজাইনার নিজের ভুল শুধরাতে গিয়ে কাজটাই হারাতেন।
   */
  private async clearCompletion(
    where: Prisma.DesignTargetWhereInput,
    by: { userId: number; ip: string | null },
  ): Promise<number> {
    /**
     * ⚠️⚠️ **মোছার আগে পড়ে নেওয়া হয়, আর সেটাই এখানকার আসল কথা।**
     * `completed_at` · `completed_via` · `completed_by_id` — তিনটেই
     * `null` হয়ে যাচ্ছে, অর্থাৎ কাজটা কখনো শেষ হয়েছিল সেই প্রমাণটাই
     * সারি থেকে উধাও। ⭐ পরে পড়লে আর কিছুই পাওয়া যেত না।
     */
    const before = await this.prisma.designTarget.findFirst({
      where,
      select: {
        id: true,
        asin: true,
        jobNumber: true,
        assignedToId: true,
        completedAt: true,
        completedVia: true,
        completedById: true,
      },
    });
    if (before === null) return 0;

    const { count } = await targetWrite(this.prisma, by.userId, 'manual', tx => tx.designTarget.updateMany({
      where,
      data: {
        status: DesignTargetStatus.assigned,
        completedAt: null,
        completedVia: null,
        completedById: null,
      },
    }));
    if (count === 0) return 0;

    /**
     * ⭐⭐ **এটাই একমাত্র মুছে-ফেলা কাজ যার নিজের চিহ্ন থাকে না** — তাই
     * লগটাই একমাত্র জায়গা *(মালিকের প্রশ্নে যোগ হয়েছে, ২৫ আগস্ট:
     * "ei access ta ki designer der pawa uchit?")*।
     *
     * ⚠️ প্রশ্নটার আসল সমস্যা ছিল অধিকার নয়, **যাচাই করার উপায় না
     * থাকা**। লগ থাকলে প্রশ্নটা "বিশ্বাস করব কি না" থেকে "দরকার হলে
     * দেখে নেব"-তে নেমে আসে।
     */
    await this.audit.record({
      userId: by.userId,
      action: 'design_undone',
      targetType: 'design_target',
      targetId: before.id,
      ipAddress: by.ip ?? undefined,
      meta: {
        asin: before.asin,
        jobNumber: before.jobNumber,
        assignedToId: before.assignedToId,
        // ⚠️ যা মুছে গেল — সারিতে এগুলো আর নেই
        completedAt: before.completedAt?.toISOString() ?? null,
        completedVia: before.completedVia,
        completedById: before.completedById,
      },
    });

    return count;
  }

  /**
   * ⭐ ডিজাইনারের নিজের Undo — **আজকের**, **নিজের**, আর **এখনো এগোয়নি**।
   *
   * ⚠️⚠️ `count === 0` হলে চুপ করে থাকা যায় না। "Undo চাপলাম, কিছুই হলো
   * না" — এটাই সেই নীরব ব্যর্থতা যা মানুষকে সিস্টেমের উপর আস্থা হারায়।
   * ⭐ তাই কেন হলো না, সেটা খুঁজে বলা হয়।
   */
  async undoMine(
    employeeId: number,
    id: number,
    now: Date,
    by: { userId: number; ip: string | null },
  ): Promise<{ ok: boolean }> {
    const count = await this.clearCompletion(
      {
        id,
        assignedToId: employeeId,
        status: DesignTargetStatus.done,
        completedAt: { gte: dhakaStart(workDateStr(now)) },
        // ⚠️ শেকলে এগিয়ে যাওয়া সারি ফেরানো যায় না — কেউ বানান দেখে
        //    ফেলেছেন বা Amazon-এ পাঠিয়ে দিয়েছেন, সেটা আর "ভুলে চাপা" নয়
        checkedAt: null,
        uploadedAt: null,
        liveAt: null,
      },
      by,
    );
    if (count > 0) return { ok: true };

    const row = await this.prisma.designTarget.findUnique({
      where: { id },
      select: {
        assignedToId: true,
        status: true,
        completedAt: true,
        checkedAt: true,
        uploadedAt: true,
        liveAt: true,
      },
    });

    if (!row || row.assignedToId !== employeeId) {
      throw new ForbiddenException('That design is not on your list.');
    }
    if (row.status !== DesignTargetStatus.done || row.completedAt === null) {
      // ⭐ দুবার চাপলে এখানেই এসে পড়ে — আর সেটা ব্যর্থতা নয়
      return { ok: true };
    }
    if (row.checkedAt !== null || row.uploadedAt !== null || row.liveAt !== null) {
      throw new ConflictException(
        'This design has already moved on — someone has checked it or sent it to Amazon. Ask the owner to undo it.',
      );
    }
    throw new ConflictException(
      "You can only undo today's work. Ask the owner to undo an older one.",
    );
  }

  /**
   * ⭐ মালিক ও ম্যানেজারের Undo — **যেকোনো দিনের, যে কারো**।
   *
   * ⚠️ দিনের সীমা নেই, কারণ পুরোনো ভুল শোধরানোই এর একমাত্র কাজ। কিন্তু
   * শেকলে এগিয়ে যাওয়া সারি এখানেও ফেরানো যায় না — ওটা ফেরালে বানান-কিউ
   * আর আপলোডের সংখ্যাগুলো একসাথে মিথ্যে হয়ে যেত।
   */
  async undoComplete(
    id: number,
    by: { userId: number; ip: string | null },
  ): Promise<{ ok: boolean }> {
    const count = await this.clearCompletion(
      {
        id,
        status: DesignTargetStatus.done,
        checkedAt: null,
        uploadedAt: null,
        liveAt: null,
      },
      by,
    );
    if (count > 0) return { ok: true };

    const row = await this.prisma.designTarget.findUnique({
      where: { id },
      select: { status: true, checkedAt: true, uploadedAt: true, liveAt: true },
    });
    if (!row) throw new NotFoundException('Design target not found');
    if (row.status !== DesignTargetStatus.done) return { ok: true };

    throw new ConflictException(
      'This design has already been checked or sent to Amazon — undo those steps first.',
    );
  }

  /**
   * ⭐ "এটা বাদ দিলাম"।
   *
   * ⚠️⚠️ **শর্তে `assignedToId` আছে** — নিজের টার্গেট ছাড়া কেউ কিছু
   * ছুঁতে পারে না। আইডি অনুমান করে অন্যের সারি বদলানোর পথ বন্ধ।
   */
  async skip(
    employeeId: number,
    id: number,
    reason: DropReason,
    now: Date = new Date(),
    userId: number | null = null,
  ): Promise<{ ok: boolean }> {
    const result = await targetWrite(this.prisma, userId, 'skip_request', async tx => {
      // Serialize the allowance across tabs/API instances. Undo never refunds it.
      await tx.$queryRaw`SELECT pg_advisory_xact_lock(260927, ${employeeId}::int)::text`;
      await tx.$queryRaw`SELECT id FROM design_targets WHERE id = ${id} FOR UPDATE`;
      const row = await tx.designTarget.findUnique({ where: { id } });
      if (!row || row.assignedToId !== employeeId || row.status !== 'assigned' || row.skipReviewPending)
        return { ok: false, pending: false };
      const count = await tx.designSkipRequest.count({ where: {
        employeeId, requestedAt: { gte: localMidnightOf(now), lt: nextLocalMidnight(now) },
      } });
      const pending = count >= DAILY_AUTOMATIC_SKIPS;
      await tx.designSkipRequest.create({ data: {
        targetId: id, employeeId, actorUserId: userId, reason, requestedAt: now,
        decision: pending ? 'pending' : 'automatic', decidedAt: pending ? null : now,
      } });
      await tx.designTarget.update({ where: { id }, data: {
        status: pending ? 'assigned' : 'skipped', dropReason: reason,
        skipReviewPending: pending, skipRequestedAt: now,
        reviewedAt: null, reviewedById: null,
      } });
      return { ok: true, pending };
    }, { maxWait: 30_000, timeout: 30_000 });
    // Pending work occupies its assignment slot in every allocation path.
    if (result.ok && !result.pending) await this.topUp(employeeId, now);
    return { ok: result.ok };
  }

  async skipAllowance(employeeId: number, now = new Date()) {
    const requested = await this.prisma.designSkipRequest.count({ where: {
      employeeId, requestedAt: { gte: localMidnightOf(now), lt: nextLocalMidnight(now) },
    } });
    return { limit: DAILY_AUTOMATIC_SKIPS, requested, remaining: Math.max(0, DAILY_AUTOMATIC_SKIPS - requested) };
  }

  async decideSkip(id: number, approve: boolean, userId: number, now = new Date()): Promise<{ ok: boolean }> {
    const employeeId = await targetWrite(this.prisma, userId, approve ? 'skip_approved' : 'skip_rejected', async tx => {
      await tx.$queryRaw`SELECT id FROM design_targets WHERE id = ${id} FOR UPDATE`;
      const row = await tx.designTarget.findUnique({ where: { id } });
      if (!row?.skipReviewPending || row.status !== 'assigned')
        throw new ConflictException('This skip request has already been decided or changed. Refresh the list.');
      const decision = await tx.designSkipRequest.updateMany({
        where: { targetId: id, decision: 'pending' },
        data: { decision: approve ? 'approved' : 'rejected', decidedAt: now, reviewerUserId: userId },
      });
      if (decision.count !== 1) throw new ConflictException('No pending skip request exists.');
      await tx.designTarget.update({ where: { id }, data: {
        skipReviewPending: false, status: approve ? 'skipped' : 'assigned',
        dropReason: approve ? row.dropReason : null,
        skipRequestedAt: approve ? row.skipRequestedAt : null,
        reviewedAt: approve ? now : null, reviewedById: approve ? userId : null,
      } });
      return row.assignedToId;
    }, { maxWait: 30_000, timeout: 30_000 });
    if (approve && employeeId !== null) await this.topUp(employeeId, now);
    return { ok: true };
  }

  /**
   * "শেষ করেছি" — হাতে চিহ্ন।
   *
   * ⚠️ `completedVia: 'manual'` লেখা থাকে, যাতে পরে বলা যায় কোনটা সিস্টেম
   * নিজে ধরেছে আর কোনটা কেউ হাতে বলেছে। সংখ্যাটা এক, কিন্তু ভরসা এক নয়।
   */
  async markDone(
    employeeId: number,
    id: number,
    userId: number,
    now: Date = new Date(),
  ): Promise<{ ok: boolean }> {
    /**
     * ⭐⭐⭐ **দিনের সীমা** *(মালিকের নিয়ম, ৯ সেপ্টেম্বর ২০২৬)* — সীমাটা
     * তাঁর নিজের দৈনিক টার্গেটের সংখ্যাই ([`dailyCompletionCap`]).
     *
     * ⚠️⚠️ **এটা কেবল এই পথে** — অর্থাৎ ডিজাইনার নিজে যেখানে বোতাম
     * চাপেন (`POST /me/targets/:id/done`)। মালিক বা ম্যানেজারের
     * `update()` পথটা ছোঁয়া হয়নি, নইলে ভুল সংশোধনের রাস্তাই বন্ধ হতো।
     */
    // Serialize completion decisions per employee across API instances.
    // Transaction locks are released on commit/rollback; namespace differs from clock drift.
    const completion = await this.prisma.$transaction(async (tx) => {
      await targetHistoryContext(tx, userId, 'manual');
      await tx.$queryRaw`SELECT pg_advisory_xact_lock(260926, ${employeeId}::int)::text AS locked`;
      const cap = await this.capFor(employeeId, tx);
      if (cap !== null) {
        const doneToday = await this.completedToday(employeeId, now, tx);
        if (doneToday >= cap) {
          // Commit the rejection evidence before returning HTTP 409; throwing inside
          // this transaction would also roll the audit record back.
          await tx.auditLog.create({ data: { userId, action: 'completion_cap_blocked',
            targetType: 'design_target', targetId: String(id), meta: { employeeId, cap, doneToday } } });
          return { count: 0, blockedCap: cap };
        }
      }
      const result = await tx.designTarget.updateMany({
        where: { id, assignedToId: employeeId, status: DesignTargetStatus.assigned, skipReviewPending: false },
        data: {
          status: DesignTargetStatus.done,
          completedAt: now,
          completedVia: 'manual',
          completedById: userId,
        },
      });
      return { count: result.count, blockedCap: null };
    });
    if (completion.blockedCap !== null) {
      throw new ConflictException(
        `You have already marked ${completion.blockedCap} designs done today, so this one ` +
          `cannot be marked done — leave it in your list and finish it tomorrow.`,
      );
    }
    if (completion.count > 0) await this.topUp(employeeId, now);

    return { ok: completion.count > 0 };
  }

  /**
   * ⭐⭐⭐ **সব ডিজাইনারের হাত দেখে নেওয়া** *(৯ সেপ্টেম্বর ২০২৬)* —
   * যাঁর দরকার, কেবল তাঁকেই দেওয়া হয়।
   *
   * ⚠️⚠️ **কেন ঘটনার সাথে সাথে চালানোই যথেষ্ট নয়।** `topUp()` ডাকা হয়
   * শেষ বা বাদ দেওয়ার **পরে**, অর্থাৎ কিছু একটা হাতে থাকতেই হয়। যাঁর
   * হাতে **একটাও নেই** তিনি কিছু চাপতেই পারেন না — আর ঠিক তাঁর কথাই
   * মালিক বলেছিলেন (*"তার কাছে করার মতো আর ডিজাইন নেই"*)।
   *
   * ⚠️ মাঠে ওই অবস্থাটা হয়: সকালে পুলে কম থাকলে `allocationSizes`
   * কর্মী-কোডের ক্রমে দেয় আর শেষজন **কিছুই পান না**; মাঝদিনে যোগ দেওয়া
   * কেউ, বা যাঁর ধরন সেদিনই `designer` করা হলো — সবারই একই দশা।
   *
   * ⭐ `topUp()` নিজেই idempotent (হাত ভরা থাকলে ০ ফেরত দেয়), তাই
   * বারবার চালানো নিরাপদ।
   */
  async topUpAll(now: Date = new Date()): Promise<void> {
    const designers = await this.prisma.employee.findMany({
      where: { status: 'active', staffType: { in: [...DESIGN_WORK_STAFF_TYPES] } },
      select: { id: true },
      orderBy: { empCode: 'asc' },
    });

    for (const d of designers) await this.topUp(d.id, now);
  }

  /**
   * ⭐ **এই কর্মীর দিনের সীমা** — `null` মানে সীমা নেই।
   *
   * ⚠️ সংখ্যাটা তিন জায়গা থেকে আসে (কর্মীর নিজের ঘর → পলিসি → নেই), আর
   * সেই ক্রমটা `designTargetOf()`-এ একবারই লেখা।
   */
  private async capFor(
    employeeId: number,
    db: Prisma.TransactionClient = this.prisma,
  ): Promise<number | null> {
    const emp = await db.employee.findUnique({
      where: { id: employeeId },
      select: {
        staffType: true,
        dailyDesignTarget: true,
        policy: { select: { dailyDesignTarget: true } },
      },
    });
    if (emp === null) return null;

    return dailyCompletionCap(
      emp.staffType,
      emp.dailyDesignTarget,
      emp.policy?.dailyDesignTarget,
    );
  }

  /**
   * ⭐ **আজ ঢাকার দিনে কতগুলো "শেষ" বলা হয়েছে।**
   *
   * ⚠️⚠️ সীমানা দুটো `localMidnightOf`/`nextLocalMidnight` থেকে — হাতে
   * কষা হয় না। `workDateOf()` একটা **লেবেল**, মুহূর্ত নয়; ওটা সরাসরি
   * বসালে দিনটা ঢাকার ভোর ৬টায় শুরু হতো, আর এই রেপোতে ঠিক ওই ভুলটাই
   * সবচেয়ে বেশিবার হয়েছে।
   *
   * ⚠️ গোনা হয় `assignedToId` ধরে, `completedById` ধরে নয় — ড্যাশবোর্ডের
   * সংখ্যাটাও তাই, আর দুটো আলাদা হলে পর্দা ও সীমা দুটো কথা বলত।
   */
  private async completedToday(
    employeeId: number,
    now: Date,
    db: Prisma.TransactionClient = this.prisma,
  ): Promise<number> {
    return db.designTarget.count({
      where: {
        assignedToId: employeeId,
        completedAt: { gte: localMidnightOf(now), lt: nextLocalMidnight(now) },
      },
    });
  }

  /**
   * ⭐⭐⭐ **হাতে যথেষ্ট না থাকলে আরও দেওয়া** *(মালিকের নিয়ম,
   * ৯ সেপ্টেম্বর ২০২৬)* — শেষ বা বাদ দেওয়ার ঠিক পরেই।
   *
   * ⚠️⚠️ **কখনো throw করে না।** টপ-আপ একটা সুবিধা; ওটা ব্যর্থ হলে
   * ডিজাইনারের "শেষ করেছি" চাপাটা ব্যর্থ হবে না।
   *
   * ⭐ ঘটনার সাথে সাথে চলে, কোনো টিকের অপেক্ষায় নয় — নইলে কেউ হাত খালি
   * নিয়ে দশ মিনিট বসে থাকতেন। সকালের বণ্টনের যন্ত্রটাই (`claimFor`)
   * ব্যবহার হয়, তাই পুল থেকে তোলার নিয়ম এক জায়গাতেই থাকে।
   */
  private async topUp(employeeId: number, now: Date): Promise<void> {
    try {
      const emp = await this.prisma.employee.findUnique({
        where: { id: employeeId },
        select: {
          staffType: true,
          dailyDesignTarget: true,
          policy: { select: { dailyDesignTarget: true } },
        },
      });
      // ⚠️ টার্গেট যাঁর নেই (ম্যানেজার), তাঁর জন্য কিছুই নয় — সকালের
      //    বণ্টনই যথেষ্ট, আর তাঁর ছোঁয়ার মতো কোনো সংখ্যা নেই
      if (emp === null || !hasDesignTarget(emp.staffType)) return;

      const [completedToday, openCount, issuedToday] = await Promise.all([
        this.completedToday(employeeId, now),
        this.prisma.designTarget.count({
          where: { assignedToId: employeeId, status: DesignTargetStatus.assigned },
        }),
        // ⭐ আজ মোট কতগুলো দেওয়া হয়েছে — দিনের ছাদটা এর উপরেই দাঁড়ায়
        this.prisma.designTarget.count({
          where: {
            assignedToId: employeeId,
            assignedAt: { gte: localMidnightOf(now), lt: nextLocalMidnight(now) },
          },
        }),
      ]);

      const size = topUpSize({
        staffType: emp.staffType,
        completedToday,
        openCount,
        issuedToday,
        dailyTarget: designTargetOf(
          emp.dailyDesignTarget,
          emp.policy?.dailyDesignTarget,
        ),
      });
      if (size === 0) return;

      const given = await this.claimFor(employeeId, size, now);

      if (given > 0) {
        this.logger.log(
          `Design targets topped up · ${given} to employee ${employeeId} ` +
            `(done ${completedToday}, had ${openCount})`,
        );
      }
    } catch (err) {
      this.logger.error(
        `Top-up failed for employee ${employeeId}: ${
          err instanceof Error ? err.message : String(err)
        }`,
      );
    }
  }

  /**
   * ⭐⭐ **ফাইলের নাম থেকে "কাজ শুরু হয়েছে" ধরা।**
   *
   * ⚠️⚠️ **আগে এটাকেই "শেষ" ধরা হতো, আর সেটা ভুল ছিল** *(সারানো ২৩
   * আগস্ট, মালিকের প্রশ্নে)*। এজেন্ট শিরোনাম থেকে নম্বরটা তখনই দেখে যখন
   * ফাইলটা **সামনে আসে** — অর্থাৎ কাজ শুরুর মুহূর্তে। ওটাকে "শেষ" ধরায়
   * টার্গেট **খোলামাত্র বন্ধ** হয়ে যেত, আর ডিজাইনার পরদিন সেটা তালিকায়
   * খুঁজে পেতেন না।
   *
   * ⭐ সিস্টেম এখন যা **সত্যিই জানে** সেটুকুই বলে: কাজ শুরু হয়েছে।
   * শেষ হওয়া বলেন ডিজাইনার নিজে (`markDone`)।
   *
   * ডিজাইনার বরাদ্দ পাওয়া নম্বরটা ফাইলের নামে বসান
   * (`1000042-Funny Cat T-Shirt.ai`), আর ওই নম্বরটাই `design_credits`-এ
   * উঠে আসে। এখানে সেটা মিলিয়ে টার্গেটটা বন্ধ করা হয়।
   *
   * ⚠️⚠️ **শর্তে `assignedToId` আছে** — একজনের ফাইল আরেকজনের টার্গেট
   * বন্ধ করতে পারবে না। নম্বর দুজনের কাছে থাকার কথা নয়, কিন্তু "কথা নয়"
   * আর "পারবে না" এক জিনিস নয়।
   *
   * ⚠️ কখনো throw করে না — এটা একটা সুবিধা, আর এর জন্য দৈনিক সারাংশ
   * আটকে যাওয়া চলবে না।
   */
  async markStartedByJobNumbers(
    employeeId: number,
    /**
     * ⭐⭐⭐ **নম্বর → সেদিন সবচেয়ে আগে যে মুহূর্তে ফাইলটা খোলা দেখা গেছে**
     * *(৬ সেপ্টেম্বর ২০২৬, G163)*।
     *
     * ⚠️⚠️ আগে এটা ছিল `numbers: string[]` আর একটা `now: Date` — আর
     * কলার ওই `now`-এর জায়গায় **কর্মদিবসের লেবেল** পাঠাত। লেবেলটা
     * UTC-মধ্যরাত, অর্থাৎ **ঢাকার ভোর ৬টা**, তাই প্রতিটা টার্গেটের
     * "কাজ শুরু" ওই এক মুহূর্তেই বসত। মাঠে ৭১১টার ৭১১টা — একটাই সময়,
     * আর প্রত্যেকটাই তার নিজের `assigned_at`-এর আগে (বণ্টন সকাল ৮টায়)।
     *
     * ⭐ এখন ঘরটা একটা `Map` — অর্থাৎ **প্রতিটা নম্বরের নিজের মুহূর্ত
     * ছাড়া ডাকাই যায় না**। একটা সাধারণ `Date` ঘর রাখলে কেউ আবার
     * লেবেল পাঠাত, আর কম্পাইলার চুপ থাকত।
     */
    startedAt: ReadonlyMap<string, Date>,
  ): Promise<number> {
    if (startedAt.size === 0) return 0;

    const at = new Map<number, Date>();
    for (const [raw, when] of startedAt) {
      const n = Number.parseInt(raw, 10);
      if (Number.isSafeInteger(n)) at.set(n, when);
    }
    if (at.size === 0) return 0;

    try {
      /**
       * ⚠️ আগে একটাই `updateMany` ছিল, কারণ সবার সময় এক ছিল। এখন
       * প্রতিটার নিজের সময়, তাই আগে দেখা হয় **কারা এখনো অচিহ্নিত** —
       * সাধারণত দিনে ০–৪টা। বাকি নম্বরগুলোয় কোনো কুয়েরিই যায় না।
       */
      const pending = await this.prisma.designTarget.findMany({
        where: {
          jobNumber: { in: [...at.keys()] },
          assignedToId: employeeId,
          status: DesignTargetStatus.assigned,
          // ⚠️ যেটায় আগেই চিহ্ন বসেছে সেটা আবার ছোঁয়া হয় না — নইলে
          //    "কবে শুরু" রোজ আজকের তারিখে সরে যেত
          startedAt: null,
        },
        select: { id: true, jobNumber: true },
      });

      let count = 0;

      for (const row of pending) {
        const when = row.jobNumber === null ? undefined : at.get(row.jobNumber);
        if (when === undefined) continue;

        // ⚠️ `startedAt: null` শর্তটা এখানেও — উপরের পড়া আর এই লেখার
        //    মাঝে অন্য একটা রান চিহ্ন বসিয়ে ফেলতে পারে
        const { count: n } = await targetWrite(this.prisma, null, 'agent', tx => tx.designTarget.updateMany({
          where: {
            id: row.id, startedAt: null,
            status: DesignTargetStatus.assigned, assignedToId: employeeId,
          },
          data: { startedAt: when },
        }));

        count += n;
      }

      return count;
    } catch (err) {
      this.logger.warn(
        `Could not mark targets started: ${
          err instanceof Error ? err.message : String(err)
        }`,
      );
      return 0;
    }
  }

  /**
   * ⭐ খোঁজার শর্তটার আকৃতি — `where`-এ ছড়িয়ে দেওয়া হয়।
   *
   * ⚠️ `OR` ঐচ্ছিক: শুধু-অঙ্ক লেখা হলে Job নম্বর **আর** ASIN দুটোই দেখা
   *    হয়, নইলে কেবল ASIN।
   */
  /**
   * ⭐⭐ **পুরো তালিকা** *(২৩ আগস্ট, মালিকের চাওয়া)* — ছাঁকনি ও পাতা ভাগসহ।
   *
   * ⚠️⚠️ **পাতা ভাগ বাধ্যতামূলক, ঐচ্ছিক নয়:** টেবিলে **৩৯ হাজারের বেশি**
   * সারি। সব একসাথে পাঠালে উত্তরটা কয়েক MB হতো, আর ব্রাউজার ওই টেবিল
   * আঁকতে গিয়ে জমে যেত।
   *
   * ⭐⭐ `q` দিয়ে **ASIN বা Job নম্বর** — দুটোই *(৬ সেপ্টেম্বর ২০২৬,
   * মালিকের চাওয়া)*। পর্দায় প্রতিটা সারির নিচে Job নম্বরটা লেখা থাকে,
   * অথচ ওটা দিয়ে খোঁজা যেত না — একমাত্র পরিচয় ছিল ASIN।
   *
   * ⚠️⚠️ **URL দিয়ে আর খোঁজা যায় না** — আগে `asinOf()` দিয়ে লিঙ্ক থেকে
   * ASIN বের করা হতো, কিন্তু মালিক ওটা তুলে দিতে বলেছেন। ⭐ পর্দা তাই
   * লিঙ্ক পেস্ট করলে **সরাসরি বলে দেয়**, নইলে ফলটা হতো একটা নীরব
   * খালি তালিকা — এই অ্যাপে সবচেয়ে অপছন্দের ব্যর্থতা।
   */
  async list(query: {
    status?: DesignTargetStatus;
    q?: string;
    page?: number;
    /** ⭐ কোন ডিজাইনারের — `employees.id` */
    staffId?: number;
    /**
     * ⭐ কে এনেছেন — `users.id` *(২৫ আগস্ট)*।
     *
     * ⚠️⚠️ `staffId`-র সাথে **আলাদা id-র জগৎ**: ওটা `employees`, এটা
     * `users`। একটার সংখ্যা অন্যটায় বসালে চুপচাপ ভুল মানুষের সারি
     * আসত — কোনো এরর নয়, কেবল ভুল উত্তর।
     */
    addedById?: number;
    /** ⭐ 'YYYY-MM-DD' — শেষ কাজের তারিখ এই দিন থেকে */
    from?: string;
    /** ⭐ 'YYYY-MM-DD' — এই দিন পর্যন্ত (দিনটাসহ) */
    to?: string;
    /** ⭐ শেকলের কোন ধাপে আটকে — গবেষকের কিউ (২৪ আগস্ট) */
    /** ⚠️ `no_file` ধাপ নয়, একটা **প্রশ্ন** — ৯ সেপ্টেম্বর ২০২৬ */
    stage?:
      | 'to_check'
      | 'to_fix'
      | 'to_upload'
      | 'to_live'
      | 'to_review'
      | 'no_file';
  }): Promise<{
    rows: TargetRow[];
    total: number;
    page: number;
    pages: number;
    /** ⭐ কোন দিন থেকে শিরোনাম জমা আছে — `fileSec === null` কেন, তার উত্তর */
    traceSince: string | null;
  }> {
    const page = Math.max(1, query.page ?? 1);

    /**
     * ⭐⭐ **ASIN নাকি Job নম্বর** — পার্থক্যটা এক লাইনে: শুধু অঙ্ক হলে
     * Job নম্বর, নইলে ASIN।
     *
     * ⚠️ তবু অঙ্ক হলে **দুটোই** দেখা হয় (`OR`)। কিছু ASIN পুরোপুরি
     * সংখ্যায় হয় (পুরোনো ISBN-ধাঁচের), আর তখন কেবল Job নম্বর খুঁজলে
     * ওই সারিটা কোনোদিন পাওয়া যেত না — নীরবে।
     *
     * ⚠️⚠️ `Number()` করার আগে **সীমা দেখা হয়**: `job_number` কলামটা
     * `Int`, তাই ২,১৪৭,৪৮৩,৬৪৭-এর বড় কিছু পাঠালে Prisma ছুড়ত আর
     * খোঁজাটা ৫০০ হয়ে ফিরত — অথচ ব্যবহারকারী শুধু একটা লম্বা সংখ্যা
     * লিখেছেন।
     */
    const INT32_MAX = 2_147_483_647;
    let match: TargetSearchMatch | undefined;

    const term = query.q?.trim().toUpperCase();
    if (term) {
      const digits = /^\d+$/.test(term);
      const jobNumber = digits ? Number(term) : NaN;

      match =
        digits && Number.isSafeInteger(jobNumber) && jobNumber <= INT32_MAX
          ? { OR: [{ jobNumber }, { asin: { contains: term } }] }
          : { asin: { contains: term } };
    }

    /**
     * ⭐⭐ **তারিখটা `lastActivityAt` ধরে** *(২৩ আগস্ট ২০২৬)* — অর্থাৎ
     * "শেষ যা ঘটেছে"।
     *
     * ⚠️⚠️ অবস্থাভেদে আলাদা ঘর ধরা হয়নি (done হলে completedAt, assigned
     * হলে assignedAt) — সেটা করলে "কোন তারিখ ছাঁকা হচ্ছে" প্রশ্নটা
     * প্রতিবার বদলাত, আর ক্রম ও ছাঁকনি দুটো আলাদা ভিত্তিতে দাঁড়াত।
     *
     * ⭐ এক ভিত্তি রাখায় ফলটা স্বাভাবিকভাবেই ঠিক হয়: `done` বাছলে ওই
     * সারির `lastActivityAt` মানেই `completedAt`, কারণ সেটাই সবচেয়ে পরের।
     *
     * ⚠️ `to`-তে দিনটা **অন্তর্ভুক্ত** — মানুষ "২৩ তারিখ পর্যন্ত" বললে
     * ২৩ তারিখটাও বোঝায়। তাই পরের দিনের শুরু পর্যন্ত (`lt`) দেখা হয়।
     */

    const activity =
      query.from || query.to
        ? {
            ...(query.from ? { gte: dhakaStart(query.from) } : {}),
            ...(query.to ? { lt: nextDay(query.to) } : {}),
          }
        : undefined;

    /**
     * ⭐⭐ **গবেষকের দুটো কিউ** *(২৪ আগস্ট ২০২৬)* — শেকলের ঠিক কোন ধাপে
     * সারিটা আটকে আছে।
     *
     * ⚠️ `to_upload`-এ **কাটা-তারিখ** আছে, `to_live`-এ নেই — কারণটা
     *    [targets.rules.ts](./targets.rules.ts)-এর `UPLOAD_QUEUE_FROM`-এ:
     *    পুরোনো ২৭ হাজার ইমপোর্ট-করা সারি বাদ না দিলে কিউটা পাহাড় হতো।
     *    `to_live`-এ ওই সমস্যা নেই, কারণ Uploaded চাপা সারিই মাত্র একটা।
     */
    /**
     * ⭐⭐ **কোন দিন থেকে শিরোনাম জমা আছে** *(৯ সেপ্টেম্বর ২০২৬)* —
     * "ফাইলের চিহ্ন নেই" বলার অধিকার এই তারিখটার পর থেকেই।
     *
     * ⚠️ প্রতিটা পাতায় একবার ডাকা হয়; ধ্রুবক বসানো হয়নি ইচ্ছাকৃতভাবে,
     * কারণ কোনোদিন পুরোনো সারি ছাঁটা শুরু হলে সীমানাটা নিজে থেকেই
     * এগোবে — কারো মনে রাখতে হবে না।
     */
    const traceSince = await this.trace.since();
    const since = traceSince === null ? null : dhakaStart(traceSince);

    /**
     * ⭐ কেবল **এই একটা ধাপের** জন্য — আর প্রশ্নটা `design_targets` থেকে
     * জিজ্ঞেস করা হয় বলে খরচ ৯৩০ ms থেকে ২৫ ms-এ নামে
     * ([`unseenJobNumbers`](./file-trace.service.ts))।
     */
    const noFileFrom =
      traceSince === null
        ? null
        : dhakaStart(laterDay(UPLOAD_QUEUE_FROM, traceSince));

    const unseenJobs =
      query.stage === 'no_file' && noFileFrom !== null
        ? await this.trace.unseenJobNumbers(noFileFrom)
        : [];

    const stage =
      /**
       * ⭐⭐⭐ **শেষ বলা হয়েছে, অথচ ফাইলটা কখনো খোলা হয়নি**
       * *(মালিকের চাওয়া, ৯ সেপ্টেম্বর ২০২৬: "kha banao")*।
       *
       * ⚠️⚠️ **এটা অ্যালার্ট নয়, আর সেটাই মালিকের শর্ত ছিল** — *"নীরব
       * তালিকা"*। কারণ চিহ্ন না থাকার নির্দোষ ব্যাখ্যা অনেক: ফাইলটা সেভ
       * করা হয়নি (মাঠে একজন গোটা দিন `Untitled-20*`-এ কাজ করেন), নামের
       * সামনে নম্বর বসানো হয়নি, বা কাজটা অন্য অ্যাপে হয়েছে। ⭐ তাই
       * তালিকাটা একটা **প্রশ্ন**, অভিযোগ নয়।
       *
       * ⚠️⚠️ দুটো সীমা **একসাথে** খাটে, আর দুটোরই আলাদা কারণ:
       *   · `UPLOAD_QUEUE_FROM` — পুরোনো ২৭ হাজার ইমপোর্ট করা সারি বাদ
       *   · `traceSince` — এর আগে আমরা শিরোনাম **দেখতামই না**
       * পরেরটা যেটা, সেটাই ধরা হয়।
       */
      query.stage === 'no_file'
        ? noFileFrom === null
          ? // ⚠️ একটাও শিরোনাম জমা নেই — তখন কারো নামে কিছু বলার অধিকার নেই
            { id: { in: [] as number[] } }
          : {
              completedAt: { not: null, gte: noFileFrom },
              jobNumber: { in: unseenJobs },
            }
        : query.stage === 'to_check'
        ? {
            completedAt: { not: null, gte: dhakaStart(UPLOAD_QUEUE_FROM) },
            checkedAt: null,
          }
        : query.stage === 'to_fix'
          ? { errorFoundAt: { not: null }, fixedAt: null }
          : query.stage === 'to_upload'
            ? {
                completedAt: { not: null, gte: dhakaStart(UPLOAD_QUEUE_FROM) },
                uploadedAt: null,
                /**
                 * ⚠️⚠️ **যেগুলোয় ভুল পাওয়া গেছে অথচ ঠিক হয়নি — বাদ**
                 * *(মালিকের সিদ্ধান্ত, ২৫ আগস্ট)*। জানা-ভাঙা ডিজাইন
                 * Amazon-এ যাবে না।
                 *
                 * ⭐ কিন্তু **এখনো দেখা হয়নি** এমন সারি আটকায় না — আটকালে
                 * আজকের ১৩২টা কিউ রাতারাতি ০ হয়ে যেত, আর কেউ শুরুই করত না।
                 */
                NOT: { errorFoundAt: { not: null }, fixedAt: null },
              }
            : query.stage === 'to_live'
              ? { uploadedAt: { not: null }, liveAt: null }
              : /**
                 * ⭐⭐ **বাদ-যাওয়া অথচ কেউ দেখেনি** *(৩১ আগস্ট ২০২৬)*।
                 *
                 * ⚠️⚠️ **কাটা-তারিখের বদলে `dropReason: { not: null }`,
                 * আর এটাই এখানকার একমাত্র চালাকি।** পুরোনো ৯৩টা `skipped`
                 * সারিতে কোনো কারণ লেখা নেই (কারণ চাওয়ার ব্যবস্থাটা ৩১
                 * আগস্টের), তাই ম্যানেজারের "দেখে নেওয়ার" কিছুই নেই —
                 * ওগুলো এমনিতেই বাদ পড়ে যায়। ⭐ `UPLOAD_QUEUE_FROM`-এর মতো
                 * একটা তারিখ-ধ্রুবক লাগেনি: শর্তটা **অর্থ** ধরে চলে,
                 * ক্যালেন্ডার ধরে নয় — আর তাই একদিন তারিখ বদলানোর কথা
                 * কারো মনে রাখতে হবে না।
                 */
                query.stage === 'to_review'
                ? {
                    OR: [{ skipReviewPending: true }, { status: {
                      in: [
                        DesignTargetStatus.skipped,
                        DesignTargetStatus.deleted,
                      ],
                    } }],
                    dropReason: { not: null },
                    reviewedAt: null,
                  }
                : {};

    const where = {
      ...(query.status ? { status: query.status } : {}),
      ...(query.staffId ? { assignedToId: query.staffId } : {}),
      ...(query.addedById ? { addedById: query.addedById } : {}),
      ...(activity ? (query.stage === 'to_review' || query.status === 'skipped'
        ? { skipRequestedAt: activity } : query.status === 'done' ? { completedAt: activity } : { lastActivityAt: activity }) : {}),
      AND: [match ?? {}, stage],
    };

    const [total, rows] = await Promise.all([
      this.prisma.designTarget.count({ where }),
      this.prisma.designTarget.findMany({
        where,
        select: {
          id: true,
          asin: true,
          status: true,
          jobNumber: true,
          assignedAt: true,
          startedAt: true,
          completedAt: true,
          completedVia: true,
          skipReviewPending: true,
          skipRequestedAt: true,
          checkedAt: true,
          errorFoundAt: true,
          fixedAt: true,
          uploadedAt: true,
          liveAt: true,
          liveAsin: true,
          sourceNote: true,
          dropReason: true,
          reviewedAt: true,
          reviewedBy: { select: { fullName: true, role: true } },
          assignedTo: { select: { empCode: true, fullName: true } },
          // ⭐ কে "শেষ" বলেছেন — বরাদ্দ পাওয়া মানুষ আর শেষ করা মানুষ
          //    এক না-ও হতে পারে (মালিক নিজেও চাপতে পারেন)
          completedBy: { select: { fullName: true, role: true } },
          /**
           * ⭐ কে এনেছেন *(২৫ আগস্ট)* — ভূমিকাসহ, কারণ পর্দায় "গবেষক
           * এনেছেন" আর "মালিক এনেছেন" দুটো আলাদা খবর।
           *
           * ⚠️ relation-টা স্কিমায় **আগে থেকেই ছিল** (`addedTargets`),
           * শুধু কখনো তোলা হয়নি — তাই কোনো মাইগ্রেশন লাগেনি।
           */
          addedBy: { select: { fullName: true, role: true } },
          addedAt: true,
        },
        /**
         * ⭐⭐ **শেষ যা ঘটেছে, সেটাই আগে** *(২৩ আগস্ট ২০২৬)*।
         *
         * ⚠️⚠️ আগে ছিল `id desc` — অর্থাৎ **কবে যোগ হয়েছে**, কবে কাজ
         * হয়েছে নয়। ৩১,৩১১টা `done` সারির মাঝে দশ মিনিট আগে করা একটা
         * ভুল যেকোনো জায়গায় থাকত, আর খুঁজে পাওয়া যেত না।
         *
         * ⚠️ `id` দ্বিতীয় ধাপ হিসেবে রাখা — একই মুহূর্তে জমা হওয়া
         * সারিগুলোর ক্রম যাতে প্রতিবার এক থাকে (নইলে পাতা বদলালে
         * একই সারি দুবার বা শূন্যবার দেখা যেত)।
         */
        orderBy: query.stage === 'to_review' || query.status === 'skipped'
          ? [{ skipReviewPending: 'desc' }, { skipRequestedAt: { sort: 'desc', nulls: 'last' } }, { id: 'desc' }]
          : [{ lastActivityAt: 'desc' }, { id: 'desc' }],
        skip: (page - 1) * TARGET_PAGE_SIZE,
        take: TARGET_PAGE_SIZE,
      }),
    ]);

    /**
     * ⭐ কেবল **পর্দায় থাকা** সারিগুলোর জন্য — ৫০টা নম্বর, ৫০টা
     * ইনডেক্স-লুকআপ। গোটা টেবিল কখনো পড়া হয় না।
     */
    const seconds = await this.trace.secondsFor(
      rows.map((r) => r.jobNumber).filter((n): n is number => n !== null),
    );

    return {
      traceSince,
      rows: rows.map((r) => ({
        id: r.id,
        asin: r.asin,
        url: amazonUrl(r.asin),
        status: r.status,
        jobNumber: r.jobNumber,
        assignedTo: r.assignedTo,
        assignedAt: r.assignedAt?.toISOString() ?? null,
        startedAt: r.startedAt?.toISOString() ?? null,
        completedAt: r.completedAt?.toISOString() ?? null,
        completedVia: r.completedVia,
        fileSec: fileSecOf(r, seconds, since),
        completedBy: r.completedBy,
        addedBy: r.addedBy,
        addedAt: r.addedAt.toISOString(),
        checkedAt: r.checkedAt?.toISOString() ?? null,
        errorFoundAt: r.errorFoundAt?.toISOString() ?? null,
        fixedAt: r.fixedAt?.toISOString() ?? null,
        uploadedAt: r.uploadedAt?.toISOString() ?? null,
        liveAt: r.liveAt?.toISOString() ?? null,
        liveAsin: r.liveAsin,
        sourceNote: r.sourceNote,
        dropReason: r.dropReason,
        skipReviewPending: r.skipReviewPending,
        skipRequestedAt: r.skipRequestedAt?.toISOString() ?? null,
        reviewedAt: r.reviewedAt?.toISOString() ?? null,
        reviewedBy: r.reviewedBy,
      })),
      total,
      page,
      pages: Math.max(1, Math.ceil(total / TARGET_PAGE_SIZE)),
    };
  }

  /**
   * ⭐⭐ **তালিকা সম্পাদনা** *(২৩ আগস্ট, মালিকের চাওয়া)* — owner ·
   * manager · গবেষক।
   *
   * ⚠️⚠️ **ASIN বদলানো যায় না, আর সেটা ইচ্ছাকৃত।** ওটা সারিটার
   * **পরিচয়** — বদলালে ডুপ্লিকেট-প্রহরীর গোটা ভিত্তিটাই নড়ে যেত, আর
   * ইতিহাসে "এই পণ্যটা হয়েছিল" কথাটা মিথ্যা হয়ে যেত। ভুল ASIN হলে
   * সারিটা মুছে নতুন করে জমা দিন।
   *
   * ⭐ যা বদলানো যায়: **অবস্থা**। পুলে ফেরত পাঠানো (কারো হাত থেকে
   * তুলে নেওয়া), শেষ বলে চিহ্ন দেওয়া, বা বাদ দেওয়া।
   */
  async update(
    id: number,
    status: DesignTargetStatus,
    now: Date,
    userId: number,
  ): Promise<{ ok: boolean }> {
    /**
     * ⚠️ পুলে ফেরত পাঠানো মানে **মালিকানাও ছেড়ে দেওয়া** — নইলে সারিটা
     * পুলে থেকেও কারো নামে বাঁধা থাকত, আর পরের বণ্টনে দুজনের হাতে
     * পড়ার পথ খুলে যেত।
     * ⚠️ কাজের নম্বর মুছি না — ওটা ASIN-এর, বরাদ্দের নয়।
     */
    const data =
      status === DesignTargetStatus.pool
        ? {
            status,
            assignedToId: null,
            assignedAt: null,
            startedAt: null,
            completedAt: null,
            completedVia: null,
            // ⚠️ এটাও মুছতে হয় — নইলে পুলে ফেরত যাওয়া সারিতে "কে শেষ
            //    করেছিল" লেখা থেকে যেত, অথচ কাজটা আর শেষ নয়
            completedById: null,
            /**
             * ⚠️⚠️ **কারণটাও মুছে যায়** *(৩১ আগস্ট ২০২৬)*। সারিটা আবার
             * পুলে ফিরছে মানে "Not Found" কথাটা আর সত্যি নয় — কেউ দেখে
             * নিয়েছেন যে পাতাটা আছে, বা ভুল করে মোছা হয়েছিল। ⭐ কারণ
             * রেখে দিলে পরের বার কেউ বণ্টন পেয়ে দেখতেন সারিটা
             * "Copyright" বলে দাগানো, অথচ সেটা মীমাংসিত।
             */
            dropReason: null,
            skipRequestedAt: null,
            /**
             * ⚠️⚠️ **"দেখা হয়েছে" চিহ্নটাও মুছে যায়** *(৩১ আগস্ট)*। সারিটা
             * পুলে ফিরছে মানে সেটা আর বাদ-যাওয়া নয়, অর্থাৎ ম্যানেজার কী
             * দেখেছিলেন তার কোনো বিষয়ই আর নেই। ⭐ রেখে দিলে ভবিষ্যতে কেউ
             * আবার Skip করলে সারিটা **কিউতেই উঠত না** — পুরোনো একটা
             * চিহ্নের কারণে নতুন সমস্যা চাপা পড়ত।
             */
            reviewedAt: null,
            reviewedById: null,
            // A new assignment must pass through the workflow again.
            checkedAt: null,
            checkedById: null,
            errorFoundAt: null,
            fixedAt: null,
            fixedById: null,
            uploadedAt: null,
            liveAt: null,
            liveAsin: null,
          }
        : status === DesignTargetStatus.done
          ? { status, completedAt: now, completedVia: 'manual', completedById: userId }
          : { status };

    const { count } = await targetWrite(this.prisma, userId, 'manual', tx => tx.designTarget.updateMany({
      where: {
        id,
        // A retry must not move yesterday's completion into today's count.
        skipReviewPending: false,
        ...(status === DesignTargetStatus.done
          ? { status: { not: DesignTargetStatus.done } }
          : {}),
      },
      data,
    }));
    if (count > 0) return { ok: true };
    if (status === DesignTargetStatus.done) {
      const existing = await this.prisma.designTarget.findUnique({
        where: { id }, select: { status: true },
      });
      return { ok: existing?.status === DesignTargetStatus.done };
    }
    return { ok: false };
  }

  /**
   * ⭐⭐ **মুছে ফেলা — সারিটা থাকে, কেবল মরা বলে দাগানো হয়**
   * *(মালিকের রিপোর্ট, ২৯ আগস্ট ২০২৬: "pool er kiso asin amazon e page
   * nei… delete korle delete hisabe pool e thakobe but karo kase
   * distribute hobena")*।
   *
   * ⚠️⚠️ **আগে এটা সত্যিকারের `DELETE` ছিল, আর তাতেই বাগটা।** সারি
   * উধাও হলে `asin` UNIQUE প্রহরীও উধাও — কাল কেউ ওই মরা ASIN আবার
   * পেস্ট করলে নতুন কাজ হিসেবে ঢুকত, বণ্টনে যেত, আর ডিজাইনার আবার গিয়ে
   * দেখতেন "Sorry, not found"। ⭐ পুরোনো টীকায় দামটা লেখাই ছিল, শুধু
   * বিকল্পটা ছিল না; এখন `deleted` অবস্থাটাই সেই বিকল্প।
   *
   * ⚠️⚠️ **শেষ হয়ে যাওয়া সারি ছোঁয়া হয় না।** `done` মানে কেউ সত্যিই
   * ডিজাইনটা বানিয়েছেন — ওটা মুছলে তাঁর দিনের গোনা কমে যেত, আর
   * আপলোডের কিউ থেকেও জিনিসটা নীরবে হারাত। ⭐ ভুল করে বেছে ফেললে কী
   * হলো সেটা `keptDone` ধরে পর্দায় বলা হয়, চুপ করে বাদ দেওয়া হয় না।
   *
   * ⭐ **হাতে থাকা (`assigned`) সারি মোছা যায়, আর সেটাই সবচেয়ে দরকারি
   * ক্ষেত্র** — ডিজাইনার লিঙ্কটা খুলে তবেই বুঝতে পারেন পাতাটা নেই।
   * ⚠️ `assignedToId` মোছা হয় না (কার হাতে ছিল সেটা ইতিহাস), কিন্তু
   * অবস্থা বদলে যাওয়ায় সারিটা তাঁর তালিকা থেকে সরে যায় আর তাঁর
   * "হাতে ৩০টা"-র গোনাতেও পড়ে না — অর্থাৎ পরের বণ্টনে বদলিটা এমনিতেই
   * এসে যায়।
   */
  async softDelete(
    ids: readonly number[],
    userId: number,
    ip: string,
    reason: DropReason,
  ): Promise<DeleteResult> {
    // ⚠️ একই id দুবার এলে দুবার গোনা হতো — পর্দায় সংখ্যাটা তখন বাড়িয়ে দেখাত
    const wanted = [...new Set(ids)];
    if (wanted.length === 0) return { deleted: 0, keptDone: 0 };

    // Eligibility belongs in the write: a designer may complete work while
    // this request is in flight. RETURNING also makes audit IDs match actual writes.
    const deleted = await targetWrite(this.prisma, userId, 'manual', tx => tx.designTarget.updateManyAndReturn({
      where: {
        id: { in: wanted },
        skipReviewPending: false,
        status: { notIn: [DesignTargetStatus.done, DesignTargetStatus.deleted] },
      },
      data: { status: DesignTargetStatus.deleted, dropReason: reason },
      select: { id: true },
    }));
    const count = deleted.length;
    const keptDone = await this.prisma.designTarget.count({
      where: { id: { in: wanted }, status: DesignTargetStatus.done },
    });

    if (count > 0) {
      await this.audit.record({
        userId,
        action: 'design_deleted',
        targetType: 'design_targets',
        targetId: deleted.length === 1 ? String(deleted[0].id) : 'bulk',
        ipAddress: ip,
        // ⚠️ ASIN-গুলো নয়, সংখ্যাগুলো — তালিকাটা টেবিলেই আছে (`bulkAdd`-এর একই নিয়ম)
        meta: { deleted: count, keptDone, asked: wanted.length, reason },
      });
    }

    return { deleted: count, keptDone };
  }

  /** পুলের অবস্থা — ইনবক্সের পর্দায় */
  /**
   * ⭐ **ছাঁকনির ড্রপডাউনের জন্য ডিজাইনারের তালিকা** *(২৩ আগস্ট ২০২৬)*।
   *
   * ⚠️⚠️ সাধারণ স্টাফ-তালিকার রুট ব্যবহার করা যেত না — ওটা owner/manager
   * only, অথচ এই পাতা **গবেষকও** দেখেন। তাই আলাদা, আর এখানে কেবল
   * নাম-কোড যায়; বেতন বা ফোন নম্বরের মতো কিছু নয়।
   *
   * ⚠️ ছেড়ে যাওয়া কর্মীও থাকেন — তাঁদের নামেই পুরোনো টার্গেট বাঁধা,
   *    আর ছাঁকনি থেকে বাদ দিলে ওই সারিগুলো কোনোদিন খুঁজে পাওয়া যেত না।
   */
  async designers(): Promise<{ id: number; empCode: string; fullName: string }[]> {
    return this.prisma.employee.findMany({
      where: { designTargets: { some: {} } },
      select: { id: true, empCode: true, fullName: true },
      orderBy: { empCode: 'asc' },
    });
  }

  /**
   * ⭐⭐ **কে কতগুলো টার্গেট এনেছেন** *(মালিকের চাওয়া, ২৫ আগস্ট:
   * "Design Pool e ke target list add koreche seta ami dekhote cai")*।
   *
   * ⚠️ সংখ্যাটা ড্রপডাউনেই দেখানো হয়, আর সেটাই আসল উত্তর: মালিক একটাও
   * ক্লিক না করে দেখেন কে কতটা এনেছেন। ছাঁকনিটা তার পরের ধাপ।
   *
   * ⚠️⚠️ `designers()`-এর মতো `employees` নয়, **`users`** — টার্গেট আনেন
   * ব্যবহারকারী (মালিক · ম্যানেজার · গবেষক), আর মালিকের কোনো
   * `employees` সারিই নেই। ওই টেবিল ধরে খুঁজলে ৩৯ হাজার সারির উৎসটাই
   * তালিকা থেকে উধাও হয়ে যেত।
   */
  async adders(): Promise<
    { id: number; fullName: string; role: UserRole; count: number }[]
  > {
    const grouped = await this.prisma.designTarget.groupBy({
      by: ['addedById'],
      _count: { _all: true },
    });
    if (grouped.length === 0) return [];

    const users = await this.prisma.user.findMany({
      where: { id: { in: grouped.map((g) => g.addedById) } },
      select: { id: true, fullName: true, role: true },
    });
    const countOf = new Map(grouped.map((g) => [g.addedById, g._count._all]));

    return users
      .map((u) => ({ ...u, count: countOf.get(u.id) ?? 0 }))
      // ⭐ যিনি সবচেয়ে বেশি এনেছেন তিনি আগে — তালিকাটা ছোট (আজ ৩ জন)
      .sort((a, b) => b.count - a.count);
  }

  async stats(): Promise<
    Record<DesignTargetStatus, number> & {
      perDesigner: number;
      uploaded: number;
      live: number;
      /** ⭐ বানান দেখা বাকি (ADR-038) */
      toCheck: number;
      /** ⭐ ভুল পাওয়া গেছে, ঠিক করা হয়নি */
      toFix: number;
      /** ⭐ গবেষকের কিউ — শেষ হয়েছে অথচ আপলোড হয়নি (কাটা-তারিখের পরের) */
      toUpload: number;
      /** ⭐ আপলোড হয়েছে অথচ লাইভ হয়নি */
      toLive: number;
    }
  > {
    /**
     * ⭐⭐ **আপলোড ও লাইভ আলাদা করে গোনা** *(২৩ আগস্ট ২০২৬)*।
     *
     * ⚠️ `status` দিয়ে গোনা যায় না — ওগুলো তারিখ, অবস্থা নয় (ইচ্ছাকৃত,
     * schema-র নোট দেখুন)। একটা কাজ একই সাথে `done` **আর** আপলোড **আর**
     * লাইভ হতে পারে, আর সেটাই ঠিক।
     */
    const [rows, uploaded, live, toCheck, toFix, toUpload, toLive, toReview] =
      await Promise.all([
      this.prisma.designTarget.groupBy({
        by: ['status'],
        _count: { _all: true },
      }),
      this.prisma.designTarget.count({ where: { uploadedAt: { not: null } } }),
      this.prisma.designTarget.count({ where: { liveAt: { not: null } } }),
      /**
       * ⚠️⚠️ এই দুটো সংখ্যা **`list()`-এর ছাঁকনির হুবহু যমজ** হতে হবে —
       * চিপে ১৩২ লিখে ক্লিক করলে ৯০টা এলে কেউ আর সংখ্যাটা বিশ্বাস করবে না।
       * ⭐ কাটা-তারিখটা এক জায়গায় (`UPLOAD_QUEUE_FROM`), তাই দুটো একসাথেই নড়ে।
       */
      this.prisma.designTarget.count({
        where: {
          completedAt: { not: null, gte: dhakaStart(UPLOAD_QUEUE_FROM) },
          checkedAt: null,
        },
      }),
      this.prisma.designTarget.count({
        where: { errorFoundAt: { not: null }, fixedAt: null },
      }),
      this.prisma.designTarget.count({
        where: {
          completedAt: { not: null, gte: dhakaStart(UPLOAD_QUEUE_FROM) },
          uploadedAt: null,
          // ⚠️ ভুল পাওয়া অথচ ঠিক-না-হওয়া সারি বাদ — `list()`-এর যমজ
          NOT: { errorFoundAt: { not: null }, fixedAt: null },
        },
      }),
      this.prisma.designTarget.count({
        where: { uploadedAt: { not: null }, liveAt: null },
      }),
      // ⭐ `list()`-এর `to_review` শর্তের যমজ — দুটো আলাদা হলে চিপের সংখ্যা
      //    আর তালিকার সংখ্যা মিলত না (২৪ আগস্টের শিক্ষা)
      this.prisma.designTarget.count({
        where: {
          OR: [{ skipReviewPending: true }, { status: {
            in: [DesignTargetStatus.skipped, DesignTargetStatus.deleted],
          } }],
          dropReason: { not: null },
          reviewedAt: null,
        },
      }),
    ]);

    const out = {
      pool: 0,
      assigned: 0,
      done: 0,
      skipped: 0,
      /**
       * ⭐ মরা ASIN — Amazon-এ পাতাটাই নেই *(২৯ আগস্ট)*।
       *
       * ⚠️⚠️ শূন্যগুলো এখানে **হাতে লেখা, আর সেটাই ইচ্ছাকৃত**: টাইপটা
       * `Record<DesignTargetStatus, number>`, তাই enum-এ নতুন মান বসলে
       * টাইপচেক এখানে থামে। ⭐ ২৯ আগস্ট ঠিক তা-ই হয়েছে — নইলে নতুন
       * অবস্থাটা গোনার বাইরে থেকে যেত আর পর্দায় কেউ টেরও পেত না।
       */
      deleted: 0,
      perDesigner: POOL_PER_DESIGNER,
      uploaded,
      live,
      toCheck,
      toFix,
      toUpload,
      toLive,
      toReview,
    };
    for (const r of rows) out[r.status] = r._count._all;

    return out;
  }

  /**
   * ⭐ **"আপলোড হয়েছে"** — owner · manager · গবেষক *(২৩ আগস্ট ২০২৬)*।
   *
   * ⚠️ শেষ হওয়ার আগে আপলোড হতে পারে না, তাই `completedAt` না থাকলে
   *    আটকানো হয় — নইলে পাইপলাইনের ক্রমটাই অর্থহীন হতো।
   */
  /**
   * ⭐⭐ **"বানান দেখলাম"** *(ADR-038, ২৫ আগস্ট ২০২৬)* — সুমাইয়ার দুটো
   * বোতামের পেছনের একটাই মেথড।
   *
   * ⚠️⚠️ **যন্ত্র বানান পড়ে না** — লেখাটা `.ai`/`.psd`-র ভেতরে, আর
   * নীতিমালায় প্রতিশ্রুতি দেওয়া আছে ফাইল খোলা হয় না। ⭐ যন্ত্র শুধু
   * **হিসাব রাখে**: কোনগুলো দেখা বাকি, কে দেখলেন, কী পেলেন। মাঠে আসল
   * সমস্যাটাও এটাই — ভুল খোঁজা নয়, *কোনগুলো দেখতে হবে* সেটা জানা।
   *
   * ⚠️ `ok: false` মানে ভুল পাওয়া গেছে — তখন `errorFoundAt`ও বসে, আর
   *    সারিটা "ঠিক করতে হবে" কিউতে চলে যায়।
   *
   * ⚠️ **idempotent** — আবার চাপলে তারিখ সরে না। নইলে একই সারিতে দুবার
   *    চাপলে "কবে দেখা হয়েছিল" আজকের তারিখে লাফ দিত।
   */
  async markChecked(
    id: number,
    ok: boolean,
    userId: number,
    now: Date,
  ): Promise<{ ok: true }> {
    return this.advanceStage(id, 'completedAt', 'checkedAt', {
        checkedAt: now,
        checkedById: userId,
        errorFoundAt: ok ? null : now,
      }, 'This design is not finished yet, so there is nothing to check.', userId);
  }

  /**
   * ⭐⭐ **"ঠিক করেছি"** — বেলালের বোতাম।
   *
   * ⚠️⚠️ `assignedToId` **ছোঁয়া হয় না**। ডিজাইনটা মূল ডিজাইনারেরই থাকে,
   * আর সেটা এই মেথডের সবচেয়ে জরুরি লাইন — নইলে যিনি ঠিক করলেন তাঁর নামে
   * কাজটা চলে যেত, আর ২৩ আগস্টের গোটা তদন্তটা শুরুই হয়েছিল ঠিক এমন
   * একটা ফুলে যাওয়া সংখ্যা দেখে ("বেলাল ১৬টা ডিজাইন করেছে?")।
   */
  async markFixed(id: number, userId: number, now: Date): Promise<{ ok: true }> {
    return this.advanceStage(id, 'errorFoundAt', 'fixedAt',
      { fixedAt: now, fixedById: userId },
      'No spelling error was recorded for this design, so there is nothing to fix.', userId);
  }

  /**
   * ⭐⭐ **"দেখে নিয়েছি"** *(মালিকের চাওয়া, ৩১ আগস্ট ২০২৬)* — মালিক ও
   * ম্যানেজারের কিউ খালি করার একমাত্র পথ।
   *
   * ⚠️⚠️ **সারিটার অবস্থা বদলায় না** — `skipped` `skipped`-ই থাকে। এটা
   * কোনো সিদ্ধান্ত নয়, একটা **স্বীকৃতি**: "আমি দেখেছি"। ⭐ সিদ্ধান্ত
   * নিতে চাইলে পাশের বোতামটা আছে (পুলে ফেরত), আর সেটা আলাদা কাজ।
   *
   * ⚠️ কেবল বাদ-যাওয়া ও কারণসহ সারিতেই চলে — নইলে যেকোনো সারিতে চিহ্ন
   * বসিয়ে দেওয়া যেত, আর ঘরটার মানে হারাত।
   */
  async markReviewed(
    id: number,
    userId: number,
    now: Date,
  ): Promise<{ ok: boolean }> {
    const { count } = await targetWrite(this.prisma, userId, 'manual', tx => tx.designTarget.updateMany({
      where: {
        id,
        status: { in: [DesignTargetStatus.skipped, DesignTargetStatus.deleted] },
        dropReason: { not: null },
      },
      data: { reviewedAt: now, reviewedById: userId },
    }));

    return { ok: count > 0 };
  }

  async markUploaded(id: number, now: Date, userId: number | null = null): Promise<{ ok: true }> {
    return this.advanceStage(id, 'completedAt', 'uploadedAt', { uploadedAt: now },
      'This design is not finished yet, so it cannot be marked uploaded.', userId);
  }

  /**
   * ⭐⭐ **"Amazon-এ লাইভ হয়েছে"** — সাথে নতুন পণ্যের ASIN।
   *
   * ⚠️⚠️ ASIN-টা **আমাদের নিজের** পণ্যের, গবেষকের আনা নমুনার নয়। এটাই
   * ভবিষ্যতে বিক্রির হিসাবের সাথে জোড়া লাগার সেতু।
   *
   * ⚠️ আপলোড না হয়ে লাইভ হতে পারে না — Amazon-এ কিছু ওঠাতে হলে আগে
   *    পাঠাতেই হয়।
   */
  async markLive(id: number, liveAsin: string | null, now: Date, userId: number | null = null): Promise<{ ok: true }> {
    return this.advanceStage(id, 'uploadedAt', 'liveAt', { liveAt: now, liveAsin },
      'This design has not been uploaded yet, so it cannot be live.', userId);
  }

  /** Prerequisites and idempotency must hold at write time, not at an earlier read. */
  private async advanceStage(
    id: number,
    prerequisite: 'completedAt' | 'errorFoundAt' | 'uploadedAt',
    stage: 'checkedAt' | 'fixedAt' | 'uploadedAt' | 'liveAt',
    data: Prisma.DesignTargetUncheckedUpdateManyInput,
    invalidMessage: string,
    userId: number | null,
  ): Promise<{ ok: true }> {
    const { count } = await targetWrite(this.prisma, userId, 'manual', tx => tx.designTarget.updateMany({
      where: { id, status: DesignTargetStatus.done, skipReviewPending: false,
        [prerequisite]: { not: null }, [stage]: null,
        ...(stage === 'uploadedAt' ? { OR: [{ errorFoundAt: null }, { fixedAt: { not: null } }] } : {}),
      },
      data,
    }));
    if (count > 0) return { ok: true };
    const target = await this.prisma.designTarget.findUnique({
      where: { id },
      select: { status: true, skipReviewPending: true, completedAt: true, errorFoundAt: true, uploadedAt: true,
        checkedAt: true, fixedAt: true, liveAt: true },
    });
    if (!target) throw new NotFoundException('No design target with this id');
    if (target.status !== DesignTargetStatus.done || target.skipReviewPending)
      throw new BadRequestException('Only completed designs can advance through production stages.');
    if (target[prerequisite] === null) throw new BadRequestException(invalidMessage);
    if (stage === 'uploadedAt' && target.errorFoundAt !== null && target.fixedAt === null)
      throw new BadRequestException('Fix the recorded spelling error before uploading this design.');
    if (target[stage] !== null) return { ok: true };
    throw new ConflictException('This design changed during the request. Please try again.');
  }
}
