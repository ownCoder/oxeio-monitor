import { Link } from 'react-router-dom';

import { getMyDays, getMyDeposit, getMySummary, type MyDay } from '../api/me';
import { useApi } from '../api/useApi';
import { useAuth } from '../auth/AuthContext';
import { MyTargets } from './MyTargets';
import { Card, Stat, StatRow } from '../components/Card';
import { Duration } from '../components/Duration';
import { Page } from '../components/Page';
import { ProgressBar, ProgressRing } from '../components/ProgressRing';
import { Empty, ErrorBox, Loading } from '../components/States';
import { Table } from '../components/Table';
import {
  formatDate,
  formatDateShort,
  formatSignedDuration,
  shiftWorkDate,
  todayInDhaka,
  weekdayOf,
} from '../lib/format';
import { Adjustments } from './employee/Adjustments';

/**
 * **J05 · J08 · ADR-011e** — স্টাফের নিজের পাতা।
 *
 * ⚠️⚠️ tray-র মেনুতে **"My data"** আইটেমটা প্রথম দিন থেকেই ছিল, আর সেটা
 * চাপলে ব্রাউজার খুলে ৪০৪ দেখাত — পাতাটা কোনোদিন বানানোই হয়নি। অর্থাৎ
 * স্বচ্ছতার প্রতিশ্রুতিটা প্রতিদিন স্টাফের চোখের সামনে ছিল, আর
 * প্রতিদিনই ভাঙত।
 *
 * ⭐ <b>পাতাটার একটাই কাজ: "আমার সম্পর্কে সিস্টেম কী জানে" — এক জায়গায়।</b>
 * তাই এখানে চারটে জিনিস, আর তার বেশি কিছু নয়:
 *   ১· আজ ও মাসের ঘণ্টা (tray-র হুবহু একই সংখ্যা)
 *   ২· দিনে দিনে তালিকা — ছুটিসহ, ফাঁকা দিনসহ
 *   ৩· ঘণ্টা-সংশোধন, কারণসহ (J08)
 *   ৪· নিজের ছবি ও নীতিমালার শর্ত
 *
 * ⚠️ **কোনো বোতাম নেই** — না "সময় দাবি করুন", না "ব্যাখ্যা দিন"। একটা
 * বসালেই সেটা approval workflow-র প্রথম ধাপ হতো, যেটা এই সিস্টেমে
 * ইচ্ছাকৃতভাবে নেই (ADR-011d)। tray জানালাতেও ঠিক এই কারণেই কোনো বোতাম
 * নেই।
 */
export function MyDataPage() {
  const { user } = useAuth();
  const today = todayInDhaka();

  /**
   * ⚠️ owner ও manager-এর `users.employee_id` সাধারণত null — তাঁরা কর্মীর
   * সারিতে বাঁধা নন। সার্ভার তাঁদের ৪০৩ বলে, কিন্তু সেটা পর্দায় আসত
   * *"You don't have access"* হয়ে — অথচ owner-এর কাছে ওই বাক্যটা
   * বিভ্রান্তিকর (তাঁর তো সবেতেই access)। আসল কথাটা অন্য: **তাঁর নিজের
   * বলে কোনো ঘণ্টা নেই**। তাই রিকোয়েস্টটা পাঠানোই হয় না।
   */
  const linked = user?.employeeId != null;

  const summary = useApi(
    (signal) => (linked ? getMySummary(signal) : Promise.resolve(null)),
    [linked],
  );

  /**
   * ⚠️ **রোলিং ৩০ দিন, "চলতি মাস" নয়।** মাসের ১ তারিখে চলতি-মাস দেখালে
   * তালিকায় একটাই সারি থাকত, আর ঠিক তখনই মানুষ গত মাসের শেষ দিনগুলো
   * মেলাতে চায়। উপরের সংখ্যাগুলো অবশ্য মাসেরই — ওটাই চুক্তির একক (O8)।
   */
  const from = shiftWorkDate(today, -29);
  const days = useApi(
    (signal) => (linked ? getMyDays(from, today, signal) : Promise.resolve([])),
    [linked, from, today],
  );

  /**
   * ⭐⭐ **R21 — নিজের জামানত।** মালিকের চাওয়া ছিল ঠিক এটাই: *"প্রতিটা
   * স্টাফ তার ড্যাশবোর্ডে তার কত টাকা জমল সেটাও দেখতে পাবে"*।
   *
   * ⚠️ আলাদা কল, `summary`-র সাথে জোড়া নয় — জামানত না থাকলেও (নিয়ম বন্ধ,
   * বা তিনি নতুন) বাকি পাতাটা যেন দিব্যি চলে। এক কলে মিশিয়ে দিলে একটার
   * ব্যর্থতা অন্যটাকেও ফাঁকা করে দিত।
   */
  const deposit = useApi(
    (signal) => (linked ? getMyDeposit(signal) : Promise.resolve(null)),
    [linked],
  );

  const p = summary.data?.progress;

  return (
    <Page
      title="My data"
      subtitle={
        summary.data
          ? `${summary.data.employee.fullName} · ${summary.data.employee.empCode}`
          : (user?.fullName ?? '')
      }
    >
      {!linked && (
        <Empty
          title="This account has no hours of its own"
          hint="Owner and manager accounts are not linked to a staff record, so there is nothing personal to show here. Staff see their own hours on this page."
        />
      )}

      {linked && summary.loading && <Loading />}
      {linked && summary.error && (
        <ErrorBox error={summary.error} retry={summary.reload} />
      )}

      {p && summary.data && (
        <div className="space-y-4">
          <StatRow>
            <Stat
              label="Today"
              value={<Duration seconds={p.todayActiveSec} />}
            />
            <Stat
              label="This month"
              value={<Duration seconds={p.monthActiveSec} />}
              unit={`/ ${p.monthlyTargetHours}h`}
            />
            <Stat
              label="Last 7 days"
              value={<Duration seconds={p.week7ActiveSec} />}
            />
            {/*
              ⭐ পুরো পাতায় **একটাই** সম্ভাব্য লাল টাইল — পিছিয়ে থাকা।
              ⚠️ এগিয়ে থাকলে লাল নয়; সব টাইল লাল করলে লালের মানেই হারায়।
            */}
            {/*
              ⭐⭐ **G111** — "এখনো দেখা হয়নি" আর "এগিয়ে আছি" এক নয়।
              ⚠️⚠️ আগে এই টাইল নতুন কর্মীর প্রথম দিনে "Ahead 0s" দেখাত।
                 সংখ্যাটা মিথ্যা ছিল না, বাক্যটা ছিল — কারণ তাঁর একটাও
                 শেষ-হওয়া কর্মদিবস তখনো দেখা হয়নি।
            */}
            {p.observed ? (
              <Stat
                label={p.paceSec < 0 ? 'Behind' : 'Ahead'}
                value={formatSignedDuration(p.paceSec)}
                tone={p.paceSec < 0 ? 'attention' : 'counted'}
              />
            ) : (
              <Stat
                label="Pace"
                value="Not observed yet"
                tone="muted"
                sub="no finished workday counted for you yet"
              />
            )}
          </StatRow>

          {/*
            ⭐⭐ **নিজের ডিজাইন-টার্গেট** *(২২ আগস্ট)* — সবার উপরে, কারণ
               ডিজাইনারের রোজকার কাজ এখান থেকেই শুরু হয়।
            ⚠️ যাঁর কোনো টার্গেট নেই তাঁর পাতায় কার্ডটা **বসেই না** —
               গবেষকের পাতায় একটা খালি বাক্স বসিয়ে লাভ নেই।
          */}
          <MyTargets />

          <div className="grid gap-4 lg:grid-cols-2">
            <Card
              title="Where You Are"
              hint="The same numbers your tray icon shows"
            >
              <div className="flex flex-wrap items-center gap-6">
                <div className="flex items-center gap-3">
                  <ProgressRing
                    value={p.monthActiveSec}
                    max={p.monthlyTargetHours * 3600}
                    size={64}
                    ariaLabel="This month"
                  />
                  <div className="text-[13px]">
                    <div className="font-medium">This month</div>
                    <div className="text-ink-3">
                      <Duration seconds={p.monthActiveSec} /> of{' '}
                      {p.monthlyTargetHours}h
                    </div>
                  </div>
                </div>

                <div className="min-w-[180px] flex-1 space-y-3">
                  {/*
                    ⚠️ ছুটির দিনে দৈনিক টার্গেট ০ — তখন খালি বার নয়, একটা
                       বাক্য। খালি বার "আজও ৮ ঘণ্টা বাকি" বলে তাড়া দিত,
                       অথচ আজ কিছু করার কথাই নেই। tray জানালাতেও একই নিয়ম।
                  */}
                  {p.dailyTargetSec > 0 ? (
                    <Line
                      label="Today"
                      value={p.todayActiveSec}
                      max={p.dailyTargetSec}
                    />
                  ) : (
                    <p className="text-[13px] text-ink-2">
                      Today is a day off — nothing is expected. Anything you do
                      work still counts.
                    </p>
                  )}

                  <Line
                    label="Last 7 days"
                    value={p.week7ActiveSec}
                    max={p.week7TargetSec}
                  />
                </div>
              </div>
            </Card>

            {/*
              ⭐ **স্বচ্ছতার ঘর।** নীতিমালায় স্টাফকে যা লিখিতভাবে বলা
              হয়েছে, তার সংখ্যাগুলো এখানেই — খুঁজতে যেতে হয় না।
              ⚠️ ছবির মেয়াদ সার্ভার থেকে আসে, হাতে লেখা নয়; নীতি বদলালে
                 পাতাটা পুরোনো প্রতিশ্রুতি দেখাত।
            */}
            {/*
              ⭐⭐ **R21 — জমা কত।** ⚠️ কার্ডটা তখনই দেখা যায় যখন সত্যিই
                 কিছু জমেছে (বা নিষ্পত্তি হয়েছে) — শূন্য নিয়ে একটা কার্ড
                 বসিয়ে রাখলে সেটা কেবল প্রশ্ন তৈরি করত।
              ⚠️ এখানে বেতনের কোনো সংখ্যা নেই, আর সেটা নিয়ম ভাঙে না:
                 অঙ্কটা তাঁর নিজের টাকা, বেতনের হিসাব নয়। এটা থেকে কারো
                 বেতন বের করা যায় না।
            */}
            {deposit.data &&
              (deposit.data.totalPaisa > 0 || deposit.data.settlement) && (
                <Card
                  title="Security Deposit"
                  hint={
                    deposit.data.settlement
                      ? 'Settled — this is the record'
                      : `Held from your salary · ${deposit.data.months.length} ${
                          deposit.data.months.length === 1 ? 'month' : 'months'
                        }`
                  }
                >
                  <div className="num text-[26px] font-semibold">
                    {deposit.data.settlement
                      ? deposit.data.settlement.amount
                      : deposit.data.total}
                  </div>

                  {deposit.data.settlement ? (
                    <p className="mt-1 text-[13px] text-ink-2">
                      {deposit.data.settlement.outcome === 'refunded'
                        ? 'Refunded to you'
                        : 'Not refunded — the notice period was short'}
                      {deposit.data.settlement.note &&
                        ` · ${deposit.data.settlement.note}`}
                    </p>
                  ) : (
                    <p className="mt-1 text-[13px] text-ink-2">
                      This is your money, held back each month. You get all of
                      it when you leave, as long as you give at least{' '}
                      {deposit.data.noticeDays} days&apos; notice.
                    </p>
                  )}

                  {/*
                    ⭐ মাস ধরে তালিকাটাও থাকে — "কোন মাসে কাটা হয়েছে"
                       প্রশ্নের উত্তর নিজের পাতাতেই থাকা দরকার, নইলে
                       মিলিয়ে দেখতে মালিকের কাছে যেতে হতো।
                  */}
                  {deposit.data.months.length > 0 && (
                    <ul className="mt-3 divide-y divide-line border-t border-line text-[13px]">
                      {deposit.data.months.map((m) => (
                        <li
                          key={m.yearMonth}
                          className="flex items-baseline justify-between py-1.5"
                        >
                          <span className="num text-ink-2">{m.yearMonth}</span>
                          <span className="num">{m.amount}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </Card>
              )}

            <Card title="What Is Recorded" hint="And for how long">
              <dl className="space-y-2.5 text-[13px]">
                <Row term="Screenshots">
                  Kept {summary.data.screenshotRetentionDays} days, then deleted
                  automatically —{' '}
                  <Link to="/screenshots" className="underline">
                    see yours
                  </Link>
                </Row>
                <Row term="Working hours">
                  Active time only. Idle and locked time is recorded but never
                  counted as work.
                </Row>
                <Row term="Policy signed">
                  {summary.data.policySignedAt
                    ? formatDate(summary.data.policySignedAt)
                    : 'Not recorded yet'}
                </Row>
                {summary.data.employee.joinedOn && (
                  <Row term="Joined">
                    {formatDate(summary.data.employee.joinedOn)}
                  </Row>
                )}
              </dl>
            </Card>
          </div>
        </div>
      )}

      {linked && (
        <div className="mt-4 space-y-4">
          <Card
            title="Day by Day"
            hint="Last 30 days · days off and empty days are shown too"
            padded={false}
          >
            {days.loading && <Loading />}
            {days.error && <ErrorBox error={days.error} retry={days.reload} />}
            {days.data?.length === 0 && <Empty title="Nothing recorded yet" />}
            {days.data && days.data.length > 0 && (
              <DayTable rows={days.data} monthCreditedSec={p?.monthCreditedSec} />
            )}
          </Card>

          {/*
          ⭐ J08 — নিজের সংশোধন, কারণসহ। কম্পোনেন্টটা owner-এর পাতার
          সাথে **ভাগ করা**: owner ওখানে যোগ করার বোতামও পান, স্টাফ শুধু
          তালিকাটা দেখেন (`isOwner` ভেতরেই যাচাই হয়)। দুটো আলাদা
          কম্পোনেন্ট লিখলে একদিন দুই পাতায় দুই রকম কারণ দেখাত।
        */}
          {user?.employeeId != null && (
            <Adjustments employeeId={user.employeeId} nonce={0} />
          )}
        </div>
      )}
    </Page>
  );
}

function Line({
  label,
  value,
  max,
}: {
  label: string;
  value: number;
  max: number;
}) {
  return (
    <div>
      <div className="mb-1 flex items-baseline justify-between text-[12.5px]">
        <span className="text-ink-2">{label}</span>
        <span className="text-ink-3">
          <Duration seconds={value} /> / <Duration seconds={max} />
        </span>
      </div>
      <ProgressBar value={value} max={max} ariaLabel={label} />
    </div>
  );
}

function Row({ term, children }: { term: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-wrap gap-x-2">
      <dt className="min-w-[120px] text-ink-3">{term}</dt>
      <dd className="min-w-0 flex-1 text-ink-2">{children}</dd>
    </div>
  );
}

/**
 * ⚠️⚠️ **নিচের যোগফলটা এখানে কষা হয় না** *(৬ সেপ্টেম্বর ২০২৬, G162)*।
 *
 * আগে হতো — `rows.filter(...).reduce(...)` — আর তাতে তিনটে আলাদা কারণে
 * উপরের *"This month"* টাইলের সাথে মিলত না: তালিকাটা রোলিং ৩০ দিনের
 * (৩১ তারিখে ১ তারিখটা আসতই না), সংশোধন কেবল নিচেরটায় ঢুকত, আর দুই
 * PC-তে একসাথে কাজ করলে নিচেরটা সময়টা দুবার গুনত।
 *
 * ⭐ এখন সংখ্যাটা সার্ভারের — ঠিক যেটা দিয়ে সে pace কষে।
 *
 * ⚠️ তাই এটা **উপরের সারিগুলোর যোগফল নয়**, মাসের যোগফল। মাসের ৩১
 * তারিখে তালিকা শুরু হয় ২ তারিখ থেকে, অথচ সংখ্যাটা ১ তারিখও ধরে —
 * এটাই চাওয়া, আর লেবেলটাও তাই *"This month"* বলে, "Total" নয়।
 */
function DayTable({ rows, monthCreditedSec }: {
  rows: MyDay[];
  /**
   * ⚠️ **`undefined` মানে "জানি না", ০ নয়।** উপরের সারাংশ কলটা আলাদা —
   *    সেটা ব্যর্থ হলেও এই তালিকাটা আসতে পারে। তখন ০ লিখলে পর্দা বলত
   *    "এ মাসে কিছুই করোনি", অথচ সত্যিটা "সংখ্যাটা আনা যায়নি"।
   */
  monthCreditedSec: number | undefined;
}) {
  return (
    <Table
      rows={rows}
      rowKey={(r) => r.workDate}
      // ⚠️ ছুটির দিন ম্লান — "কাজ করোনি" নয়, "করার কথা ছিল না"
      rowMuted={(r) => r.isOffDay && r.workedSec === 0}
      columns={[
        {
          key: 'date',
          header: 'Date',
          render: (r) => (
            <span className="num">
              {formatDateShort(r.workDate)}{' '}
              <span className="text-ink-3">{weekdayOf(r.workDate)}</span>
            </span>
          ),
        },
        {
          key: 'worked',
          header: 'Worked',
          align: 'right',
          render: (r) => (
            <Duration
              seconds={r.workedSec}
              tone={r.workedSec === 0 ? 'muted' : 'counted'}
            />
          ),
        },
        {
          key: 'adjust',
          header: 'Correction',
          align: 'right',
          render: (r) =>
            // ⚠️ শূন্য হলে ড্যাশ — `+0:00` লিখলে প্রতিটা সারিতে মনে হতো
            //    কিছু একটা বদলানো হয়েছে
            r.adjustmentSec === 0 ? (
              <span className="text-ink-3">—</span>
            ) : (
              <span className="num">
                {formatSignedDuration(r.adjustmentSec)}
              </span>
            ),
        },
        {
          key: 'credited',
          header: 'Counted',
          align: 'right',
          render: (r) => <Duration seconds={r.creditedSec} />,
        },
        {
          key: 'note',
          header: '',
          render: (r) =>
            r.isOffDay ? (
              <span className="text-[11.5px] text-ink-3">Day off</span>
            ) : null,
        },
      ]}
      footer={
        <tr>
          <td className="px-3 py-2 text-[12.5px] text-ink-3">
            This month so far
            {/* ⚠️ কোন কলামের যোগফল সেটা লেখা থাকে — নইলে পাঠক
                "Worked"-এর যোগফল ভেবে মেলাতে বসতেন (G162) */}
            <span className="text-ink-3/70"> · counted</span>
          </td>
          <td colSpan={3} className="px-3 py-2 text-right">
            {monthCreditedSec === undefined ? (
              <span
                className="text-ink-3"
                title="Could not load this month's total"
              >
                —
              </span>
            ) : (
              <Duration seconds={monthCreditedSec} />
            )}
          </td>
          <td />
        </tr>
      }
    />
  );
}
