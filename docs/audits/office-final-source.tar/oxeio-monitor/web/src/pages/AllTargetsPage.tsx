import { useEffect, useState, type ReactNode } from 'react';

import {
  deleteTarget,
  decideSkip,
  deleteTargets,
  listTargetAdders,
  undoComplete,
  listTargetDesigners,
  listTargets,
  markChecked,
  markFixed,
  markReviewed,
  targetStats,
  type DropReason,
  type TargetRow,
  type TargetStatus,
  updateTarget,
} from '../api/targets';
import { useApi } from '../api/useApi';
import { useAuth } from '../auth/AuthContext';
import { Card } from '../components/Card';
import { Page } from '../components/Page';
import { ErrorBox, Loading } from '../components/States';
import { Table, type Column } from '../components/Table';
import { formatDate, formatDateTime, formatDuration } from '../lib/format';
import {
  Chip,
  MiniButton,
  Modal,
  Notice,
  ServerError,
  useMutation,
} from './settings/ui';
import {
  dropdownValueOf,
  FILTERS,
  stageOf,
  STATUS_OPTIONS,
  type FilterKey,
  type Stage,
} from './targets/filters';
import { DropReasonPicker, DropReasonTag } from './targets/DropReason';
import { downloadTargetsCsv } from './targets/export';
import { SkipInsights, HistoryDrawer } from './targets/Insights';
import { SavedViews, parsePoolView, type PoolView } from './targets/SavedViews';

/**
 * **সব ডিজাইন-টার্গেট** *(২৩ আগস্ট, মালিকের চাওয়া)* — সাইডবারে
 * **"Design Pool"** *(মালিকের দেওয়া নাম, ২৩ আগস্ট)*।
 *
 * ⚠️ ফাইলের নাম `AllTargetsPage` রয়ে গেছে ইচ্ছাকৃতভাবে — রুট
 * (`targets/all`), import আর App.tsx সব একসাথে বদলানো মানে অকারণ churn,
 * অথচ ব্যবহারকারী ফাইলের নাম দেখেন না। ⭐ পর্দার নাম আর ফাইলের নাম
 * আলাদা হলে বিভ্রান্তি হতে পারে, তাই কথাটা এখানে লেখা রইল।
 *
 * ⚠️⚠️ **"Pool" শব্দটা এই পাতাতেই আবার আসে** — অবস্থার চিপে (`Pool` =
 * এখনো কারো হাতে যায়নি)। অর্থাৎ পাতার নাম "Design Pool" হলেও পাতাটা
 * **সব অবস্থাই** দেখায়, কেবল pool নয়। subtitle ("Every link, and where
 * it stands") ইচ্ছাকৃতভাবে রাখা হয়েছে ঠিক সেই কারণেই।
 *
 * ⚠️ জমা দেওয়ার পাতাটা আলাদা: দুটো আলাদা কাজ, আর এক পাতায় থাকলে
 * ৫০০ লাইন পেস্ট করতে গিয়ে প্রতিবার ৩৯ হাজারের তালিকাও লোড হতো।
 */
export function AllTargetsPage() {
  return (
    <Page title="Design Pool" subtitle="Every link, and where it stands">
      <TargetList />
    </Page>
  );
}


/**
 * ⭐⭐ **পুরো তালিকা** *(২৩ আগস্ট, মালিকের চাওয়া)*।
 *
 * ⚠️⚠️ **পাতা ভাগ ছাড়া এটা বানানো যেত না** — টেবিলে ৩৯ হাজারের বেশি
 * সারি। সব একসাথে আনলে উত্তরটা কয়েক MB হতো, আর ব্রাউজার টেবিলটা আঁকতে
 * গিয়ে জমে যেত।
 *
 * ⭐ খোঁজার ঘরে **URL বা ASIN** দুটোই চলে — গবেষক একটা লিঙ্ক পেস্ট করে
 * দেখে নিতে পারেন ওটা আগে হয়ে গেছে কি না, আর কে করেছিল।
 */
/** ঢাকার আজকের তারিখ, `YYYY-MM-DD` */
function dhakaToday(): string {
  // ⚠️ `toISOString()` UTC দেয় — ঢাকায় ভোর ৬টার আগে সেটা গতকাল দেখাত
  return new Date(Date.now() + 6 * 3_600_000).toISOString().slice(0, 10);
}

/**
 * ⭐⭐ **এক টেবিল, দুই পাতা** *(৩১ আগস্ট ২০২৬)*।
 *
 * ⚠️⚠️ `lockedStage` দিলে পাতাটা **ওই কিউতেই আটকে থাকে**: চিপের সারি ও
 * অবস্থার ড্রপডাউন বসে না, কারণ ওগুলো দিয়ে কেউ Review পাতা থেকে বেরিয়ে
 * অন্য কিছু দেখতে পারত — তখন পাতার নাম আর পাতার বিষয় আলাদা হয়ে যেত।
 *
 * ⭐ খোঁজা ও বাকি ছাঁকনি (ডিজাইনার · কে এনেছেন · তারিখ) **থাকে** — ওগুলো
 * কিউয়ের ভেতরে খোঁজার জিনিস, কিউ থেকে বেরোনোর নয়।
 *
 * ⚠️ মার্কআপটা **নকল করা হয়নি, ভাগ করা হয়েছে** — ১৭ আগস্টে Worklog-এর
 * সময় শেখা: দুই জায়গায় কপি থাকলে একদিন একটা বদলাত আর অন্যটা নয়।
 */
export function TargetList({ lockedStage }: { lockedStage?: Stage } = {}) {
  const [initialView] = useState(() => parsePoolView(window.location.search));
  const [showInsights,setShowInsights] = useState(false);
  const [historyId,setHistoryId] = useState<number|null>(null);
  const [filter, setFilter] = useState<FilterKey>(lockedStage ?? initialView.filter as FilterKey);
  /** ⚠️ আটকানো পাতায় কিউ বদলানোর কন্ট্রোলগুলো বসে না */
  const showQueues = lockedStage === undefined;
  const [q, setQ] = useState(initialView.q);
  const [staffId, setStaffId] = useState(initialView.staffId);
  /** ⭐ কে এনেছেন — `users.id`, `staffId`-র (`employees.id`) থেকে আলাদা */
  const [addedById, setAddedById] = useState(initialView.addedById);
  const [from, setFrom] = useState(initialView.from);
  const [to, setTo] = useState(initialView.to);
  const [page, setPage] = useState(1);
  /** ⭐ বাকি ছাঁকনিগুলো খোলা আছে কি না *(২৫ আগস্ট)* — ডিফল্টে বন্ধ */
  const [showFilters, setShowFilters] = useState(false);
  const edit = useMutation();

  /**
   * ⭐⭐ **বেছে নেওয়া সারিগুলো** *(মালিকের চাওয়া, ২৯ আগস্ট ২০২৬:
   * "not found asin gula delete korar time e select kora zabe")*।
   *
   * ⚠️ `Set`, `TargetRow[]` নয় — দরকার শুধু "এটা বাছা হয়েছে কি না",
   * আর সারির বাকি তথ্য তালিকাতেই আছে। সারি জমিয়ে রাখলে রিফ্রেশের পর
   * পুরোনো কপি হাতে থেকে যেত।
   */
  const [picked, setPicked] = useState<ReadonlySet<number>>(new Set());
  const [confirmingBulk, setConfirmingBulk] = useState(false);
  /** ⚠️ শেষ-হওয়া কতগুলো বাদ পড়ল — মোছার পর একবার বলা হয়, তারপর চুপ */
  const [kept, setKept] = useState(0);

  const designers = useApi(listTargetDesigners, []);
  /**
   * ⭐⭐ **কে কতগুলো এনেছেন** *(মালিকের চাওয়া, ২৫ আগস্ট)*।
   *
   * ⚠️ সংখ্যাটা ড্রপডাউনের ভেতরেই লেখা থাকে, তাই মালিক **কিছু না চেপেই**
   * উত্তরটা পান — ছাঁকাটা তার পরের ধাপ, বাধ্যতামূলক নয়।
   */
  const adders = useApi(listTargetAdders, []);
  /** ⭐ চিপের পাশের সংখ্যাটা — ক্লিক করার **আগেই** জানা দরকার কাজ আছে কি না */
  const stats = useApi(targetStats, []);

  /**
   * ⭐ শর্তটার **নাম আছে** — `role !== 'employee'` লেখা হয়নি।
   *
   * ⚠️ এই প্রকল্পে নাম না দেওয়া অধিকার-শর্ত বারবার বাগ তৈরি করেছে
   * (G134: ম্যানেজার নেভে Settings দেখতেন, চাপলে "There's nothing at this
   * address")। নাম থাকলে বদলানোর সময় সব জায়গা একসাথে বদলায়।
   */
  const { user } = useAuth();
  const mayDelete = user?.role === 'owner' || user?.role === 'manager';

  const data = useApi(
    (signal) =>
      listTargets(
        {
          /**
           * ⚠️ কিউ দুটো `status` নয় — তাই আলাদা করে পাঠাতে হয়। `stage`
           *    থাকলে `status` পাঠানো হয় **না**, নইলে দুটো ছাঁকনি একসাথে
           *    বসে কিউটা খালি দেখাত।
           */
          ...(stageOf(filter)
            ? { stage: stageOf(filter) }
            : filter === 'all'
              ? {}
              : { status: filter as TargetStatus }),
          ...(q.trim() ? { q: q.trim() } : {}),
          ...(staffId ? { staffId: Number(staffId) } : {}),
          ...(addedById ? { addedById: Number(addedById) } : {}),
          ...(from ? { from } : {}),
          ...(to ? { to } : {}),
          page,
        },
        signal,
      ),
    [filter, q, staffId, addedById, from, to, page],
  );

  /**
   * ⚠️⚠️ **ছাঁকনি বা পাতা বদলালে বাছাই মুছে যায়, আর এটা নিরাপত্তার শর্ত।**
   * নইলে ২ নম্বর পাতায় ৫০টা বেছে, তারপর ছাঁকনি বদলে Delete চাপলে
   * **চোখের সামনে নেই এমন** সারি মুছে যেত — আর কেউ বুঝতই না কী গেল।
   */
  useEffect(() => {
    setPicked(new Set());
    setKept(0);
  }, [filter, q, staffId, addedById, from, to, page]);

  /**
   * ⭐⭐ **গোটানো ছাঁকনির গায়ের সংখ্যাটা** *(২৫ আগস্ট)*।
   *
   * ⚠️⚠️ লুকোনো ছাঁকনি নিজেই একটা ফাঁদ: কেউ কাল এসে খালি তালিকা দেখে
   * ভাবত ডেটা হারিয়ে গেছে, অথচ গতকালের তারিখটাই বসে ছিল। এই সংখ্যাটাই
   * সেই ফাঁদটা বন্ধ করে — বোতামে সংখ্যা থাকলে সেটা লালও হয়ে থাকে।
   */
  const activeFilters =
    (staffId ? 1 : 0) + (addedById ? 1 : 0) + (from ? 1 : 0) + (to ? 1 : 0);

  /**
   * ⭐ ড্রপডাউনে কী দেখাবে — কিউ-চিপ বাছা থাকলে `all`।
   *
   * ⚠️ চিপ আর ড্রপডাউন **একই চলক** (`filter`) ধরে চলে, তাই একটা বাছলে
   * অন্যটা নিজে থেকেই ছেড়ে দেয়। দুটো আলাদা চলক রাখলে একদিন দুটোই
   * বসে যেত, আর তালিকা খালি দেখাত।
   *
   * ⚠️⚠️ `done_today` আসল অবস্থা নয় — তাই মিলিয়ে দেখা হয়, মনে রাখা হয়
   * না। মনে রাখলে মালিক হাতে তারিখ বদলানোর পরেও ড্রপডাউন "আজ" বলত।
   */
  const today = dhakaToday();
  const statusValue = dropdownValueOf(filter, from, to, today);

  const rows = data.data?.rows ?? [];
  /** ⚠️ খালি পাতায় `every()` সত্যি বলে — তাই সংখ্যাটাও দেখা হয় */
  const selectableRows = rows.filter((r) => !r.skipReviewPending && r.status !== 'done' && r.status !== 'deleted');
  const allPicked = selectableRows.length > 0 && selectableRows.every((r) => picked.has(r.id));

  const toggleAll = () =>
    setPicked(allPicked ? new Set() : new Set(selectableRows.map((r) => r.id)));

  const toggleOne = (id: number) =>
    setPicked((prev) => {
      const next = new Set(prev);
      // ⚠️ `delete()` false ফেরালে তবেই যোগ — দুই লাইনের if/else নয়
      if (!next.delete(id)) next.add(id);
      return next;
    });

  /**
   * ⭐ চেকবক্সের কলামটা কেবল যাঁর মোছার অধিকার আছে তাঁর কাছে — গবেষকের
   * পর্দায় বসালে বেছে নেওয়া যেত, অথচ কিছুই করা যেত না।
   */
  const pickColumn: Column<TargetRow>[] = mayDelete
    ? [
        {
          key: 'pick',
          className: 'w-8',
          header: (
            <input
              type="checkbox"
              className="tap"
              aria-label="Select deletable targets on this page"
              disabled={selectableRows.length === 0 || edit.busy || data.loading}
              checked={allPicked}
              onChange={toggleAll}
            />
          ),
          render: (r) => (
            <input
              type="checkbox"
              className="tap"
              aria-label={'Select ' + r.asin}
              disabled={r.skipReviewPending || r.status === 'done' || r.status === 'deleted' || edit.busy || data.loading}
              title={r.skipReviewPending ? 'Decide the pending skip before deleting' : r.status === 'done' ? 'Finished work is protected' : r.status === 'deleted' ? 'Already deleted' : 'Select for deletion'}
              checked={picked.has(r.id)}
              onChange={() => toggleOne(r.id)}
            />
          ),
        },
      ]
    : [];

  /** ⚠️ ছাঁকনি বা খোঁজা বদলালে পাতা ১-এ ফেরত — নইলে ৫ নম্বর পাতায় বসে
   *  থেকে "কিছু নেই" দেখা যেত, অথচ ফল আছে */
  /**
   * ⭐ লেখাটা কি একটা লিঙ্ক? — `/` বা `:` থাকলেই যথেষ্ট।
   *
   * ⚠️ নিখুঁত URL পার্সিং নয়, ইচ্ছাকৃতভাবে: কাজটা কেবল **ইঙ্গিত দেখানো**,
   *    কিছু আটকানো নয়। ASIN বা Job নম্বরে এ দুটো অক্ষরের একটাও থাকে না।
   */
  const looksLikeUrl = /[/:]/.test(q);

  const hasSearchFilters = q.trim() !== '' || activeFilters > 0 || (showQueues && filter !== 'all');
  const resetFilters = () => {
    setPage(1); setQ(''); setStaffId(''); setAddedById(''); setFrom(''); setTo(''); setFilter(lockedStage ?? 'all');
    setPicked(new Set()); setConfirmingBulk(false);
  };
  const applyView = (v:PoolView) => {setQ(v.q);setStaffId(v.staffId);setAddedById(v.addedById);setFrom(v.from);setTo(v.to);setFilter(lockedStage ?? v.filter as FilterKey);setPage(1);setPicked(new Set());setConfirmingBulk(false);};
  const skipDates = filter === 'to_review' || filter === 'skipped';

  const change = (next: () => void) => {
    setConfirmingBulk(false);
    setPage(1);
    next();
  };

  return (
    <Card
      title="Every Target"
      /*
        ⚠️ "Newest activity first" আগে ছাঁকনির সারিতে একটা আলাদা লেখা
           ছিল — একটা গোটা কন্ট্রোলের জায়গা নিত, অথচ কিছুই করত না।
        ⭐ কথাটা সত্যি আর দরকারি, তাই মোছা হয়নি — সংখ্যাটার পাশে এসেছে।
      */
      hint={
        data.data
          ? `${data.data.total.toLocaleString()} matching targets · ${skipDates ? 'pending reviews first, then newest skip request' : 'newest activity first'}`
          : 'Loading…'
      }
      padded={false}
    >
      <div className="flex flex-wrap items-center gap-2 px-4 pt-3 pb-2">
        {showQueues &&
          FILTERS.filter((f) => f.stage !== 'to_upload' && f.stage !== 'to_live').map((f) => (
          <button
            key={f.key}
            type="button"
            onClick={() => change(() => setFilter(f.key))}
            title={
              f.stage === 'to_check'
                ? 'Finished designs whose spelling has not been checked yet'
                : f.stage === 'to_fix'
                  ? 'A spelling error was found — waiting to be fixed'
                  : f.stage === 'to_upload'
                    ? 'Checked or not yet checked, and not sent to Amazon. Designs with an unfixed error are held back.'
                    : f.stage === 'to_review'
                      ? 'Skipped or deleted, with a reason — nobody has looked at these yet'
                      : f.stage === 'to_live'
                      ? 'Sent to Amazon, not live yet'
                      : undefined
            }
            className={`rounded-full border px-3 py-1 text-[12.5px] transition ${
              filter === f.key
                ? 'border-brand bg-brand-bg font-semibold text-brand-ink'
                : 'border-line text-ink-2 hover:border-brand'
            }`}
          >
            {f.label}
            {/*
              ⭐ সংখ্যাটা চিপেই — ক্লিক করার **আগেই** জানা দরকার আজ কাজ
                 আছে কি না। ⚠️ ০ হলেও দেখানো হয়, কারণ "০" মানে
                 "শেষ করেছি", আর সেটাই একমাত্র পুরস্কার এখানে।
            */}
            {stats.data ? (
              <span className="num ml-1.5 text-ink-3">
                {f.stage === 'to_check'
                  ? stats.data.toCheck
                  : f.stage === 'to_fix'
                    ? stats.data.toFix
                    : f.stage === 'to_upload'
                      ? stats.data.toUpload
                      : f.stage === 'to_review'
                        ? stats.data.toReview
                        : stats.data.toLive}
              </span>
            ) : null}
          </button>
          ))}

        {/*
          ⭐⭐ **পাঁচটা অবস্থা-চিপের বদলে একটা ড্রপডাউন** *(২৫ আগস্ট)*।

          ⚠️ `done_today` বেছে নিলে তারিখ দুটোও বসে যায়, তাই মানটা
             ফিরে আসে `done` হিসেবে — নিচের `statusValue` সেটা মিলিয়ে
             দেখে আবার `done_today` দেখায়। ⭐ ছাঁকনি যা করেছে, ড্রপডাউন
             ঠিক তা-ই বলে; দুটো আলাদা হলে কেউ বিশ্বাস করত না।
        */}
        {showQueues && (
          <select
            aria-label="Target status"
            value={statusValue}
          onChange={(e) =>
            change(() => {
              const v = e.target.value;
              if (v === 'done_today') {
                setFilter('done');
                setFrom(dhakaToday());
                setTo(dhakaToday());
                return;
              }
              setFilter(v as FilterKey);
              // ⚠️ "আজ" থেকে বেরোলে তারিখ দুটোও ছাড়তে হয়, নইলে কেউ
              //    "Done" বেছে খালি তালিকা দেখে ভাবত ডেটা হারিয়ে গেছে
              if (statusValue === 'done_today') {
                setFrom('');
                setTo('');
              }
            })
          }
          className={`rounded-md border px-2 py-1 text-[12.5px] transition ${
            statusValue === 'all'
              ? 'border-line bg-paper text-ink'
              : 'border-brand bg-brand-bg font-semibold text-brand-ink'
          }`}
        >
            {STATUS_OPTIONS.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </select>
        )}

        {/*
          ⭐⭐ **বাকি ছাঁকনিগুলো গোটানো** *(২৫ আগস্ট)*।

          ⚠️⚠️ চারটে ঘরই (ডিজাইনার · কে এনেছেন · দুটো তারিখ) বেশিরভাগ
             সময় **খালি পড়ে থাকে**, অথচ রোজ পর্দার একটা গোটা সারি নেয়।

          ⚠️ কিন্তু লুকোনো ছাঁকনি নিজেই একটা ফাঁদ — কেউ কাল এসে খালি
             তালিকা দেখে ভাবত ডেটা হারিয়ে গেছে। ⭐ তাই বোতামের গায়ে
             **সংখ্যা** বসে, আর সংখ্যা থাকলে বোতামটা লাল হয়ে থাকে।
             লুকোনো, কিন্তু নীরব নয়।
        */}
        <button
          type="button"
          onClick={() => setShowFilters((v) => !v)}
          aria-expanded={showFilters}
          className={`rounded-md border px-2.5 py-1 text-[12.5px] transition ${
            activeFilters > 0
              ? 'border-brand bg-brand-bg font-semibold text-brand-ink'
              : 'border-line text-ink-2 hover:border-brand'
          }`}
        >
          Filters
          {activeFilters > 0 && <span className="num ml-1.5">{activeFilters}</span>}
          <span className="ml-1 text-ink-3">{showFilters ? '▴' : '▾'}</span>
        </button>

        {/*
          ⭐⭐ **ASIN বা Job নম্বর** *(৬ সেপ্টেম্বর ২০২৬, মালিকের চাওয়া)*।
             প্রতিটা সারির নিচে Job নম্বরটা লেখা থাকে, অথচ এতদিন ওটা দিয়ে
             খোঁজা যেত না — একমাত্র পরিচয় ছিল ASIN।

          ⚠️⚠️ **লিঙ্ক আর চলে না।** আগে পেস্ট করা URL থেকে ASIN বের করে
             নেওয়া হতো; মালিক ওটা তুলে দিতে বলেছেন।
        */}
        <input
          aria-label="Search ASIN or job number"
          value={q}
          onChange={(e) => change(() => setQ(e.target.value))}
          placeholder="ASIN or job no…"
          className="num ml-auto w-full max-w-[260px] rounded-md border border-line bg-paper px-2.5 py-1 text-[12.5px] text-ink"
        />
      </div>

      {/*
        ⚠️⚠️ লিঙ্ক পেস্ট করলে **বলে দেওয়া হয়**। নইলে ফলটা হতো একটা নীরব
           খালি তালিকা, আর ব্যবহারকারী ভাবতেন ডিজাইনটা পুলে নেই — অথচ
           আছে। এই অ্যাপে নীরব ভুল উত্তরই সবচেয়ে অপছন্দের ব্যর্থতা।
      */}
      <div className="flex flex-wrap items-center gap-2 px-4 pb-2">
        <MiniButton disabled={data.loading || edit.busy} onClick={() => { setPicked(new Set()); setConfirmingBulk(false); data.reload(); stats.reload(); }}>Refresh</MiniButton>
        <MiniButton disabled={data.loading || rows.length === 0} title="Export the visible page, up to 50 matching targets" onClick={() => downloadTargetsCsv(rows, data.data?.page ?? page)}>Export this page · CSV</MiniButton>
        {mayDelete && <MiniButton onClick={()=>setShowInsights(!showInsights)}>{showInsights?'Hide skip report':'Skip report'}</MiniButton>}
        {hasSearchFilters && <MiniButton onClick={resetFilters}>Reset all filters</MiniButton>}
        {data.loading && <span role="status" className="text-xs text-ink-3">Loading targets…</span>}
      </div>
      {looksLikeUrl && (
        <div className="px-4 pb-2 text-[12px] text-idle-ink">
          Links are not searched any more — paste the <b>ASIN</b> or the{' '}
          <b>job number</b> instead.
        </div>
      )}

      {showFilters && (
        <div className="flex flex-wrap items-center gap-2 px-4 pb-2">
          <select
            aria-label="Designer"
            value={staffId}
            onChange={(e) => change(() => setStaffId(e.target.value))}
            className="rounded-md border border-line bg-paper px-2 py-1 text-[12.5px] text-ink"
          >
            <option value="">Any designer</option>
            {(designers.data ?? []).map((d) => (
              <option key={d.id} value={d.id}>
                {d.empCode} · {d.fullName}
              </option>
            ))}
          </select>

          {/*
            ⚠️⚠️ পাশের ড্রপডাউনের সাথে দেখতে এক, অথচ **ভিন্ন টেবিলের id**
               — ওটা `employees`, এটা `users`। লেখাদুটো তাই আলাদা রাখা,
               নইলে ওরা যমজ দেখাত।
            ⭐ প্রতিটা নামের পাশে সংখ্যা — মালিক ছাঁকার **আগেই** দেখেন কে
               কতটা এনেছেন।
          */}
          <select
            aria-label="Added by"
            value={addedById}
            onChange={(e) => change(() => setAddedById(e.target.value))}
            className="rounded-md border border-line bg-paper px-2 py-1 text-[12.5px] text-ink"
          >
            <option value="">Added by anyone</option>
            {(adders.data ?? []).map((a) => (
              <option key={a.id} value={a.id}>
                {a.fullName} · {a.count.toLocaleString()}
              </option>
            ))}
          </select>

          <label className="flex items-center gap-1.5 text-[12px] text-ink-3">
            From
            <input
              type="date"
              max={to || undefined}
              value={from}
              onChange={(e) => change(() => setFrom(e.target.value))}
              className="num rounded-md border border-line bg-paper px-2 py-1 text-[12.5px] text-ink"
            />
          </label>

          <label className="flex items-center gap-1.5 text-[12px] text-ink-3">
            to
            <input
              type="date"
              min={from || undefined}
              value={to}
              onChange={(e) => change(() => setTo(e.target.value))}
              className="num rounded-md border border-line bg-paper px-2 py-1 text-[12.5px] text-ink"
            />
          </label>

          <MiniButton onClick={() => change(() => { setFrom(today); setTo(today); })}>Today</MiniButton>
          <MiniButton onClick={() => change(() => { setFrom(new Date(Date.now() + 6 * 3_600_000 - 6 * 86_400_000).toISOString().slice(0, 10)); setTo(today); })}>Last 7 days</MiniButton>
          {activeFilters > 0 && (
            <button
              type="button"
              onClick={() =>
                change(() => {
                  setStaffId('');
                  setAddedById('');
                  setFrom('');
                  setTo('');
                })
              }
              className="text-[12px] text-data hover:underline"
            >
              Clear filters
            </button>
          )}
        </div>
      )}

      <SavedViews scope={String(user?.userId)+'.'+(lockedStage??'all')} current={{filter,q,staffId,addedById,from,to}} onApply={applyView}/>
      {mayDelete&&showInsights&&<SkipInsights/>}
      {historyId!==null&&<HistoryDrawer id={historyId} onClose={()=>setHistoryId(null)}/>}
      <div className="px-4">
        {(from || to) && <p className="pb-2 text-xs text-ink-3">
          {skipDates ? 'Dates refer to skip requests in Dhaka time. Clear dates to include legacy skips and deleted targets.' : filter === 'done' ? 'Dates refer to completion time in Dhaka time.' : 'Dates refer to the latest recorded target activity in Dhaka time.'}
        </p>}
        <ServerError error={edit.error} />
      </div>

      {/*
        ⭐⭐⭐ **তালিকাটা কী বলে, আর কী বলে না** *(৯ সেপ্টেম্বর ২০২৬)*।

        ⚠️⚠️ এই লেখাটা ঐচ্ছিক নয়। একটা "প্রমাণ নেই" তালিকা ব্যাখ্যা ছাড়া
           পড়লে ওটা একটা **অভিযোগপত্র**, অথচ চিহ্ন না থাকার সবচেয়ে সাধারণ
           কারণ নির্দোষ: মাঠে একজন গোটা দিন `Untitled-20*`-এ কাজ করেন,
           কখনো সেভ করেন না — তাঁর ৮০% কাজেরই কোনো চিহ্ন নেই, অথচ কাজটা
           হয়েছে। ⭐ সংখ্যাটা ভুল নয়, ওটার **মানেটা** সহজে ভুল পড়া যায়।
      */}
      {filter === 'no_file' && (
        <div className="px-4 pb-1">
          <Notice>
            These were marked <b>done</b>, but no file whose name starts with
            that job number was ever open in Illustrator or Photoshop.{' '}
            <b>That is a question, not a verdict</b> — a file saved without the
            job number in its name, or never saved at all, leaves no trace
            either.
            {data.data?.traceSince ? (
              <>
                {' '}
                Window titles are kept from{' '}
                <span className="num">
                  {formatDate(data.data.traceSince)}
                </span>{' '}
                onward, so nothing older is listed.
              </>
            ) : null}
          </Notice>
        </div>
      )}

      {data.loading && !data.data && <Loading />}
      {data.error && <ErrorBox error={data.error} retry={data.reload} />}

      {data.data && data.data.rows.length === 0 && (
        <div className="px-4 py-6 text-[13px] text-ink-3">
          No targets match your search or filters.
          {hasSearchFilters && <button type="button" onClick={resetFilters} className="ml-2 text-data hover:underline">Reset all filters</button>}
        </div>
      )}

      {data.data && data.data.rows.length > 0 && (
        <>
          {/*
            ⭐⭐ **কতগুলো বাছা হয়েছে, আর তা নিয়ে কী করা যায়** — বারটা বসে
               তখনই, যখন অন্তত একটা বাছা। ⚠️ সবসময় বসিয়ে রাখলে পাতার
               মাথায় একটা খালি ফালি থাকত, আর ২৫ আগস্টের ছাঁটাইয়ের গোটা
               কথাই ছিল এই পাতায় কম জিনিস রাখা।
          */}
          {mayDelete && picked.size > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line bg-paper px-4 py-2.5">
              <span className="text-[12.5px] text-ink-2">
                <span className="num font-semibold">{picked.size}</span> selected
              </span>
              <span className="flex gap-2">
                <MiniButton
                  disabled={edit.busy}
                  onClick={() => setPicked(new Set())}
                >
                  Clear
                </MiniButton>
                <MiniButton
                  tone="danger"
                  disabled={edit.busy}
                  onClick={() => setConfirmingBulk(true)}
                >
                  Delete {picked.size} selected
                </MiniButton>
              </span>
            </div>
          )}

          {/*
            ⚠️⚠️ **যেগুলো মোছা হয়নি সেগুলোর কথাও বলা হয়।** ৫০টা বেছে ৪৮টা
               মুছলে বাকি দুটোর কী হলো সেটা না বললে মানুষ ধরেই নিতেন সব
               মুছে গেছে — আর শেষ-হওয়া কাজ চুপচাপ তালিকায় থেকে যেত।
          */}
          {kept > 0 && (
            <div className="px-4 pt-3">
              <Notice tone="attention">
                <span className="num font-semibold">{kept}</span> finished{' '}
                {kept === 1 ? 'design was' : 'designs were'} left alone — deleting
                those would take away work that was really done. Undo them first
                if they must go.
              </Notice>
            </div>
          )}

          {/*
            ⚠️⚠️ **`ConfirmDialog` নয়, খোলা `Modal` — আর কারণটা গঠনগত**
               *(৩১ আগস্ট)*। ওই ডায়ালগের নিজের একটা "Delete" বোতাম আছে, আর
               কারণ বাছাই তার সাথে বাঁধা যেত না: হয় কারণ ছাড়াই মোছা যেত,
               নয় একটা ডিফল্ট বসাতে হতো — আর ডিফল্ট মানে কেউ কোনোদিন
               ভেবে বাছত না। ⭐ এখানে **তিনটে কারণই নিচের বোতাম**, অর্থাৎ
               কারণ না বেছে মোছার কোনো পথ নেই।
          */}
          {confirmingBulk && (
            <Modal
              title={
                picked.size === 1
                  ? 'Delete 1 target?'
                  : 'Delete ' + picked.size + ' targets?'
              }
              onClose={() => setConfirmingBulk(false)}
              footer={
                <DropReasonPicker
                  busy={edit.busy}
                  onPick={(reason) =>
                    edit.run(async () => {
                      const res = await deleteTargets([...picked], reason);
                      setKept(res.keptDone);
                      setPicked(new Set());
                      setConfirmingBulk(false);
                      data.reload();
                      stats.reload();
                    })
                  }
                  onCancel={() => setConfirmingBulk(false)}
                />
              }
            >
              <div className="space-y-3">
                <p className="text-[13px] text-ink-2">
                  Use this for links whose Amazon page is gone.
                </p>
                {/*
                  ⚠️⚠️ পরিণামটা **দুই দিক থেকেই** লেখা: আর কারো কাছে যাবে না,
                     আর ওই ASIN কোনোদিন পুলে ফিরতেও পারবে না। দ্বিতীয় কথাটাই
                     এই বদলের গোটা কারণ, তাই লুকোনো চলে না।
                */}
                <Notice tone="attention">
                  They stay in the list as Deleted, never go to anyone again, and
                  the same ASIN can never be added back to the pool. Finished
                  designs in the selection are left alone.
                </Notice>
                <ServerError error={edit.error} />
              </div>
            </Modal>
          )}

          <Table
            rows={data.data.rows}
            rowKey={(r) => String(r.id)}
            columns={[
              ...pickColumn,
              /*
                ⭐⭐ **সাতটা কলাম থেকে চারটে** *(মালিকের সিদ্ধান্ত, ২৫
                   আগস্ট: "khubi gatharing lagoche dekhote")*।

                ⚠️⚠️ কোনো তথ্য মোছা হয়নি — **জোড়া লাগানো হয়েছে**, আর
                   জোড়াগুলো ইচ্ছেমতো নয়:
                     · Job no. → ASIN-এর নিচে  (দুটোই *পরিচয়*)
                     · তারিখ  → Stage-এর নিচে  (একই কথা: কোন ধাপে, কবে)
                     · কে এনেছেন → কে করছেন    (একটা *বাক্য*, দুটো ঘর নয়)
              */
              {
                key: 'design',
                header: 'Design',
                render: (r) => (
                  <span className="block">
                    <a
                      href={r.url}
                      target="_blank"
                      // ⚠️ tabnabbing ঠেকাতে — নতুন ট্যাব যেন এই পাতা সরাতে না পারে
                      rel="noreferrer noopener"
                      className="num text-data hover:underline"
                    >
                      {r.asin}
                    </a>

                    {/*
                      ⚠️ কাজের নম্বর **না থাকলে লাইনটাই বসে না** — একটা
                         "—" দেখানোর চেয়ে ফাঁকা জায়গাই শান্ত, আর পুলে
                         পড়ে থাকা সারির নম্বর থাকেই না।
                    */}
                    {r.jobNumber !== null && (
                      <span className="num block text-[11.5px] text-ink-3">
                        Job {r.jobNumber}
                      </span>
                    )}
                  </span>
                ),
              },
              {
                key: 'stage',
                header: 'Stage',
                render: (r) => (
                  <span className="block">
                    {/*
                      ⭐ কারণটা চিপের **পাশে**, নিচে নয় *(৩১ আগস্ট)* — নিচের
                         লাইনটা তারিখের, আর দুটো আলাদা জিনিস এক লাইনে বসলে
                         কোনটা কী বোঝা যেত না।
                    */}
                    <span className="flex flex-wrap items-center gap-1.5">
                      <StatusChip row={r} />
                      <DropReasonTag reason={r.dropReason} />
                      {/*
                        ⭐ দেখা হয়ে গেলে কে দেখেছেন সেটা এখানেই — সারিটা
                           কিউ থেকে সরে যায় বলে নইলে খবরটা কোথাও থাকত না।
                      */}
                      {r.reviewedAt !== null && (
                        <Chip tone="counted">
                          Reviewed{r.reviewedBy ? ` · ${r.reviewedBy.fullName}` : ''}
                        </Chip>
                      )}
                    </span>
                    <WhenCell row={r} />
                  </span>
                ),
              },
              /**
               * ⭐⭐⭐ **দাবির পাশে মাপ** *(মালিকের চাওয়া, ৯ সেপ্টেম্বর
               * ২০২৬: "ka banao")*।
               *
               * ⚠️⚠️ **কেন কলামটা দরকার হলো।** "শেষ" চিহ্নটা কর্মীর
               * নিজের ক্লিক — কেউ যাচাই করে না। ৮ সেপ্টেম্বরে একজনের
               * ৩২টা "শেষ" নিয়ে প্রশ্ন উঠলে উত্তর দিতে ডাটাবেসে হাতে
               * কোয়েরি লিখতে হয়েছিল, কারণ পর্দায় দাবিটা ছিল, দাবির
               * পাশে কিছু ছিল না।
               *
               * ⭐ নতুন কিছু জমা করতে হয়নি — এজেন্ট শিরোনাম আগে থেকেই
               * রাখে, আর ফাইলের নাম শুরু হয় জব-নম্বরে।
               */
              {
                key: 'file',
                header: 'File',
                className: 'hidden sm:table-cell',
                render: (r) => <FileCell sec={r.fileSec} />,
              },
              {
                key: 'people',
                header: 'People',
                /*
                  ⭐⭐ **"কে এনেছেন → কে করছেন"** — একটা সারির গোটা গল্প।

                  ⚠️⚠️ দুটো আলাদা id-র জগৎ এক ঘরে বসছে (`users` →
                     `employees`), আর তীরচিহ্নটা সেটাই বোঝায়: বাঁয়ে যিনি
                     কাজটা **এনেছেন**, ডানে যিনি **করছেন**।

                  ⚠️ আনার নামটা **ধূসর**, করার নামটা গাঢ় — রোজকার কাজে
                     ডিজাইনারের নামটাই বেশি দরকার হয়, তাই ওজনটা সেদিকে।
                */
                className: 'hidden sm:table-cell',
                render: (r) => <PeopleCell row={r} />,
              },
              {
                key: 'edit',
                header: '',
                render: (r) => (
                  <span className="flex flex-wrap items-center justify-end gap-1.5">
                  {mayDelete&&<MiniButton title={'History for '+r.asin} onClick={()=>setHistoryId(r.id)}>History</MiniButton>}
                  <RowActions
                    row={r}
                    busy={edit.busy}
                    onChange={(status) =>
                      edit.run(async () => {
                        await updateTarget(r.id, status);
                        data.reload();
                      })
                    }
                    onChecked={(ok) =>
                      edit.run(async () => {
                        await markChecked(r.id, ok);
                        data.reload();
                        stats.reload();
                      })
                    }
                    onFixed={() =>
                      edit.run(async () => {
                        await markFixed(r.id);
                        data.reload();
                        stats.reload();
                      })
                    }
                    onUndo={() =>
                      edit.run(async () => {
                        await undoComplete(r.id);
                        data.reload();
                      })
                    }
                    onReviewed={() =>
                      edit.run(async () => {
                        await markReviewed(r.id);
                        data.reload();
                        stats.reload();
                      })
                    }
                    mayDelete={mayDelete}
                    onSkipDecision={(approve) => edit.run(async () => {
                      await decideSkip(r.id, approve);
                      data.reload();
                      stats.reload();
                    })}
                    mayProofread={user?.canProofread === true}
                    onDelete={(reason) =>
                      edit.run(async () => {
                        // ⚠️ একক পথেও `keptDone` আসে — শেষ-হওয়া সারিতে
                        //    Delete চাপলে কিছুই ঘটে না, আর সেটা বলা দরকার
                        const res = await deleteTarget(r.id, reason);
                        setKept(res.keptDone);
                        data.reload();
                        stats.reload();
                      })
                    }
                  />
                  </span>
                ),
              },
            ]}
          />

          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-line px-4 py-2.5 text-[12.5px] text-ink-3">
            <span className="num">
              Page {data.data.page} of {data.data.pages}
            </span>
            <span className="flex gap-2">
              <MiniButton
                disabled={data.loading || data.data.page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                Previous
              </MiniButton>
              <MiniButton
                disabled={data.loading || data.data.page >= data.data.pages}
                onClick={() => setPage((p) => p + 1)}
              >
                Next
              </MiniButton>
            </span>
          </div>
        </>
      )}
    </Card>
  );
}

/**
 * ⚠️ "শেষ" হলে **কীভাবে** শেষ হলো সেটাও বলা হয় — সিস্টেম ফাইলের নাম
 * থেকে ধরেছে, নাকি কেউ হাতে বলেছে, নাকি পুরোনো তালিকা থেকে এসেছে।
 * সংখ্যাটা এক, কিন্তু ভরসা এক নয়।
 */
function StatusChip({ row }: { row: TargetRow }) {
  if (row.skipReviewPending) return <Chip tone="attention">Pending skip review</Chip>;
  if (row.status === 'done') {
    /*
      ⚠️ পুরোনো Excel থেকে আসা সারিগুলো আলাদা করে বলা হয় — ওগুলোর
         সংখ্যাটা সত্যি, কিন্তু oXeio সেটা **মাপেনি**, শুধু ইতিহাস
         হিসেবে নিয়েছে। ভরসার মাত্রা এক নয়।
      ⚠️ `filename` আর আসে না (২৩ আগস্ট থেকে ওটা "শুরু"); পুরোনো সারিতে
         থাকতে পারে বলে ঘরটা রাখা।
    */
    return (
      <Chip tone="counted">
        {row.completedVia === 'import' ? 'Done (old list)' : 'Done'}
      </Chip>
    );
  }
  // ⭐ "কাজ চলছে" আলাদা করে দেখানো — মালিক দেখেন কোনগুলোয় সত্যিই হাত
  //    পড়েছে, আর কোনগুলো পড়ে আছে
  if (row.status === 'assigned') {
    return row.startedAt ? (
      <Chip tone="pending">Started</Chip>
    ) : (
      <Chip tone="muted">In hand</Chip>
    );
  }
  if (row.status === 'skipped') return <Chip tone="attention">Skipped</Chip>;
  /**
   * ⚠️ ধূসর, লাল নয় — মোছা সারি কোনো **সমস্যা** নয়, একটা মীমাংসিত ঘটনা।
   * লাল রাখলে তালিকা ভর্তি লাল চিপ হতো, আর তখন সত্যিকারের লাল
   * (`Skipped`) আর চোখে পড়ত না (`Notice`-এর একই নিয়ম)।
   */
  if (row.status === 'deleted') return <Chip tone="muted">Deleted</Chip>;

  return <Chip>Waiting</Chip>;
}

/**
 * ⭐ কোন তারিখ, আর **কীসের** তারিখ।
 *
 * ⚠️ শুধু একটা তারিখ বসালে পুলে পড়ে থাকা সারিতেও কিছু একটা দেখাত, আর
 * পাঠক ধরে নিতেন ওটা "কবে হয়েছে"।
 */
/**
 * ⭐ Stage-এর নিচের ছোট তারিখটা *(২৫ আগস্ট থেকে আলাদা কলাম নয়)*।
 *
 * ⚠️⚠️ **কোন তারিখটা দেখানো হচ্ছে সেটাও বলা হয়** — শেষ হওয়ার, শুরুর,
 * নাকি বরাদ্দের। শুধু একটা তারিখ বসালে পাঠক ধরে নিতেন ওটা "কবে
 * হয়েছে"। উপরের চিপটা অবস্থা বলে, কিন্তু `In hand` সারিতে তারিখটা
 * শুরুরও হতে পারে, বরাদ্দেরও — চিপ ওই দুটো আলাদা করে না।
 *
 * ⭐ পুলে পড়ে থাকা সারির কোনো কাজের তারিখ নেই, তাই আগে এখানে `—` বসত।
 * এখন **কবে এসেছে** সেটা বসে — ওটাই ওই সারির একমাত্র খবর, আর ঘরটা
 * খালি রাখার চেয়ে সত্যি কথা বলা ভালো।
 */
/**
 * ⭐⭐ **ফাইলের চিহ্ন — তিনটে অবস্থা, তিন রকম লেখা** *(৯ সেপ্টেম্বর ২০২৬)*।
 *
 * | মান | পর্দায় | মানে |
 * |---|---|---|
 * | `null` | `—` | ⚠️ বলার মতো কিছু নেই — হয় তখনকার শিরোনাম জমা নেই, নয় সারিটা এখনো শেষ বলা হয়নি |
 * | `0` | `no trace` | **শেষ বলা হয়েছে**, অথচ কখনো খোলা হয়নি |
 * | `> 0` | `18m` / `45s` | এতক্ষণ পর্দায় ছিল |
 *
 * ⚠️⚠️ **`formatDuration()` এখানে একা যথেষ্ট নয়, আর কারণটা সূক্ষ্ম:**
 * ওটা ২০ সেকেন্ডকে `0m` লেখে, আর `0m` দেখতে হুবহু "কখনো খোলা হয়নি"-র
 * মতো। অথচ এই কলামে ঠিক ওই পার্থক্যটাই সবচেয়ে দরকারি খবর — ২০ সেকেন্ড
 * মানে ফাইলটা খোলা হয়েছিল, আর শূন্য মানে হয়নি। ⭐ তাই এক মিনিটের নিচে
 * সেকেন্ডেই লেখা হয়।
 *
 * ⚠️ `0`-র রংটা **সতর্কতার নয়** — ধূসর। লাল করলে তালিকাটা অভিযোগ হয়ে
 * যেত, অথচ সেভ না করা ফাইলও ঠিক এই ঘরেই পড়ে।
 */
function FileCell({ sec }: { sec: number | null }) {
  if (sec === null) {
    return (
      <span
        className="num text-[12px] text-ink-3"
        title="Nothing to say yet — either this is not marked done, or no window titles were kept from back then"
      >
        —
      </span>
    );
  }

  if (sec === 0) {
    return (
      <span
        className="text-[11.5px] text-ink-3 italic"
        title="Marked done, but no file starting with this job number was ever open in Illustrator or Photoshop. A file saved under another name leaves no trace either."
      >
        no trace
      </span>
    );
  }

  return (
    <span
      className="num whitespace-nowrap text-[12px] text-ink-2"
      title="How long a file starting with this job number was on screen in Illustrator or Photoshop"
    >
      {sec < 60 ? `${sec}s` : formatDuration(sec)}
    </span>
  );
}

function WhenCell({ row }: { row: TargetRow }) {
  if (row.skipReviewPending || row.status === 'skipped') return (
    <span className="num mt-0.5 block text-[11.5px] text-ink-3">
      {row.skipRequestedAt ? `${formatDateTime(row.skipRequestedAt)} · skip requested` : 'Skip time not recorded (legacy)'}
    </span>
  );
  const when =
    row.completedAt ?? row.startedAt ?? row.assignedAt ?? row.addedAt;

  const what = row.completedAt
    ? 'done'
    : row.startedAt
      ? 'started'
      : row.assignedAt
        ? 'given'
        : 'added';

  return (
    <span className="num mt-0.5 block whitespace-nowrap text-[11.5px] text-ink-3">
      {formatDateTime(when)} · {what}
    </span>
  );
}

/**
 * ⭐⭐ **কে এনেছেন → কে করছেন** *(২৫ আগস্ট)*।
 *
 * ⚠️ আগে এটা দুটো আলাদা কলাম ছিল ("Added by" আর "Designer"), আর দুটোই
 * মানুষের নাম — পাশাপাশি বসে সেটা গাদাগাদি লাগত। ⭐ এক ঘরে তীরচিহ্ন
 * দিয়ে লিখলে ওটা একটা **বাক্য** হয়ে যায়: কাজটা কোথা থেকে এসে কার
 * কাছে গেছে।
 */
function PeopleCell({ row }: { row: TargetRow }) {
  return (
    <span className="block">
      <span className="whitespace-nowrap">
        {/* ⚠️ আনার নামটা ধূসর — রোজকার কাজে ডিজাইনারের নামটাই বেশি দরকার */}
        <span className="text-ink-3">{row.addedBy.fullName}</span>
        <span className="px-1 text-ink-3">→</span>
        {row.assignedTo ? (
          <span className="text-ink">{row.assignedTo.fullName}</span>
        ) : row.sourceNote ? (
          /*
            ⚠️ ইমপোর্ট করা পুরোনো সারিতে `assignedTo` **নেই** — নামটা
               কাঁচা লেখায় (`Hafiz-24-05-2026`), কারণ ওই কর্মীদের অনেকেই
               আর সিস্টেমে নেই।
          */
          <span className="num text-[12px] text-ink-3">{row.sourceNote}</span>
        ) : (
          <span className="text-ink-3">nobody yet</span>
        )}
      </span>

      {/*
        ⭐⭐ **কে "শেষ" বলেছেন** *(২৩ আগস্ট, মালিকের রিপোর্ট)*। আগে কেবল
        বরাদ্দ পাওয়া মানুষের নাম দেখাত, তাই মালিক নিজে Complete চাপলেও
        ডিজাইনারের নামই উঠত — সরাসরি ভুল তথ্য।

        ⚠️ নামটা তখনই আসে যখন কেউ সত্যিই চেপেছেন। পুরোনো সারিগুলোয় ঘরটা
        খালি থাকে — অনুমান করে কিছু বসানো হয় না।
      */}
      {row.completedBy && (
        <span className="block text-[11.5px] text-ink-3">
          ✓ marked by {row.completedBy.fullName}
        </span>
      )}
    </span>
  );
}

/**
 * ⭐⭐ **সম্পাদনা** *(২৩ আগস্ট)* — owner · manager · গবেষক।
 *
 * ⚠️⚠️ **ASIN বদলানোর পথ নেই** — ওটা সারিটার পরিচয়। বদলালে
 * ডুপ্লিকেট-প্রহরীর গোটা ভিত্তিটাই নড়ে যেত, আর ইতিহাসে "এই পণ্যটা
 * হয়েছিল" কথাটা মিথ্যা হয়ে যেত।
 *
 * ⚠️ **Delete এখন আর সারি মোছে না** *(২৯ আগস্ট ২০২৬)* — অবস্থা হয়
 * `deleted`, সারিটা তালিকায় থাকে। ⭐ তবু জিজ্ঞেস করা হয়: ফেরার পথ
 * আছে (অবস্থা বদলে `pool`), কিন্তু ভুল সারি মুছলে কেউ টেরই পাবেন না —
 * চিপটা ধূসর, আর ধূসর জিনিস চোখে পড়ে না।
 */
function RowActions({
  row,
  busy,
  onChange,
  onChecked,
  onFixed,
  onUndo,
  onReviewed,
  onSkipDecision,
  onDelete,
  mayDelete,
  mayProofread,
}: {
  row: TargetRow;
  busy: boolean;
  onChange: (status: TargetStatus) => void;
  /** ⭐ `true` = বানান ঠিক · `false` = ভুল পাওয়া গেছে */
  onChecked: (ok: boolean) => void;
  onFixed: () => void;
  /** ⭐ "শেষ" ফিরিয়ে নেওয়া *(২৫ আগস্ট)* — যেকোনো দিনের */
  onUndo: () => void;
  /** ⭐ "দেখে নিয়েছি" — কেবল বাদ-যাওয়া সারিতে *(৩১ আগস্ট)* */
  onReviewed: () => void;
  onSkipDecision: (approve: boolean) => void;
  onDelete: (reason: DropReason) => void;
  /** ⚠️ `false` হলে Delete বোতামটাই বসে না — গবেষকের হাতে ওটা থাকবে না */
  mayDelete: boolean;
  /**
   * ⭐ `false` হলে বানান-যাচাইয়ের তিনটে বোতাম বসে না *(২৫ আগস্ট)*।
   *
   * ⚠️ সারির অবস্থার সাথে **এবং** করে দেখা হয়, বদলে নয় — অধিকার
   * থাকলেও ক্রম মানতে হয়: দেখা হয়ে গেলে "Spelling OK" আর ওঠে না।
   */
  mayProofread: boolean;
}) {
  const [confirming, setConfirming] = useState(false);
  /**
   * ⭐⭐ **বাকি বোতামগুলো খোলা আছে কি না** *(মালিকের সিদ্ধান্ত, ২৫ আগস্ট:
   * "khubi gatharing lagoche dekhote")*।
   *
   * ⚠️⚠️ একটা সারি **একটাই** ধাপে থাকে, তবু আগে পাইপলাইনের সব বোতাম
   * একসাথে বসত — একটা শেষ-হওয়া সারিতে ছটা পর্যন্ত। ⭐ এখন এই সারির
   * *পরের ধাপটা* সামনে, বাকিগুলো `⋯`-এ।
   *
   * ⚠️ **কোনো বোতাম মুছে যায়নি** — সবই এক ক্লিক দূরে। পপ-আপ মেনু না
   * করে সারির ভেতরেই খোলা হয়: মেনু বসাতে হলে জায়গা মাপা, বাইরে ক্লিক
   * ধরা, কি-বোর্ড সামলানো — তিনটে নতুন ফাঁদ, একটাও দরকার নেই।
   */
  const [open, setOpen] = useState(false);

  if (row.skipReviewPending) return mayDelete ? (
    <span className="flex flex-wrap justify-end gap-1.5">
      <MiniButton tone="good" disabled={busy} onClick={() => onSkipDecision(true)}>Approve skip</MiniButton>
      <MiniButton disabled={busy} onClick={() => onSkipDecision(false)}>Reject · return to designer</MiniButton>
    </span>
  ) : <span className="text-xs text-ink-3">Waiting for owner or manager</span>;

  /**
   * ⭐⭐ **"Really delete" উঠে গেছে, তার জায়গায় তিনটে কারণ** *(৩১ আগস্ট)*।
   *
   * ⚠️ পুরোনো বোতামটা একটা প্রশ্ন করত যার উত্তরে **কোনো তথ্য ছিল না** —
   * "হ্যাঁ" ছাড়া কিছু জানা যেত না। এখন একই চাপে নিশ্চিতকরণ **আর** কারণ,
   * দুটোই আসে।
   */
  if (confirming) {
    return (
      <DropReasonPicker
        busy={busy}
        onPick={(reason) => {
          setConfirming(false);
          onDelete(reason);
        }}
        onCancel={() => setConfirming(false)}
      />
    );
  }

  /**
   * ⭐⭐ **বাদ-যাওয়া সারিতে একটাই বোতাম — ফেরানোর** *(মালিকের নির্দেশ,
   * ৩১ আগস্ট ২০২৬: "delete kora design e only un delete show korbe",
   * তারপর "same jinis ta kew skip dileO hobe")*।
   *
   * ⚠️⚠️ আগে এই সারিগুলোতেও বসত Complete · Skip · Delete — অর্থাৎ
   * ইতিমধ্যে বাদ-যাওয়া জিনিসকে আবার বাদ দেওয়ার, বা কেউ বানায়নি এমন
   * ডিজাইনকে "শেষ" বলার প্রস্তাব। ⭐ কোনোটাই ক্ষতি করত না (সার্ভার
   * প্রতিটা পথেই আলাদা পাহারা দেয়), কিন্তু পর্দা মিথ্যা বলত — এমন কাজের
   * প্রস্তাব দিত যার কোনো মানে নেই।
   *
   * ⚠️⚠️ **শর্তটা `open`/`next`-এর আগে, আর জায়গাটাই এখানকার আসল কথা।**
   * প্রথমবার এটা নিচে বসানো হয়েছিল — খোলা মেনুর ভেতরে — আর তাতে গোটানো
   * সারিতে `Complete` থেকেই যেত। ⭐ মালিক ছবি পাঠিয়ে ধরিয়ে দিয়েছেন:
   * *"deleted design er pase complete button keno?"*
   *
   * ⭐ **`skipped` ও `deleted` একই আচরণ পায়, কেবল লেখাটা আলাদা** — কর্মটা
   * এক (পুলে ফেরত), কিন্তু বোতামের নাম যেটা ফেরানো হচ্ছে তারই উল্টো
   * শব্দ, নইলে "To pool" পড়ে বোঝা যেত না কী ফিরছে।
   *
   * ⚠️ ফেরত মানে **পুলে ফেরত** (`pool`), আর সার্ভার তখন কারণটাও মুছে দেয়
   * — নইলে সারিটা পুলে ফিরেও "Not Found" বলে দাগানো থাকত, আর পরের বণ্টনে
   * যিনি পেতেন তিনি একটা মীমাংসিত সতর্কবার্তা দেখতেন।
   */
  if (row.status === 'deleted' || row.status === 'skipped') {
    return (
      <span className="flex flex-wrap items-center justify-end gap-1.5">
        {/*
          ⭐⭐ **"দেখে নিয়েছি" — কিউ খালি করার একমাত্র পথ** *(৩১ আগস্ট)*।
          ⚠️ বোতামটা বসে **কেবল যতক্ষণ কেউ দেখেনি**, আর কেবল কারণসহ সারিতে
             (পুরোনো ৯৩টায় কারণ নেই, তাই দেখার কিছুও নেই)। ⭐ দেখা হয়ে
             গেলে বোতামটা উধাও, আর তার জায়গায় নিচের চিপটা বলে কে দেখেছেন।
          ⚠️ `mayDelete` = owner/manager — সার্ভারের `@Roles`-এর সাথে এক।
        */}
        {mayDelete && row.dropReason !== null && row.reviewedAt === null && (
          <MiniButton tone="good" disabled={busy} onClick={onReviewed}>
            Reviewed
          </MiniButton>
        )}
        <MiniButton disabled={busy} onClick={() => onChange('pool')}>
          {row.status === 'deleted' ? 'Undelete' : 'Un-skip'}
        </MiniButton>
      </span>
    );
  }

  /**
   * ⭐⭐ **এই সারির পরের ধাপ** — শেকলের ক্রম মেনে, উপর থেকে নিচে।
   *
   * ⚠️⚠️ ক্রমটাই এখানকার আসল সিদ্ধান্ত: একটা শেষ-হওয়া সারিতে "বানান
   * দেখা" আর "আপলোড" **দুটোই** সম্ভব, কিন্তু আগে বানান। উল্টো করলে
   * না-দেখা ডিজাইন Amazon-এ চলে যেত, আর কিউটা কখনো খালি হতো না।
   *
   * ⚠️ যাচাইয়ের ধাপে **দুটো** বোতাম, কারণ ওটা একটা কাজ নয় — একটা
   * সিদ্ধান্ত (ঠিক আছে, নাকি ভুল আছে)। একটায় নামানো যেত না।
   */
  const broken = row.errorFoundAt !== null && row.fixedAt === null;

  const next: ReactNode =
    mayProofread && broken ? (
      <MiniButton tone="good" disabled={busy} onClick={onFixed}>
        Fixed
      </MiniButton>
    ) : mayProofread && row.completedAt !== null && row.checkedAt === null ? (
      <>
        <MiniButton tone="good" disabled={busy} onClick={() => onChecked(true)}>
          Spelling OK
        </MiniButton>
        <MiniButton tone="danger" disabled={busy} onClick={() => onChecked(false)}>
          Has error
        </MiniButton>
      </>
    ) : row.status !== 'done' ? (
      /*
        ⚠️ নামটা **"Complete"**, "Done" নয় — ডিজাইনারের পাতায় ঠিক এই
           বোতামটাই ওই নামে আছে, আর দুটো আলাদা শব্দ মানে মালিক ভাবতেন
           দুটো আলাদা কাজ (মালিকের প্রশ্ন, ২৩ আগস্ট)।
        ⭐ নিয়মটা: **বোতামে ক্রিয়া** (Complete · Skip), **চিহ্নে অবস্থা**
           (Done · Skipped)।
      */
      <MiniButton tone="good" disabled={busy} onClick={() => onChange('done')}>
        Complete
      </MiniButton>
    ) : null;

  if (!open) {
    return (
      <span className="flex items-center justify-end gap-1.5 whitespace-nowrap">
        {next}
        <MiniButton title={'More actions for ' + row.asin} disabled={busy} onClick={() => setOpen(true)}>
          {'⋯'}
        </MiniButton>
      </span>
    );
  }

  /**
   * খোলা অবস্থা — সব কিছু, ক্রম মেনে।
   *
   * ⚠️⚠️ বোতামগুলো **ক্রম মেনেই দেখা যায়**: শেষ না হলে "Uploaded" নেই,
   * আপলোড না হলে "Live" নেই। সবগুলো একসাথে দেখালে যে-কেউ যেকোনো ক্রমে
   * চাপতে পারতেন, আর তখন পাইপলাইনের সংখ্যাগুলোই অর্থ হারাত। সার্ভারও
   * একই পাহারা দেয় — পর্দা একমাত্র রক্ষী নয়।
   */
  return (
    <span className="flex flex-wrap items-center justify-end gap-1.5">
      {/* ⭐ কারো হাত থেকে তুলে নেওয়া — মালিকানাও ছেড়ে যায় */}
      {row.status !== 'pool' && (
        <MiniButton disabled={busy} onClick={() => onChange('pool')}>
          To pool
        </MiniButton>
      )}
      {row.status !== 'done' && (
        <MiniButton tone="good" disabled={busy} onClick={() => onChange('done')}>
          Complete
        </MiniButton>
      )}
      {mayProofread && row.completedAt !== null && row.checkedAt === null && (
        <>
          <MiniButton tone="good" disabled={busy} onClick={() => onChecked(true)}>
            Spelling OK
          </MiniButton>
          <MiniButton tone="danger" disabled={busy} onClick={() => onChecked(false)}>
            Has error
          </MiniButton>
        </>
      )}
      {mayProofread && broken && (
        <MiniButton tone="good" disabled={busy} onClick={onFixed}>
          Fixed
        </MiniButton>
      )}
      {/*
        ⭐⭐ **"ভুল করে Complete চেপে ফেলেছে"** *(মালিকের রিপোর্ট, ২৫ আগস্ট)*।

        ⚠️⚠️ পাশের "To pool" দিয়ে এটা করা **যায় না** — ওটা মালিকানাও
           ছেড়ে দেয়, তাই কাজটা ডিজাইনারের হাত থেকে বেরিয়ে যেত। এটা
           কেবল "শেষ" চিহ্নটা তোলে, সারিটা তাঁর হাতেই থাকে।

        ⚠️ শেকলে এগিয়ে যাওয়া সারিতে বোতামটাই ওঠে না — বানান দেখা হয়ে
           গেলে বা Amazon-এ চলে গেলে ওটা আর "ভুলে চাপা" নয়, আর ফেরালে
           কিউয়ের সংখ্যাগুলো একসাথে মিথ্যে হয়ে যেত।
      */}
      {row.status === 'done' &&
        row.checkedAt === null &&
        row.uploadedAt === null &&
        row.liveAt === null && (
          <MiniButton disabled={busy} onClick={onUndo}>
            Undo complete
          </MiniButton>
        )}
      {/*
        ⚠️ শর্তটা (`status !== 'skipped'`) উঠে গেছে *(৩১ আগস্ট)* — উপরের
           early return-এর পর এখানে `skipped` সারি আর পৌঁছায়ই না, তাই
           শর্তটা চিরকাল সত্যি ছিল। ⭐ টাইপচেকারই ধরিয়ে দিয়েছে
           ("no overlap"), আর মৃত শর্ত রেখে দেওয়া মানে পরের পাঠককে
           ভাবতে বাধ্য করা যে ওটা কখন মিথ্যা হয়।
      */}
      <MiniButton tone="danger" disabled={busy} onClick={() => onChange('skipped')}>
        Skip
      </MiniButton>
      {/*
        ⚠️ গবেষকের হাতে Delete থাকবে না — ৪৬ হাজার সারির মধ্যে একটা
           ভুল ডিলিট কেউ খুঁজেই পেত না।
      */}
      {mayDelete && row.status !== 'done' && (
        <MiniButton tone="danger" disabled={busy} onClick={() => setConfirming(true)}>
          Delete
        </MiniButton>
      )}
      <MiniButton disabled={busy} onClick={() => setOpen(false)}>
        {'×'}
      </MiniButton>
    </span>
  );
}

