import { getPayroll, type PayrollRow } from '../../api/reports';
import { useApi } from '../../api/useApi';
import { Card } from '../../components/Card';
import { Hours } from '../../components/Duration';
import { ProgressBar } from '../../components/ProgressRing';
import { Caveat, Empty, ErrorBox, Loading } from '../../components/States';
import { STAFF_TYPE_LABEL } from '../../api/admin';
import { PersonCell, Table, type Column } from '../../components/Table';
import {
  formatDate,
  formatMonth,
  formatTaka,
  hoursToSeconds,
} from '../../lib/format';

/**
 * F03 — মাসিক পে-রোল ঘণ্টা শিট। **owner-only**।
 *
 * ⭐⚠️ এই কম্পোনেন্টটা ম্যানেজারের পর্দায় কখনো render হয় না — `ReportsPage`
 *    ট্যাবটাই বানায় না (`user.role === 'owner'` না হলে)। ৪০৩ দেখিয়ে আটকানো
 *    যথেষ্ট নয়: তাহলে "পে-রোল" নামের একটা ট্যাব দেখা যেত, আর **বেতনের
 *    ব্যবস্থাটা যে আছে সেটাই** জানা হয়ে যেত (§ ৪.৩, ADR-023)।
 *
 * ⚠️ প্রতিটা কল সার্ভারে audit-এ লেখা হয় (`payroll_view`) — তাই অকারণে
 *    বারবার fetch করা হয় না, আর `useApi` মাস বদলালেই কেবল আবার আনে।
 *
 * ⚠️ সব ঘণ্টা ও টাকা **স্ট্রিং** (Decimal)। `Number()` করে যোগ-বিয়োগ করা
 *    হয় না — `formatTaka()` শুধু কমা বসায়, নইলে ১৩০০০.১০ পর্দায়
 *    ১৩০০০.০৯৯৯… হয়ে যেত।
 */
export function PayrollTab({ month }: { month: string }) {
  const { data, error, loading, reload } = useApi(
    (signal) => getPayroll(month, signal),
    [month],
  );

  if (loading && !data) return <Loading label="Loading payroll…" />;
  if (error) return <ErrorBox error={error} retry={reload} />;

  if (!data || data.rows.length === 0) {
    return (
      <Empty
        title={`No rows for ${formatMonth(month)}`}
        hint={
          data && data.missingSummary.length > 0
            ? `The monthly figures for these ${data.missingSummary.length} are not built yet: ${data.missingSummary.join(', ')}. The rows appear once the month ends or the nightly rollup runs.`
            : 'The monthly figures for that month are not built yet. Try an earlier month.'
        }
      />
    );
  }

  const columns: Column<PayrollRow>[] = [
    {
      key: 'person',
      header: 'Staff',
      render: (row) => (
        <PersonCell
          fullName={row.fullName}
          empCode={row.empCode}
          note={row.staffType ? STAFF_TYPE_LABEL[row.staffType] : undefined}
        />
      ),
    },
    {
      key: 'target',
      header: 'Target',
      align: 'right',
      /**
       * ⭐ **G37** — টার্গেট এখন **তার কর্মদিবস × ৮**, ফ্ল্যাট ২০৮ নয়।
       *
       * ⚠️ পুরো মাস না থাকলে নিচে দিনের হিসাবটা দেখানো হয় (`১৩ / ২৭ দিন`)।
       * ছাড়া দিলে owner দেখতেন একজনের টার্গেট ২১৬ঘ আর আরেকজনের ১০৪ঘ,
       * কোনো ব্যাখ্যা ছাড়াই — আর বেতনের ঘরেও কম সংখ্যা, কারণ অদৃশ্য।
       */
      render: (row) => (
        <div className="flex flex-col items-end">
          <Hours hours={row.targetHours} tone="muted" />
          {row.workdays < row.monthWorkdays && (
            <span className="text-xs text-idle" title="Joined or left mid-month — target and salary are both prorated">
              {row.workdays} / {row.monthWorkdays} days
            </span>
          )}
        </div>
      ),
    },
    {
      key: 'credited',
      header: 'Counted',
      align: 'right',
      render: (row) => (
        <Hours hours={row.creditedHours} className="font-semibold" />
      ),
    },
    {
      key: 'pace',
      header: 'Progress',
      className: 'w-24',
      render: (row) => (
        <ProgressBar
          value={hoursToSeconds(row.creditedHours)}
          max={hoursToSeconds(row.targetHours)}
          ariaLabel="Target"
        />
      ),
    },
    {
      key: 'shortfall',
      header: 'Shortfall',
      align: 'right',
      render: (row) =>
        Number(row.shortfallHours) > 0 ? (
          <span className="font-semibold text-brand-ink">
            <Hours hours={row.shortfallHours} />
          </span>
        ) : (
          <span className="num text-ink-3">—</span>
        ),
    },
    {
      /**
       * ⚠️⚠️ এই কলামে **কেবল ঘণ্টা** — কোনো টাকা নয়। OT-র হার নির্ধারিত
       *    হয়নি (O4), তাই সার্ভারও কোনো অঙ্ক পাঠায় না। এখানে নিজে থেকে
       *    "× ১.৫" বসিয়ে দিলে সেটাই নীরবে কোম্পানির নীতি হয়ে যেত।
       */
      key: 'overtime',
      header: 'Overtime',
      align: 'right',
      render: (row) =>
        Number(row.overtimeHours) > 0 ? (
          <Hours hours={row.overtimeHours} />
        ) : (
          <span className="num text-ink-3">—</span>
        ),
    },
    {
      key: 'salary',
      header: 'Monthly salary',
      align: 'right',
      // ⚠️ `null` = বেতন **বসানো নেই**, শূন্য নয়। `—` লিখলে দুটো এক দেখাত,
      //    আর তখন কারো বেতন বসাতে ভুলে যাওয়া ধরাই পড়ত না।
      render: (row) =>
        row.monthlySalary === null ? (
          <span className="text-[11.5px] text-ink-3">Not set</span>
        ) : (
          <span className="num">{formatTaka(row.monthlySalary)}</span>
        ),
    },
    {
      key: 'rate',
      header: 'Hourly rate',
      align: 'right',
      render: (row) => (
        <span className="num text-ink-3">{formatTaka(row.hourlyRate)}</span>
      ),
    },
    {
      key: 'deduction',
      header: 'Deduction',
      align: 'right',
      render: (row) =>
        row.deduction !== null && Number(row.deduction) > 0 ? (
          <span className="num text-brand-ink">{formatTaka(row.deduction)}</span>
        ) : (
          <span className="num text-ink-3">{formatTaka(row.deduction)}</span>
        ),
    },
    {
      key: 'payable',
      header: 'Payable',
      align: 'right',
      render: (row) => (
        <span className="num">{formatTaka(row.payable)}</span>
      ),
    },
    {
      /**
       * ⭐⭐ **R21 — এই মাসের জামানতের কিস্তি**।
       *
       * ⚠️ `—` মানে এই মাসে কিস্তি নেই (খাতা শুরু হয়নি, বা নিষ্পত্তি
       *    হয়ে গেছে)। ০ নয়, কারণ ৳০-র কিস্তি বলে কিছু নেই (G145)।
       */
      key: 'deposit',
      header: 'Deposit',
      align: 'right',
      render: (row) =>
        row.securityDeposit === null ? (
          <span className="num text-ink-3">—</span>
        ) : (
          <span className="num text-brand-ink">
            {formatTaka(row.securityDeposit)}
          </span>
        ),
    },
    {
      /**
       * ⭐⭐⭐ **হাতে যা যাবে** — শিটের শেষ কথা, তাই এটাই মোটা করে লেখা।
       *
       * ⚠️⚠️ **এই কলামটা ছ-দিন আগেও ছিল না**, অথচ সার্ভার সংখ্যাটা
       * পাঠাচ্ছিল আর নিচের সতর্কবার্তাটা এর নাম ধরেই কথা বলত
       * (*"Net payable stops at zero"*)। ফলে মালিক টাকা দিতেন
       * `Payable` দেখে — জামানত না কেটেই।
       *
       * ⚠️ `null` = বেতন বসানো নেই, তাই নিট বের করা যায় না। শূন্য নয়।
       */
      key: 'net',
      header: 'Net payable',
      align: 'right',
      render: (row) =>
        row.netPayable === null ? (
          <span className="text-[11.5px] text-ink-3">Not set</span>
        ) : (
          <span className="num font-semibold">{formatTaka(row.netPayable)}</span>
        ),
    },
  ];

  return (
    <>
      <Card
        title={`Payroll Hours · ${formatMonth(month)}`}
        hint="Deduction = salary × shortfall ÷ target, and shortfall counts only the days we actually watched. Net payable = payable − deposit. Every view of this sheet is written to the audit log."
        padded={false}
      >
        <Table
          columns={columns}
          rows={data.rows}
          rowKey={(row) => String(row.employeeId)}
          rowMuted={(row) => row.monthlySalary === null}
        />
      </Card>

      {/* ⭐ O4 — সার্ভারের `payroll.math.ts`-ও ঠিক এই কথাটাই বলে */}
      <Caveat>
        No money is calculated for overtime — there is no separate overtime
        rate (O4, settled 23 Aug). “Payable” above is only the salary minus the
        shortfall deduction.
      </Caveat>

      {data.missingSalary.length > 0 && (
        <Caveat>
          These <span className="num">{data.missingSalary.length}</span> have no
          salary on file, so no deduction or payable could be worked out for
          them (they are not treated as zero): {data.missingSalary.join(', ')}
        </Caveat>
      )}

      {data.missingSummary.length > 0 && (
        <Caveat>
          These <span className="num">{data.missingSummary.length}</span> have
          no figures for that month yet, so they are <b>not</b> in the table
          above: {data.missingSummary.join(', ')}
        </Caveat>
      )}

      {/*
        ⚠️⚠️ R21 — নিট শূন্যে থামা নীরবে ঘটতে দেওয়া যায় না। সার্ভার ঘরটা
        বরাবরই পাঠাত, শুধু পর্দা পড়ত না।
      */}
      {data.depositExceedsPayable.length > 0 && (
        <Caveat>
          For these{' '}
          <span className="num">{data.depositExceedsPayable.length}</span> the
          security-money instalment is larger than what they earned this month,
          so “Net payable” stops at zero and the full instalment could not be
          taken: {data.depositExceedsPayable.join(', ')}
        </Caveat>
      )}

      {/*
        ⭐⭐ G108 — এই পাতার সংখ্যাগুলোই সবচেয়ে বেশি ক্ষতি করতে পারে, কারণ
        এখানেই `d ÷ D` দিয়ে সত্যিই টাকা কাটা হয়। তারিখ নড়লে ছাপা হয়ে
        যাওয়া শিটটাই ভুল হয়ে যায়।
      */}
      {data.approximateHolidayDates.length > 0 && (
        <Caveat>
          <span className="num">{data.approximateHolidayDates.length}</span>{' '}
          holiday date
          {data.approximateHolidayDates.length > 1 ? 's' : ''} in this month{' '}
          {data.approximateHolidayDates.length > 1 ? 'are' : 'is'} not final yet
          (
          {data.approximateHolidayDates.map((d, i) => (
            <span key={d}>
              {i > 0 && ', '}
              <b className="num">{formatDate(d)}</b>
            </span>
          ))}
          ). If one moves, the working days for this month change — and the
          day fraction these payables are built on changes with them.
        </Caveat>
      )}
    </>
  );
}
