import {
  getSummaryReport,
  type GroupBy,
  type SummaryRow,
} from '../../api/reports';
import { useApi } from '../../api/useApi';
import { Card } from '../../components/Card';
import { Hours } from '../../components/Duration';
import { ProgressBar } from '../../components/ProgressRing';
import { Caveat, Empty, ErrorBox, Loading } from '../../components/States';
import { PersonCell, Table, type Column } from '../../components/Table';
import {
  formatCount,
  formatDateShort,
  formatMonth,
  hoursToSeconds,
} from '../../lib/format';
import { MAX_SHOWN_ROWS, MetaNote, SignedHours, TrimmedNote } from './shared';

/**
 * F02 — সাপ্তাহিক/মাসিক সারাংশ: worked · target · shortfall · overtime।
 *
 * ⭐⚠️ **অতিরিক্ত ঘণ্টার টাকা এখানে কখনো দেখানো হবে না** — শুধু ঘণ্টা।
 *    OT-র হার (১×, ১.৫×, নাকি কিছুই না) এখনো ঠিক হয়নি (open question O4)।
 *    পর্দায় একটা টাকার অঙ্ক বসিয়ে দিলে সেই হারটাই নীরবে কোম্পানির নীতি
 *    হয়ে যেত, অথচ সিদ্ধান্তটা কেউ নেয়নি। সার্ভারও তাই `overtimeNote`
 *    পাঠায় — সেটা নিচে হুবহু দেখানো হয়।
 */
export function SummaryTab({
  from,
  to,
  employeeId,
  groupBy,
}: {
  from: string;
  to: string;
  employeeId: number | null;
  groupBy: GroupBy;
}) {
  const { data, error, loading, reload } = useApi(
    (signal) =>
      getSummaryReport(
        { from, to, employeeId: employeeId ?? undefined, groupBy },
        signal,
      ),
    [from, to, employeeId, groupBy],
  );

  if (loading && !data) return <Loading label="Loading summary…" />;
  if (error) return <ErrorBox error={error} retry={reload} />;
  if (!data || data.rows.length === 0) {
    return (
      <Empty
        title="No summary for this range"
        hint="Summaries are built from the daily figures. Until the agent sends data this page stays empty — try other dates."
      />
    );
  }

  const shown = data.rows.slice(0, MAX_SHOWN_ROWS);

  /**
   * ⚠️ মাসে `bucket` = `'2026-08'`, সপ্তাহে সপ্তাহ-শুরুর তারিখ। কিন্তু
   *    `bucketStart`/`bucketEnd` **পুরো** মাস/সপ্তাহ নয় — রেঞ্জ ও কর্মকালের
   *    যতটুকু ভেতরে পড়েছে ততটুকু। তাই সপ্তাহে দুই প্রান্তই দেখানো হয়,
   *    নইলে "১০ আগস্ট থেকে সপ্তাহ" পড়ে কেউ ধরে নিত পুরো সাত দিনই আছে।
   */
  const bucketLabel = (row: SummaryRow): string =>
    groupBy === 'month'
      ? formatMonth(row.bucket)
      : `${formatDateShort(row.bucketStart)} – ${formatDateShort(row.bucketEnd)}`;

  const columns: Column<SummaryRow>[] = [
    {
      key: 'person',
      header: 'Staff',
      render: (row) => (
        <PersonCell fullName={row.fullName} empCode={row.empCode} />
      ),
    },
    {
      key: 'bucket',
      header: groupBy === 'month' ? 'Month' : 'Week',
      render: (row) => (
        <span className="num whitespace-nowrap">{bucketLabel(row)}</span>
      ),
    },
    {
      key: 'workdays',
      header: 'Workdays',
      align: 'right',
      render: (row) => (
        <span className="num text-ink-3">{formatCount(row.workdays)}</span>
      ),
    },
    {
      key: 'daysWithWork',
      header: 'Days worked',
      align: 'right',
      render: (row) => (
        <span className="num">{formatCount(row.daysWithWork)}</span>
      ),
    },
    {
      key: 'worked',
      header: 'Worked',
      align: 'right',
      render: (row) => <Hours hours={row.workedHours} />,
    },
    {
      key: 'adjustment',
      header: 'Adjustment',
      align: 'right',
      render: (row) => <SignedHours hours={row.adjustmentHours} />,
    },
    {
      key: 'credited',
      header: 'Counted',
      align: 'right',
      render: (row) => (
        <Hours hours={row.creditedHours} className="font-semibold" />
      ),
    },
    {
      /**
       * ⚠️ হেডারে "days shown" — এটা এই সারির দিনগুলোর টার্গেট, "এ পর্যন্ত
       *    কত হওয়ার কথা ছিল" নয়। শুধু "Target" লেখা থাকলে পাঠক পাশের
       *    Counted থেকে বিয়োগ করে নিজের মতো একটা ঘাটতি বানিয়ে ফেলতেন —
       *    আর সেই বানানো সংখ্যাটায় এজেন্ট বসার আগের দিনগুলোও থাকত।
       */
      key: 'target',
      header: 'Target · days shown',
      align: 'right',
      render: (row) => <Hours hours={row.targetHours} tone="muted" />,
    },
    {
      // ⭐ বার পূর্ণ হলে **সবুজ** হয়ে যায় (`ProgressBar`-এর নিয়ম) — টার্গেট
      //    ছোঁয়া কোনো সমস্যা নয়, তাই ওটা লাল থাকে না। চলতি অবস্থায়
      //    নিরপেক্ষ `ink`; লাল এই টেবিলে শুধু ঘাটতির কলামে।
      key: 'pace',
      header: 'Progress',
      className: 'w-24',
      render: (row) => (
        <ProgressBar
          value={hoursToSeconds(row.creditedHours)}
          max={hoursToSeconds(row.targetHours)}
          ariaLabel="Target"
        />
      ),
    },
    {
      // ⚠️ ঘাটতিই একমাত্র লাল সংখ্যা এই টেবিলে — লাল মানে "মনোযোগ দরকার",
      //    আর সব কলাম লাল করলে লালের মানেই হারিয়ে যেত।
      // ⚠️⚠️ হেডারে "vs expected" — সংখ্যাটা Target বিয়োগ Counted **নয়**।
      //    সার্ভার এটা মাপে কেবল সেই দিনগুলোর বিপরীতে যেগুলো সত্যিই দেখা
      //    হয়েছে ও শেষ হয়েছে (`SummaryRow.shortfallHours`)। কথাটা না
      //    লিখলে টেবিলটা নিজেই নিজের সাথে অমিল দেখাত।
      key: 'shortfall',
      header: 'Shortfall vs expected',
      align: 'right',
      render: (row) =>
        row.shortfallHours > 0 ? (
          <span className="num font-semibold text-brand-ink">
            <Hours hours={row.shortfallHours} />
          </span>
        ) : (
          <span className="num text-ink-3">—</span>
        ),
    },
    {
      key: 'overtime',
      header: 'Overtime',
      align: 'right',
      render: (row) =>
        row.overtimeHours > 0 ? (
          <Hours hours={row.overtimeHours} />
        ) : (
          <span className="num text-ink-3">—</span>
        ),
    },
  ];

  return (
    <>
      {/*
        ⭐⭐ `hint`-এর বাক্যটাই এই টেবিলের চাবি: তিনটে সংখ্যা তিনটে আলাদা
        প্রশ্নের উত্তর। এটা ছাড়া পাঠক Target থেকে Counted বিয়োগ করে মেলাতে
        গিয়ে ভাবতেন Shortfall কলামে ভুল আছে।
      */}
      <Card
        title={groupBy === 'month' ? 'Month by Month' : 'Week by Week'}
        hint="Counted = worked + adjustment. Shortfall is measured only against what was expected by yesterday — days before tracking started, and today, are never counted as a shortfall."
        padded={false}
      >
        <Table
          columns={columns}
          rows={shown}
          // ⚠️ একই কর্মীর একাধিক বালতি আসে, তাই দুটোই কী-তে দরকার
          rowKey={(row) => `${row.employeeId}-${row.bucket}`}
        />
        {data.rows.length > shown.length && (
          <TrimmedNote total={data.rows.length} />
        )}
      </Card>

      {/* ⭐ সার্ভারের নিজের বাক্য — এটাই O4-কে খোলা রাখে */}
      <Caveat>{data.overtimeNote}</Caveat>

      <MetaNote meta={data.meta} />
    </>
  );
}
