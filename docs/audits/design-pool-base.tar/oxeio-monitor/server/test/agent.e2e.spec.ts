import { randomUUID } from 'node:crypto';

import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';

import { AppCategoryService } from '../src/activity/app-category.service';
import {
  createEmployeeWithCode,
  createHarness,
  enrollDevice,
  iso,
  minutesAgo,
  resetDatabase,
  todayWindow,
  type EnrolledDevice,
  type Harness,
  dhakaNoon,
  realNow,
} from './setup/harness';

let h: Harness;
let code: string;
let device: EnrolledDevice;

const WEBP = Buffer.from([
  0x52, 0x49, 0x46, 0x46, 0x00, 0x00, 0x00, 0x00, 0x57, 0x45, 0x42, 0x50,
]);

/** এজেন্টের প্রতিটি রিকোয়েস্টে যা সবসময় থাকে: টোকেন + নিজের ঘড়ির সময় */
function asAgent<T extends { set(field: string, val: string): T }>(
  req: T,
  token: string,
): T {
  return req
    .set('Authorization', `Bearer ${token}`)
    .set('X-Client-Time', iso(realNow()));
}

beforeAll(async () => {
  h = await createHarness();
});

afterAll(async () => {
  await h.close();
});

beforeEach(async () => {
  await resetDatabase(h.prisma, h.app);
  ({ code } = await createEmployeeWithCode(h.prisma));
  device = await enrollDevice(h, code);
});

describe('enrollment (H05)', () => {
  it('ভুল কোডে 401', async () => {
    await h
      .http()
      .post('/api/v1/agent/enroll')
      .send({
        enrollmentCode: 'WRONGCODE',
        hostname: 'PC-08',
        windowsUsername: 'x',
        machineGuid: 'guid-x',
      })
      .expect(401);
  });

  it('সঠিক কোডে টোকেন ও কনফিগ আসে', async () => {
    expect(device.token.length).toBeGreaterThan(20);
    expect(device.configVersion).toBeTruthy();
  });

  it('কোড একবারই ব্যবহার করা যায়', async () => {
    await h
      .http()
      .post('/api/v1/agent/enroll')
      .send({
        enrollmentCode: code,
        hostname: 'PC-07',
        windowsUsername: 'rakib',
        machineGuid: 'guid-test-001',
      })
      .expect(401);
  });

  it('টোকেন plaintext-এ জমা হয় না (I02)', async () => {
    const row = await h.prisma.device.findFirstOrThrow({
      where: { id: device.deviceId },
    });
    expect(row.tokenHash).not.toBe(device.token);
    expect(row.tokenHash).toHaveLength(64); // sha256 hex
  });
});

describe('device auth', () => {
  it('টোকেন ছাড়া 401', async () => {
    await h.http().get('/api/v1/agent/config').expect(401);
  });

  it('ভুল টোকেনে 401', async () => {
    await h
      .http()
      .get('/api/v1/agent/config')
      .set('Authorization', 'Bearer garbage')
      .expect(401);
  });

  it('সঠিক টোকেনে কনফিগ আসে, ক্যাপচার উইন্ডো সহ', async () => {
    const res = await asAgent(
      h.http().get('/api/v1/agent/config'),
      device.token,
    ).expect(200);

    expect(res.body.config.screenshotFrom).toBe('07:00');
    expect(res.body.config.screenshotTo).toBe('23:00');
    expect(res.body.config.idleThresholdSec).toBe(60);
  });

  it('revoke করা ডিভাইস 403 পায় (H06)', async () => {
    await h.prisma.device.update({
      where: { id: device.deviceId },
      data: { status: 'revoked' },
    });

    const res = await asAgent(
      h.http().get('/api/v1/agent/config'),
      device.token,
    ).expect(403);
    expect(res.body.command).toBe('revoke');
  });
});

describe('heartbeat', () => {
  it('কনফিগ ভার্সন মিললে কোনো কমান্ড নেই', async () => {
    const res = await asAgent(
      h.http().post('/api/v1/agent/heartbeat'),
      device.token,
    )
      .send({
        state: 'active',
        activeSecToday: 1200,
        queueDepth: 0,
        configVersion: device.configVersion,
      })
      .expect(200);

    expect(res.body.commands).toEqual([]);
  });

  /**
   * ⭐ এজেন্ট নিজে মাসের হিসাব জানে না — রিবুটের পর তার কাউন্টার শূন্য থেকে
   * শুরু হয়। সংখ্যাটা সার্ভার না দিলে tray-তে "০ ঘ / ২০৮ঘ" দেখাত, আর স্টাফ
   * ভাবত তার মাসের কাজ মুছে গেছে।
   */
  it('heartbeat-এ মাসিক অগ্রগতি ফেরত আসে', async () => {
    const worked = todayWindow(600);

    await asAgent(h.http().post('/api/v1/agent/segments'), device.token)
      .send({
        segments: [
          {
            clientUuid: randomUUID(),
            state: 'active',
            startedAt: iso(worked.startedAt),
            endedAt: iso(worked.endedAt),
            durationSec: worked.durationSec,
          },
        ],
      })
      .expect(200);

    const res = await asAgent(
      h.http().post('/api/v1/agent/heartbeat'),
      device.token,
    )
      .send({
        state: 'active',
        activeSecToday: worked.durationSec,
        queueDepth: 0,
      })
      .expect(200);

    expect(res.body.progress).toBeTruthy();
    expect(res.body.progress.todayActiveSec).toBe(worked.durationSec);
    expect(res.body.progress.monthActiveSec).toBe(worked.durationSec);
    // ⭐ G37 — কর্মদিবস × ৮, তাই মাসভেদে বদলায় (ADR-025)। দাবিটা নিয়মের।
    const target = res.body.progress.monthlyTargetHours as number;
    expect(target % 8).toBe(0);
    expect(target).toBeGreaterThanOrEqual(20 * 8);
    expect(target).toBeLessThanOrEqual(27 * 8);

    // ── আজ ও ৭ দিনের টার্গেট — tray-র তিনটে বারের জন্য ──────────────────

    const { dailyTargetSec, week7ActiveSec, week7TargetSec } = res.body.progress;

    /**
     * ⚠️ নির্দিষ্ট সংখ্যা মেলানো হয় না — মাসের কর্মদিবস কয়টা সেটা টেস্ট
     * কোন তারিখে চলছে তার উপর নির্ভর করে, আর সেটা বাঁধলে টেস্টটা মাসে
     * একবার নিজে থেকেই ভাঙত (G62-র মতোই সময়ের বোমা)।
     * তাই **সম্পর্কগুলো** যাচাই করা হয়, মানগুলো নয়।
     */
    expect(typeof dailyTargetSec).toBe('number');

    // ছুটির দিনে ০, নইলে এক কর্মদিবসের ভাগ — ২৪ ঘণ্টার বেশি কখনো নয়
    expect(dailyTargetSec).toBeGreaterThanOrEqual(0);
    expect(dailyTargetSec).toBeLessThanOrEqual(86_400);

    // ৭ দিনের কাজ আজকের কাজের চেয়ে কম হতে পারে না (আজ ওই ৭ দিনের ভেতরেই)
    expect(week7ActiveSec).toBeGreaterThanOrEqual(worked.durationSec);

    /**
     * ৭ দিনে সর্বোচ্চ ৭টা কর্মদিবস, তাই টার্গেটও তার বেশি নয়।
     *
     * ⚠️⚠️ **কেবল কর্মদিবসে** — আর এটাই ছিল একটা ঘুমন্ত সময়-বোমা
     * *(ফেটেছে শুক্রবার ২১ আগস্ট ২০২৬)*। ছুটির দিনে `dailyTargetSec`
     * **০** (সেটাই সঠিক, `progress.service.ts` দেখুন), অথচ গত ৭ দিনে
     * ৬টা কর্মদিবস থাকায় `week7TargetSec` = ৪৮ ঘণ্টা। তখন দাবিটা দাঁড়াত
     * `172800 ≤ 0` — অর্থাৎ টেস্টটা **প্রতি শুক্রবার** ভাঙত, আর কোডে
     * কোনো ভুল না থাকা সত্ত্বেও।
     *
     * ⭐ নিচের দাবিটা (মাসিক টার্গেটের চেয়ে বড় নয়) ছুটির দিনেও খাটে, আর
     * আসল ঝুঁকিটা — ভুল হরে ভাগ — ওটাই ধরে।
     */
    if (dailyTargetSec > 0) {
      expect(week7TargetSec).toBeLessThanOrEqual(dailyTargetSec * 7);
    }

    // ⚠️ মাসের টার্গেটের চেয়ে বড় হতে পারে না — হলে বুঝতে হবে দৈনিক ভাগটা
    //    ভুল হরে ভাগ হচ্ছে, আর tray-তে ৭ দিনের বার সবসময় ভরা দেখাত
    expect(week7TargetSec).toBeLessThanOrEqual(target * 3600);
  });

  /**
   * ⭐ ছুটির দিনে দৈনিক টার্গেট **০**, আর সেটা "সার্ভার বলেনি" (null) থেকে
   * আলাদা। ⚠️ দুটো এক করে ফেললে tray ছুটির দিনেও "৮ ঘণ্টা বাকি" বলে তাড়া
   * দিত — অথচ নিয়ম হলো ছুটির দিনে কাজ করলে সেটা গোনা হয়, কিন্তু করতেই
   * হবে এমন নয় (§ ৪)।
   */
  it('ছুটির দিনে দৈনিক টার্গেট শূন্য, null নয়', async () => {
    /**
     * ⚠️⚠️ **ঢাকার** তারিখ, UTC-র নয় — G62-র হুবহু পুনরাবৃত্তি।
     *
     * আগে এখানে `getUTCFullYear/Month/Date` দিয়ে আজকের তারিখ বানানো হতো।
     * দিনের বেলায় দুটো এক, তাই টেস্ট পাস করত। কিন্তু ঢাকার মধ্যরাত থেকে
     * ভোর ৬টার মধ্যে UTC তখনো **আগের দিনে** — ফলে ছুটিটা বসত গতকালের
     * ঘরে, সার্ভার আজকের দিনটাকে কর্মদিবসই দেখত, আর টার্গেট ০-র বদলে
     * ২৮,৮০০ আসত। ঠিক ০০:২২-এ ধরা পড়েছে।
     */
    const workDate = dhakaNoon();
    workDate.setUTCHours(0, 0, 0, 0);

    await h.prisma.holiday.create({
      data: { holidayDate: workDate, name: 'Test holiday' },
    });

    const res = await asAgent(
      h.http().post('/api/v1/agent/heartbeat'),
      device.token,
    )
      .send({ state: 'active', activeSecToday: 0, queueDepth: 0 })
      .expect(200);

    expect(res.body.progress.dailyTargetSec).toBe(0);
  });

  /**
   * ⭐ enroll-এ ভার্সন একবার বসে, তারপর আর হালনাগাদ হতো না। ⚠️ এটা শুধু
   * ড্যাশবোর্ডের সংখ্যা নয় — heartbeat **এই মান দেখেই** ঠিক করে আপডেট
   * অফার করবে কি না, তাই স্টেল থাকলে আপডেট হয়ে যাওয়া এজেন্টকেও একই
   * আপডেট বারবার অফার করা হতো (G59)।
   */
  it('heartbeat-এ পাঠানো নতুন ভার্সন ডিভাইসে বসে যায়', async () => {
    await asAgent(h.http().post('/api/v1/agent/heartbeat'), device.token)
      .send({ state: 'active', activeSecToday: 10, agentVersion: '9.9.9' })
      .expect(200);

    const row = await h.prisma.device.findUniqueOrThrow({
      where: { id: device.deviceId },
    });
    expect(row.agentVersion).toBe('9.9.9');
  });

  /**
   * ⭐⭐⭐ **রোলআউট নিজে থেকে এগোনোর একমাত্র প্রমাণ এখানেই বসে**
   * *(৫ সেপ্টেম্বর ২০২৬)*।
   *
   * ⚠️⚠️ `agent_version_since` না বসলে `RolloutAdvanceJob` কোনোদিন কোনো
   * প্রমাণ পেত না, আর রোলআউট **চিরকাল canary-তেই** আটকে থাকত — অর্থাৎ ঠিক
   * যে সমস্যাটা সারানো হচ্ছে সেটাই ফিরে আসত, কেবল আরও নীরবে। কলামটা যোগ
   * করা আর কলামটা **ভরা** — এই প্রকল্পে দুটোর মাঝখানেই দশবারের বেশি বাগ
   * হয়েছে।
   */
  it('⭐ নতুন ভার্সন বসলে "কবে থেকে"-ও বসে', async () => {
    /**
     * ⚠️ `realNow()` — `dhakaNoon()` নয়, আর এটা G140-র ব্যতিক্রম নয়, তার
     *    বৈধ ব্যবহার। সময়টা লেখে **সার্ভার**, তার নিজের ঘড়ি দিয়ে; তুলনাটাও
     *    তাই আসল ঘড়ির সাপেক্ষেই হতে হয়। পিন করা দুপুর দিলে দিনে দুবার
     *    ভুল ফল আসত।
     */
    const before = realNow();

    await asAgent(h.http().post('/api/v1/agent/heartbeat'), device.token)
      .send({ state: 'active', activeSecToday: 10, agentVersion: '9.9.9' })
      .expect(200);

    const row = await h.prisma.device.findUniqueOrThrow({
      where: { id: device.deviceId },
    });

    expect(row.agentVersionSince).not.toBeNull();
    expect(row.agentVersionSince!.getTime()).toBeGreaterThanOrEqual(
      before.getTime() - 1000,
    );
  });

  /**
   * ⭐⭐⭐ **সময়টা বসে কেবল ভার্সন বদলালে — প্রতি heartbeat-এ নয়।**
   *
   * ⚠️⚠️ এটাই এই ফিচারের সবচেয়ে সহজে ভুল হওয়া লাইন। প্রতিবার বসালে ঘড়িটা
   * প্রতি ৩০ সেকেন্ডে শূন্য থেকে শুরু হতো, আর "ছ-ঘণ্টা ধরে টিকে আছে"
   * শর্তটা **কোনোদিনই** সত্যি হতো না। ⭐ ব্যর্থতাটা হতো নীরব: কোনো এরর
   * নেই, শুধু রোলআউট আর কখনো এগোত না।
   */
  it('⭐ একই ভার্সনে দ্বিতীয় heartbeat — ঘড়িটা নড়ে না', async () => {
    await asAgent(h.http().post('/api/v1/agent/heartbeat'), device.token)
      .send({ state: 'active', activeSecToday: 10, agentVersion: '9.9.9' })
      .expect(200);

    const first = (
      await h.prisma.device.findUniqueOrThrow({ where: { id: device.deviceId } })
    ).agentVersionSince;

    await asAgent(h.http().post('/api/v1/agent/heartbeat'), device.token)
      .send({ state: 'idle', activeSecToday: 20, agentVersion: '9.9.9' })
      .expect(200);

    const second = (
      await h.prisma.device.findUniqueOrThrow({ where: { id: device.deviceId } })
    ).agentVersionSince;

    expect(second).toEqual(first);
  });

  it('ভার্সন না পাঠালে আগেরটাই থাকে — মুছে যায় না', async () => {
    await asAgent(h.http().post('/api/v1/agent/heartbeat'), device.token)
      .send({ state: 'active', activeSecToday: 10, agentVersion: '1.2.3' })
      .expect(200);

    // ⚠️ পুরোনো এজেন্ট (যে ফিল্ডটা চেনেই না) heartbeat পাঠালে ভার্সন
    //    null হয়ে যাওয়া চলবে না — তাতে আপডেট অফার বন্ধ হয়ে যেত।
    await asAgent(h.http().post('/api/v1/agent/heartbeat'), device.token)
      .send({ state: 'active', activeSecToday: 20 })
      .expect(200);

    const row = await h.prisma.device.findUniqueOrThrow({
      where: { id: device.deviceId },
    });
    expect(row.agentVersion).toBe('1.2.3');
  });

  it('ভার্সন না মিললে reload_config', async () => {
    const res = await asAgent(
      h.http().post('/api/v1/agent/heartbeat'),
      device.token,
    )
      .send({ state: 'active', activeSecToday: 1, configVersion: 'stale' })
      .expect(200);

    expect(res.body.commands).toContain('reload_config');
  });

  it('last_seen_at হালনাগাদ হয় (G01-এর ভিত্তি)', async () => {
    const before = await h.prisma.device.findFirstOrThrow({
      where: { id: device.deviceId },
    });
    await new Promise((r) => setTimeout(r, 20));

    await asAgent(h.http().post('/api/v1/agent/heartbeat'), device.token)
      .send({ state: 'active', activeSecToday: 5 })
      .expect(200);

    const after = await h.prisma.device.findFirstOrThrow({
      where: { id: device.deviceId },
    });
    expect(after.lastSeenAt!.getTime()).toBeGreaterThan(
      before.lastSeenAt!.getTime(),
    );
  });

  /**
   * ⭐ Live Board-এর রঙ এই দুটো কলামের উপর দাঁড়ানো। আগে `state` নেওয়া হতো
   * কিন্তু কোথাও লেখা হতো না, তাই বোর্ড শেষ `activity_segments` সারি থেকে
   * অনুমান করত — আর এজেন্ট সেগমেন্ট ব্যাচে পাঠায় বলে ওই অনুমান কয়েক মিনিট
   * পুরোনো। ৩০ সেকেন্ডে রিফ্রেশ হওয়া বোর্ডের জন্য সেটা অর্থহীন।
   */
  it('heartbeat-এর state ডিভাইসে জমা হয়', async () => {
    await asAgent(h.http().post('/api/v1/agent/heartbeat'), device.token)
      .send({ state: 'idle', activeSecToday: 30 })
      .expect(200);

    const row = await h.prisma.device.findUniqueOrThrow({
      where: { id: device.deviceId },
    });
    expect(row.lastState).toBe('idle');
    expect(row.lastStateAt).not.toBeNull();
  });

  /**
   * ⚠️ `lastState` বদলায়নি বলে `lastStateAt`-ও না বসালে সবচেয়ে খারাপ বাগটা
   * ফিরে আসত: এজেন্ট একটানা `active` বলতে বলতে মরে গেলে সময়টা তার মৃত্যুর
   * মুহূর্তে আটকে থাকত না — আটকে থাকত **প্রথমবার active বলার** মুহূর্তে।
   * বোর্ড তখন সুস্থ, সক্রিয় কর্মীর টাটকা রিপোর্টকেও বাসি ধরে ফেলে দিত।
   */
  it('state না বদলালেও lastStateAt প্রতিবার এগোয়', async () => {
    await asAgent(h.http().post('/api/v1/agent/heartbeat'), device.token)
      .send({ state: 'active', activeSecToday: 10 })
      .expect(200);
    const first = await h.prisma.device.findUniqueOrThrow({
      where: { id: device.deviceId },
    });

    await new Promise((r) => setTimeout(r, 20));

    await asAgent(h.http().post('/api/v1/agent/heartbeat'), device.token)
      .send({ state: 'active', activeSecToday: 20 })
      .expect(200);
    const second = await h.prisma.device.findUniqueOrThrow({
      where: { id: device.deviceId },
    });

    expect(second.lastState).toBe('active');
    expect(second.lastStateAt!.getTime()).toBeGreaterThan(
      first.lastStateAt!.getTime(),
    );
  });
});

describe('segments — dedupe ও যাচাই (§ ২.১-ঘ)', () => {
  /**
   * ⚠️ টাইমস্ট্যাম্প **সবসময় ঢাকার আজকের দিনের ভেতরে** রাখতে হয়।
   *
   * আগে এখানে `minutesAgo(30)` ছিল। মধ্যরাতের ঠিক পরে টেস্ট চালালে সেটা
   * আগের তারিখে পড়ত, সার্ভার সেগমেন্টটা মধ্যরাতে ভাগ করে দিত (§ ২.১-ক),
   * আর `accepted` ২-এর বদলে ৩ আসত। টেস্টটা দিনের বেলা পাস করত আর রাত
   * ১২টার পর ফেল — সবচেয়ে বিরক্তিকর ধরনের ফ্লেকি।
   */
  const dayWindow = () => {
    const w = todayWindow(900);
    const half = Math.floor(w.durationSec / 2);
    return { start: w.startedAt, half, total: w.durationSec, end: w.endedAt };
  };

  const segment = (over: Record<string, unknown> = {}) => {
    const w = dayWindow();
    const mid = new Date(w.start.getTime() + w.half * 1_000);

    return {
      clientUuid: randomUUID(),
      state: 'active',
      startedAt: iso(w.start),
      endedAt: iso(mid),
      durationSec: w.half,
      ...over,
    };
  };

  it('client_uuid না থাকলে 422', async () => {
    const { clientUuid, ...withoutUuid } = segment();
    void clientUuid;

    await asAgent(h.http().post('/api/v1/agent/segments'), device.token)
      .send({ segments: [withoutUuid] })
      .expect(422);
  });

  it('একই ব্যাচ দুবার পাঠালে দ্বিতীয়বার সব duplicate', async () => {
    const batch = {
      segments: [
        segment({ inputScore: 72 }),
        (() => {
          // প্রথমটার ঠিক পরের অংশ — একই দিনের ভেতরে, ওভারল্যাপ ছাড়া
          const w = dayWindow();
          const mid = new Date(w.start.getTime() + w.half * 1_000);
          return segment({
            state: 'idle',
            startedAt: iso(mid),
            endedAt: iso(w.end),
            durationSec: w.total - w.half,
          });
        })(),
      ],
    };

    const first = await asAgent(
      h.http().post('/api/v1/agent/segments'),
      device.token,
    )
      .send(batch)
      .expect(200);
    expect(first.body).toMatchObject({ accepted: 2, duplicates: 0 });

    const second = await asAgent(
      h.http().post('/api/v1/agent/segments'),
      device.token,
    )
      .send(batch)
      .expect(200);
    expect(second.body).toMatchObject({ accepted: 0, duplicates: 2 });
  });

  it('counts_as_work শুধু active-এ সত্যি', async () => {
    /**
     * ⚠️⚠️ তিনটে সেগমেন্টই **আজকের ঢাকা-দিনের ভেতরে** আর পরপর সাজানো।
     *
     * আগে `idle`/`locked`-এ `minutesAgo(15/10/9)` ছিল — আর সেটাই ঠিক ওই
     * ফাঁদ যা এই ফাইলেরই `segment()` ডিফল্টে একবার সারানো হয়েছে (উপরের
     * টীকা): মধ্যরাতের পরে চললে ওগুলো **আগের তারিখে** পড়ত, সার্ভার
     * সেগমেন্ট ভাগ করত, আর `orderBy startedAt`-এ active আর প্রথমে থাকত না —
     * `[active, idle, locked]`-এর বদলে `[idle, locked, active]`। CI ঠিক
     * মধ্যরাতে চলে এটা ধরিয়ে দিয়েছে (§ ৩ব)।
     *
     * ⭐ এখন active-এর জানালার **পরেই** idle, তারপর locked — সব আজকের
     *    দিনে, তাই ক্রম সবসময় স্থির।
     */
    const w = dayWindow();
    const mid = w.start.getTime() + w.half * 1_000;
    const gap = Math.max(1, Math.floor(w.half / 2));

    await asAgent(h.http().post('/api/v1/agent/segments'), device.token)
      .send({
        segments: [
          segment(), // active — [w.start, mid]
          segment({
            state: 'idle',
            startedAt: iso(new Date(mid)),
            endedAt: iso(new Date(mid + gap * 1_000)),
            durationSec: gap,
          }),
          segment({
            state: 'locked',
            startedAt: iso(new Date(mid + gap * 1_000)),
            endedAt: iso(new Date(mid + 2 * gap * 1_000)),
            durationSec: gap,
          }),
        ],
      })
      .expect(200);

    const rows = await h.prisma.activitySegment.findMany({
      orderBy: { startedAt: 'asc' },
    });
    expect(rows.map((r) => [r.state, r.countsAsWork])).toEqual([
      ['active', true],
      ['idle', false],
      ['locked', false],
    ]);
  });

  it('৫০০-র বেশি রেকর্ড হলে 400', async () => {
    const segments = Array.from({ length: 501 }, () => segment());
    await asAgent(h.http().post('/api/v1/agent/segments'), device.token)
      .send({ segments })
      .expect(400);
  });
});

describe('মধ্যরাতে ভাগ (§ ২.১-ক)', () => {
  it('২৩:৫০ → ০০:১০ একটি সেগমেন্ট দুই তারিখে ভাগ হয়', async () => {
    const res = await asAgent(
      h.http().post('/api/v1/agent/segments'),
      device.token,
    )
      .send({
        segments: [
          {
            clientUuid: randomUUID(),
            state: 'active',
            // ১৭:৫০Z = ঢাকায় ২৩:৫০ · ১৮:১০Z = পরদিন ০০:১০
            startedAt: '2026-08-08T17:50:00.000Z',
            endedAt: '2026-08-08T18:10:00.000Z',
            durationSec: 1200,
          },
        ],
      })
      .expect(200);

    expect(res.body).toMatchObject({ accepted: 2, split: 1 });

    const rows = await h.prisma.activitySegment.findMany({
      orderBy: { startedAt: 'asc' },
    });
    expect(rows.map((r) => r.workDate.toISOString().slice(0, 10))).toEqual([
      '2026-08-08',
      '2026-08-09',
    ]);
    // ভাগ হলেও মোট সময় অটুট থাকে
    expect(rows[0].durationSec + rows[1].durationSec).toBe(1200);
    // দুই টুকরোর client_uuid আলাদা, নইলে UNIQUE-এ আটকাত
    expect(rows[0].clientUuid).not.toBe(rows[1].clientUuid);

    const split = await h.prisma.event.findFirst({
      where: { type: 'segment_split' },
    });
    expect(split).not.toBeNull();
  });

  it('ভাগ হওয়া রেকর্ড আবার পাঠালেও ডুপ্লিকেট হয় না', async () => {
    const batch = {
      segments: [
        {
          clientUuid: randomUUID(),
          state: 'active',
          startedAt: '2026-08-08T17:50:00.000Z',
          endedAt: '2026-08-08T18:10:00.000Z',
          durationSec: 1200,
        },
      ],
    };

    await asAgent(h.http().post('/api/v1/agent/segments'), device.token)
      .send(batch)
      .expect(200);
    const again = await asAgent(
      h.http().post('/api/v1/agent/segments'),
      device.token,
    )
      .send(batch)
      .expect(200);

    expect(again.body).toMatchObject({ accepted: 0, duplicates: 2 });
    expect(await h.prisma.activitySegment.count()).toBe(2);
  });
});

describe('clock drift (§ ২)', () => {
  it('এজেন্টের ঘড়ি পিছিয়ে থাকলে সার্ভার সময় সংশোধন করে', async () => {
    const clientNow = minutesAgo(10); // PC-র ঘড়ি ১০ মিনিট পিছিয়ে

    // ⚠️ সংশোধনের পর সেগমেন্টটা যেন আজকের দিনেই থাকে — মধ্যরাত পেরোলে
    //    দু-ভাগ হতো, আর নিচের findFirstOrThrow প্রথম ভাগটা (শেষ ০০:০০) দিত
    const { durationSec } = todayWindow(300);
    const clientStart = new Date(clientNow.getTime() - durationSec * 1_000);

    await h
      .http()
      .post('/api/v1/agent/segments')
      .set('Authorization', `Bearer ${device.token}`)
      .set('X-Client-Time', iso(clientNow))
      .send({
        segments: [
          {
            clientUuid: randomUUID(),
            state: 'active',
            startedAt: iso(clientStart),
            endedAt: iso(clientNow),
            durationSec,
          },
        ],
      })
      .expect(200);

    const row = await h.prisma.activitySegment.findFirstOrThrow();
    // সংশোধনের পর শেষ সময়টা "এখন"-এর কাছাকাছি হওয়ার কথা, ১০ মিনিট আগে নয়
    const gapSec = Math.abs((realNow().getTime() - row.endedAt.getTime()) / 1000);
    expect(gapSec).toBeLessThan(60);

    const dev = await h.prisma.device.findFirstOrThrow({
      where: { id: device.deviceId },
    });
    expect(dev.lastDriftSec).toBeGreaterThan(500);
  });

  it('drift ৫ মিনিটের বেশি হলে একটাই অ্যালার্ট তৈরি হয়', async () => {
    const clientNow = minutesAgo(30);

    for (let i = 0; i < 3; i++) {
      await h
        .http()
        .post('/api/v1/agent/heartbeat')
        .set('Authorization', `Bearer ${device.token}`)
        .set('X-Client-Time', iso(clientNow))
        .send({ state: 'active', activeSecToday: 10 })
        .expect(200);
    }

    // ৩ বার পাঠালেও ৬ ঘণ্টায় একটাই — নইলে দিনে হাজারখানেক অ্যালার্ট হতো
    const alerts = await h.prisma.alert.findMany({
      where: { type: 'clock_drift' },
    });
    expect(alerts).toHaveLength(1);
  });
});

describe('work session', () => {
  it('logoff সেশন বন্ধ করে', async () => {
    const worked = todayWindow(600);

    await asAgent(h.http().post('/api/v1/agent/segments'), device.token)
      .send({
        segments: [
          {
            clientUuid: randomUUID(),
            state: 'active',
            startedAt: iso(worked.startedAt),
            endedAt: iso(worked.endedAt),
            durationSec: worked.durationSec,
          },
        ],
      })
      .expect(200);

    await asAgent(h.http().post('/api/v1/agent/events'), device.token)
      .send({
        events: [
          { clientUuid: randomUUID(), type: 'logoff', occurredAt: iso(realNow()) },
        ],
      })
      .expect(200);

    const session = await h.prisma.workSession.findFirstOrThrow();
    expect(session.endedAt).not.toBeNull();
    expect(session.endReason).toBe('logoff');
  });

  /**
   * G43 — অফলাইন queue রিপ্লেতে পুরোনো ব্যাচ নতুনের **পরে** আসে।
   * আগে এতে চলতি সেশন অতীতের সময়ে বন্ধ হয়ে ended_at < started_at হয়ে যেত।
   */
  it('ক্রম উল্টে এলেও সেশনের সীমা ভাঙে না', async () => {
    await asAgent(h.http().post('/api/v1/agent/segments'), device.token)
      .send({
        segments: [
          {
            clientUuid: randomUUID(),
            state: 'active',
            startedAt: iso(minutesAgo(30)),
            endedAt: iso(minutesAgo(20)),
            durationSec: 600,
          },
        ],
      })
      .expect(200);

    // এখন অনেক পুরোনো (গতকালের) ব্যাচ এল
    await asAgent(h.http().post('/api/v1/agent/segments'), device.token)
      .send({
        segments: [
          {
            clientUuid: randomUUID(),
            state: 'active',
            startedAt: '2026-08-08T17:50:00.000Z',
            endedAt: '2026-08-08T18:10:00.000Z',
            durationSec: 1200,
          },
        ],
      })
      .expect(200);

    await asAgent(h.http().post('/api/v1/agent/events'), device.token)
      .send({
        events: [
          { clientUuid: randomUUID(), type: 'logoff', occurredAt: iso(realNow()) },
        ],
      })
      .expect(200);

    const sessions = await h.prisma.workSession.findMany();
    for (const s of sessions) {
      expect(s.endedAt).not.toBeNull();
      expect(s.endedAt!.getTime()).toBeGreaterThan(s.startedAt.getTime());
    }

    // প্রতিটি সেগমেন্ট তার সেশনের সীমার ভেতরে থাকতে হবে
    const segments = await h.prisma.activitySegment.findMany();
    const byId = new Map(sessions.map((s) => [s.id, s]));
    for (const seg of segments) {
      const s = byId.get(seg.sessionId)!;
      expect(seg.startedAt.getTime()).toBeGreaterThanOrEqual(
        s.startedAt.getTime(),
      );
      expect(seg.endedAt.getTime()).toBeLessThanOrEqual(s.endedAt!.getTime());
    }

    // গতকালের সেশন আজকের logoff দিয়ে নয়, নিজের মধ্যরাতেই বন্ধ হবে
    const yesterday = sessions.find(
      (s) => s.workDate.toISOString().slice(0, 10) === '2026-08-08',
    )!;
    expect(yesterday.endReason).toBe('day_rollover');
    expect(yesterday.endedAt!.toISOString()).toBe('2026-08-08T18:00:00.000Z');
  });
});

describe('app usage ও events', () => {
  it('app usage জমা হয়, ডোমেইনসহ', async () => {
    const used = todayWindow(300);

    const res = await asAgent(
      h.http().post('/api/v1/agent/app-usage'),
      device.token,
    )
      .send({
        items: [
          {
            clientUuid: randomUUID(),
            startedAt: iso(used.startedAt),
            endedAt: iso(used.endedAt),
            durationSec: used.durationSec,
            processName: 'chrome.exe',
            appName: 'Google Chrome',
            windowTitle: 'GitHub',
            domain: 'github.com',
            isBrowser: true,
          },
        ],
      })
      .expect(200);

    expect(res.body.accepted).toBe(1);
    const row = await h.prisma.appUsage.findFirstOrThrow();
    expect(row.domain).toBe('github.com');
    // কোনো নিয়ম বসানো নেই — অচেনা থাকাই ঠিক (null ≠ neutral)
    expect(row.categoryId).toBeNull();
  });

  /**
   * D05 — ⭐ এই টেস্টটাই প্রমাণ করে ক্যাটাগরি **সত্যিই বসছে**।
   * ম্যাচারের ইউনিট টেস্ট আলাদা; এটা দেখায় ingest পথটা জোড়া লেগেছে।
   */
  it('ব্রাউজারের সাইট অনুযায়ী ক্যাটাগরি বসে, ব্রাউজার অনুযায়ী নয়', async () => {
    const used = todayWindow(300);

    await h.prisma.appCategory.createMany({
      data: [
        {
          matchType: 'process',
          pattern: 'chrome.exe',
          displayName: 'Google Chrome',
          category: 'neutral',
          priority: 200,
        },
        {
          matchType: 'domain',
          pattern: 'youtube.com',
          displayName: 'YouTube',
          category: 'unproductive',
          priority: 100,
        },
      ],
    });
    h.app.get(AppCategoryService).invalidate();

    await asAgent(h.http().post('/api/v1/agent/app-usage'), device.token)
      .send({
        items: [
          {
            clientUuid: randomUUID(),
            startedAt: iso(used.startedAt),
            endedAt: iso(used.endedAt),
            durationSec: used.durationSec,
            processName: 'chrome.exe',
            windowTitle: 'কিছু একটা — YouTube',
            domain: 'music.youtube.com',
            isBrowser: true,
          },
        ],
      })
      .expect(200);

    const row = await h.prisma.appUsage.findFirstOrThrow({
      include: { category: true },
    });

    // সাবডোমেইনেও ডোমেইনের নিয়ম চলে, আর সেটা chrome.exe-কে হারায়
    expect(row.category?.category).toBe('unproductive');
    expect(row.category?.displayName).toBe('YouTube');
  });

  /**
   * ⚠️ নিয়ম মুছে গেলে ক্যাশে তার id বসে থাকে, আর insert foreign key ভাঙে।
   * তখন ৫০০ দিয়ে পাঁচ মিনিট (TTL) বসে না থেকে একবার ক্যাশ ফেলে আবার চেষ্টা।
   */
  it('নিয়ম মুছে গেলেও ব্যাচ ঢোকে', async () => {
    const used = todayWindow(300);

    const rule = await h.prisma.appCategory.create({
      data: {
        matchType: 'process',
        pattern: 'excel.exe',
        displayName: 'Excel',
        category: 'productive',
        priority: 100,
      },
    });
    h.app.get(AppCategoryService).invalidate();

    // ক্যাশে ঢোকানো, তারপর নিয়মটা উধাও — ক্যাশ কিছুই জানে না
    await h.app.get(AppCategoryService).rules();
    await h.prisma.appCategory.delete({ where: { id: rule.id } });

    const res = await asAgent(
      h.http().post('/api/v1/agent/app-usage'),
      device.token,
    )
      .send({
        items: [
          {
            clientUuid: randomUUID(),
            startedAt: iso(used.startedAt),
            endedAt: iso(used.endedAt),
            durationSec: used.durationSec,
            processName: 'excel.exe',
          },
        ],
      })
      .expect(200);

    expect(res.body.accepted).toBe(1);
    const row = await h.prisma.appUsage.findFirstOrThrow();
    expect(row.categoryId).toBeNull();
  });

  it('event জমা হয়', async () => {
    const res = await asAgent(
      h.http().post('/api/v1/agent/events'),
      device.token,
    )
      .send({
        events: [
          {
            clientUuid: randomUUID(),
            type: 'lock',
            occurredAt: iso(minutesAgo(3)),
          },
        ],
      })
      .expect(200);

    expect(res.body.accepted).toBe(1);
  });
});

describe('screenshots', () => {
  const meta = (over: Record<string, unknown> = {}) => ({
    clientUuid: randomUUID(),
    slotStart: iso(minutesAgo(5)),
    capturedAt: iso(minutesAgo(4)),
    monitorIndex: 0,
    width: 1920,
    height: 1080,
    activeApp: 'code.exe',
    activeTitle: 'main.ts',
    ...over,
  });

  it('webp ছাড়া অন্য ফরম্যাট 400 (ADR-007)', async () => {
    await asAgent(h.http().post('/api/v1/agent/screenshots'), device.token)
      .field('meta', JSON.stringify(meta()))
      .attach('file', WEBP, { filename: 'shot.png', contentType: 'image/png' })
      .expect(400);
  });

  it('webp গ্রহণ করে ও তারিখ-ভিত্তিক পাথে রাখে', async () => {
    const res = await asAgent(
      h.http().post('/api/v1/agent/screenshots'),
      device.token,
    )
      .field('meta', JSON.stringify(meta()))
      .attach('file', WEBP, { filename: 'shot.webp', contentType: 'image/webp' })
      .expect(201);

    expect(res.body.accepted).toBe(1);
    // retention জব যেন শুধু ফোল্ডার ধরে মুছতে পারে (ADR-006)
    expect(res.body.path).toMatch(
      /^screenshots\/\d{4}\/\d{2}\/\d{2}\/emp-\d{3}\/\d{6}_m0\.webp$/,
    );
  });

  it('একই স্লট ও মনিটরের ছবি দুবার এলে duplicate', async () => {
    const m = JSON.stringify(meta());

    await asAgent(h.http().post('/api/v1/agent/screenshots'), device.token)
      .field('meta', m)
      .attach('file', WEBP, { filename: 'shot.webp', contentType: 'image/webp' })
      .expect(201);

    const res = await asAgent(
      h.http().post('/api/v1/agent/screenshots'),
      device.token,
    )
      .field('meta', m)
      .attach('file', WEBP, { filename: 'shot.webp', contentType: 'image/webp' })
      .expect(201);

    expect(res.body).toMatchObject({ accepted: 0, duplicate: true });
    expect(await h.prisma.screenshot.count()).toBe(1);
  });
});

describe('auto-update (G34)', () => {
  it('নতুন ভার্সন না থাকলে 204', async () => {
    await asAgent(
      h.http().get('/api/v1/agent/update?current=1.0.0'),
      device.token,
    ).expect(204);
  });

  it('নতুন ভার্সন থাকলে hash সহ তথ্য দেয়', async () => {
    await h.prisma.agentVersion.create({
      data: {
        version: '1.2.0',
        msiPath: 'agent/oXeioAgent-1.2.0.msi',
        sha256: 'a'.repeat(64),
        rolloutStage: 'all',
      },
    });

    const res = await asAgent(
      h.http().get('/api/v1/agent/update?current=1.0.0'),
      device.token,
    ).expect(200);

    expect(res.body).toMatchObject({ version: '1.2.0', mandatory: false });
    expect(res.body.sha256).toHaveLength(64);
  });

  it('rollout থামানো থাকলে কিছুই দেয় না', async () => {
    await h.prisma.agentVersion.create({
      data: {
        version: '1.3.0',
        msiPath: 'agent/bad.msi',
        sha256: 'b'.repeat(64),
        rolloutStage: 'halted',
      },
    });

    await asAgent(
      h.http().get('/api/v1/agent/update?current=1.0.0'),
      device.token,
    ).expect(204);
  });

  it('১.১০.০ কে ১.৯.০ এর চেয়ে নতুন ধরে (স্ট্রিং তুলনা নয়)', async () => {
    await h.prisma.agentVersion.create({
      data: {
        version: '1.10.0',
        msiPath: 'agent/x.msi',
        sha256: 'c'.repeat(64),
        rolloutStage: 'all',
      },
    });

    const res = await asAgent(
      h.http().get('/api/v1/agent/update?current=1.9.0'),
      device.token,
    ).expect(200);
    expect(res.body.version).toBe('1.10.0');
  });

  /**
   * ⭐⭐⭐ **"First to" — আর যে কারণে ওটা কোনোদিন কাজ করেনি**
   * *(৫ সেপ্টেম্বর ২০২৬)*।
   *
   * ⚠️⚠️ `pilotDeviceId` ঘরটা `offerFor()`-এ যোগ হয়েছিল ১ সেপ্টেম্বর, আর
   * **heartbeat কলারটা** `device.id` পাঠাত — কিন্তু **এই endpoint-টা
   * পাঠাত না**। ফলে `isPilot` এখানে চিরকাল `false`।
   *
   * ⚠️⚠️ ব্যর্থতাটা বিশেষভাবে বিভ্রান্তিকর ছিল, কারণ **অর্ধেক কাজ করত**:
   * heartbeat বেছে দেওয়া PC-কে `update_agent` কমান্ড পাঠাত (এজেন্ট জানত
   * আপডেট আছে), তারপর সে এখানে এসে **২০৪** পেত। কোনো এরর নয়, কোনো লগ
   * নয় — শুধু একটা আপডেট যেটা কোনোদিন নামত না।
   *
   * ⭐ ফিচারটা লেখাই হয়েছিল OX-05-এর জন্য (বালতি ৮৬), আর ঠিক সে-ই
   * কোনোদিন সেটা পায়নি। এই প্রকল্পের চেনা ছাঁদ: **চুক্তি লেখা আছে,
   * কলার লেখা হয়নি।**
   */
  it('⭐ বালতির বাইরে থাকা পাইলট PC তবু অফার পায়', async () => {
    await h.prisma.agentVersion.create({
      data: {
        version: '9.9.9',
        msiPath: 'agent/pilot.msi',
        sha256: 'd'.repeat(64),
        // ⚠️ canary ৭% — নিচের ডিভাইসটা এতে পড়ে কি না তার উপর ভরসা করা
        //    হয় না; পাইলট বালতিকে **অগ্রাহ্য** করে, আর সেটাই দাবি।
        rolloutStage: 'canary',
        pilotDeviceId: device.deviceId,
      },
    });

    const res = await asAgent(
      h.http().get('/api/v1/agent/update?current=1.0.0'),
      device.token,
    ).expect(200);

    expect(res.body.version).toBe('9.9.9');
  });

  /**
   * ⚠️⚠️ **জরুরি ব্রেক পাইলটের উপরেও খাটে।** `halted` মানে বিল্ডটা মাঠে
   * কিছু ভেঙেছে — তখন ঠিক সেই মেশিনটাতেই ওটা যেতে থাকা সবচেয়ে খারাপ,
   * কারণ ওখানেই আমরা সবচেয়ে বেশি নজর রাখছি। ক্রমটাই এটা ঠিক করে
   * (`isOfferedTo`-তে `percent <= 0` চেক পাইলটেরও আগে)।
   */
  it('⭐ `halted` হলে পাইলটও কিছু পায় না', async () => {
    await h.prisma.agentVersion.create({
      data: {
        version: '9.9.9',
        msiPath: 'agent/pilot.msi',
        sha256: 'd'.repeat(64),
        rolloutStage: 'halted',
        pilotDeviceId: device.deviceId,
      },
    });

    await asAgent(
      h.http().get('/api/v1/agent/update?current=1.0.0'),
      device.token,
    ).expect(204);
  });
});
