import { randomUUID } from 'node:crypto';

import { UserRole } from '@prisma/client';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';

import {
  createHarness,
  hashPassword,
  MANAGER_EMAIL,
  MANAGER_PASSWORD,
  OWNER_EMAIL,
  OWNER_PASSWORD,
  resetDatabase,
  type Harness,
  uniqueSuffix,
} from './setup/harness';
import { resolveThrottle } from '../src/auth/login-throttle.config';

/** ⚠️ চলমান কনফিগ থেকেই — টেস্টে সংখ্যা হার্ডকোড করলে সেটিং বদলালেই ভাঙত */
const THROTTLE = resolveThrottle({
  maxFails: process.env.LOGIN_MAX_FAILS,
  lockMinutes: process.env.LOGIN_LOCK_MINUTES,
});

/**
 * ⭐⭐ **স্টাফ নিজের ইমেইল-পাসওয়ার্ড দিয়ে নিজের PC যোগ করে।**
 *
 * ⚠️ enrollment code-এর ব্যবস্থায় মালিককে প্রতিটা PC-র জন্য আলাদা কোড
 * বানাতে হতো আর **হাতে মেলাতে** হতো কোন কোড কোন মেশিনে। ভুল মিললে কোনো
 * এরর আসত না — একজনের ঘণ্টা আরেকজনের নামে জমা হতো, আর ধরা পড়ত মাস শেষে।
 *
 * ⚠️ কিন্তু এই সরল পথটার দাম আছে: এটা একটা **পাসওয়ার্ড নেওয়ার
 * endpoint**, আর এখানে cookie বা CSRF কিছুই নেই। তাই এই ফাইলের অর্ধেক
 * টেস্ট সুবিধা নিয়ে নয়, **রক্ষাকবচ** নিয়ে — ভুল পাসওয়ার্ড, বন্ধ
 * অ্যাকাউন্ট, 2FA, আর brute-force throttle।
 */
let h: Harness;
let employeeId: number;

const STAFF_EMAIL = 'rakib@test.local';
const STAFF_PASSWORD = 'staff-password-123';

const facts = (overrides: Record<string, unknown> = {}) => ({
  hostname: 'PC-07',
  windowsUsername: 'rakib',
  machineGuid: randomUUID(),
  osVersion: 'Windows 11',
  agentVersion: '0.2.0',
  monitors: 2,
  ...overrides,
});

const enrollLogin = (body: Record<string, unknown>) =>
  h.http().post('/api/v1/agent/enroll-login').send(body);

beforeAll(async () => {
  h = await createHarness();
});

afterAll(async () => {
  await h.close();
});

beforeEach(async () => {
  await resetDatabase(h.prisma, h.app);

  const policy = await h.prisma.workPolicy.findFirstOrThrow();
  const employee = await h.prisma.employee.create({
    data: { empCode: 'OX-001', fullName: 'Rakib Hasan', policyId: policy.id },
  });
  employeeId = employee.id;

  await h.prisma.user.create({
    data: {
      email: STAFF_EMAIL,
      passwordHash: await hashPassword(STAFF_PASSWORD),
      fullName: 'Rakib Hasan',
      role: UserRole.employee,
      employeeId,
      mustChangePw: false,
    },
  });
});

describe('POST /agent/enroll-login — সফল পথ', () => {
  it('স্টাফের লগইনে ডিভাইস টোকেন আসে', async () => {
    const res = await enrollLogin({
      ...facts(),
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });

    expect(res.status).toBe(200);
    expect(res.body.deviceToken).toBeTruthy();
    expect(res.body.employee.empCode).toBe('OX-001');
    expect(res.body.config).toBeTruthy();

    const device = await h.prisma.device.findUniqueOrThrow({
      where: { id: res.body.deviceId },
    });
    // ⭐ যে লগইন করল, ডিভাইসটা তারই নামে — এটাই গোটা বদলটার কারণ
    expect(device.employeeId).toBe(employeeId);
    expect(device.monitors).toBe(2);
  });

  /**
   * ⚠️ **টোকেনটা শুধু একবারই যায়** — সার্ভারে কেবল sha256। এখানে সেটা
   * মিলিয়ে দেখা: রেসপন্সের প্লেইন টোকেনটা ডাটাবেসের কলামে নেই।
   */
  it('প্লেইন টোকেন ডাটাবেসে জমা হয় না', async () => {
    const res = await enrollLogin({
      ...facts(),
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });

    const device = await h.prisma.device.findUniqueOrThrow({
      where: { id: res.body.deviceId },
    });
    expect(device.tokenHash).not.toBe(res.body.deviceToken);
    expect(device.tokenHash).toHaveLength(64); // sha256 hex
  });

  it('টোকেনটা সত্যিই কাজ করে — heartbeat ২০০', async () => {
    const enrolled = await enrollLogin({
      ...facts(),
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });

    const beat = await h
      .http()
      .post('/api/v1/agent/heartbeat')
      .set('Authorization', `Bearer ${enrolled.body.deviceToken}`)
      .send({ state: 'active', activeSecToday: 60 });

    expect(beat.status).toBe(200);
  });

  /**
   * ⚠️ একই PC-তে আবার সাইন ইন করলে **নতুন সারি নয়**, আগেরটাই হালনাগাদ
   * (`machineGuid` দিয়ে upsert)। নইলে প্রতিবার এজেন্ট রিইনস্টলে ডিভাইসের
   * তালিকা ফুলে যেত, আর "কোনটা আসল" বলা যেত না।
   */
  it('একই মেশিনে দ্বিতীয়বার — একই ডিভাইস, নতুন টোকেন', async () => {
    const guid = randomUUID();
    const first = await enrollLogin({
      ...facts({ machineGuid: guid }),
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });
    const second = await enrollLogin({
      ...facts({ machineGuid: guid }),
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });

    expect(second.body.deviceId).toBe(first.body.deviceId);
    expect(second.body.deviceToken).not.toBe(first.body.deviceToken);

    // ⚠️ পুরোনো টোকেনটা এখন অচল — নইলে PC হাতবদল হলেও পুরোনো টোকেন
    //    দিয়ে ডেটা পাঠানো যেত
    const stale = await h
      .http()
      .post('/api/v1/agent/heartbeat')
      .set('Authorization', `Bearer ${first.body.deviceToken}`)
      .send({ state: 'active', activeSecToday: 60 });
    expect(stale.status).toBe(401);
  });

  /** ছ-মাস পরে "এই মেশিনটা কীভাবে যোগ হয়েছিল" — উত্তরটা ইভেন্টেই থাকে */
  it('agent_start ইভেন্টে লেখা থাকে কোন পথে বসল', async () => {
    await enrollLogin({
      ...facts(),
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });

    const [event] = await h.prisma.event.findMany({
      where: { type: 'agent_start' },
    });
    expect((event.meta as { via: string }).via).toBe('login');
  });
});

describe('POST /agent/enroll-login — রক্ষাকবচ', () => {
  it('ভুল পাসওয়ার্ডে ৪০১, আর কোনো ডিভাইস বসে না', async () => {
    const res = await enrollLogin({
      ...facts(),
      email: STAFF_EMAIL,
      password: 'wrong-password',
    });

    expect(res.status).toBe(401);
    expect(await h.prisma.device.count()).toBe(0);
  });

  /** ⚠️ "ইউজার নেই" আর "পাসওয়ার্ড ভুল" — একই বার্তা, নইলে কোন ইমেইলগুলো
   *  আসল তা বাইরে থেকে গুনে বের করা যেত */
  it('অচেনা ইমেইলেও একই ৪০১', async () => {
    const unknown = await enrollLogin({
      ...facts(),
      email: 'nobody@test.local',
      password: STAFF_PASSWORD,
    });
    const wrong = await enrollLogin({
      ...facts(),
      email: STAFF_EMAIL,
      password: 'wrong-password',
    });

    expect(unknown.status).toBe(401);
    expect(unknown.body.message).toBe(wrong.body.message);
  });

  it('নিষ্ক্রিয় অ্যাকাউন্টে ৪০১', async () => {
    await h.prisma.user.update({
      where: { email: STAFF_EMAIL },
      data: { isActive: false },
    });

    const res = await enrollLogin({
      ...facts(),
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });
    expect(res.status).toBe(401);
  });

  /**
   * ⭐ owner ও manager-এর `users.employee_id` null — তাঁদের নামে কর্মীর
   * সারি নেই, তাই ঘণ্টা জমা করার জায়গাও নেই। ৪০১ নয় **৪০৩**, আর
   * বার্তাটা কাজের: "এই PC-র স্টাফ অ্যাকাউন্ট দিয়ে সাইন ইন করুন"।
   */
  it('owner বা manager-এর অ্যাকাউন্টে ৪০৩', async () => {
    for (const [email, password] of [
      [OWNER_EMAIL, OWNER_PASSWORD],
      [MANAGER_EMAIL, MANAGER_PASSWORD],
    ]) {
      const res = await enrollLogin({ ...facts(), email, password });
      expect(res.status, email).toBe(403);
    }

    expect(await h.prisma.device.count()).toBe(0);
  });

  /**
   * ⭐⭐ **brute force।** endpoint-টায় cookie নেই, CSRF নেই — অর্থাৎ
   * পাসওয়ার্ড অনুমান করার সবচেয়ে সহজ দরজা এটাই হতে পারত। যাচাইটা
   * `AuthService.login()`-এ হওয়ায় লগইনের throttle-টাও আপনাআপনি প্রযোজ্য।
   */
  it.skipIf(!THROTTLE.enabled)('বারবার ভুল দিলে অ্যাকাউন্ট তালাবন্ধ হয়', async () => {
    /**
     * ⚠️ এই টেস্টের জন্য **আলাদা ও অনন্য** একটা ইমেইল। throttle-এর
     * কাউন্টার ইন-মেমরিতে (`email|ip`), আর `resetDatabase()` সেটা মোছে না
     * — তাই সাধারণ স্টাফ অ্যাকাউন্টটা তালাবন্ধ করে দিলে **পরের প্রতিটা
     * টেস্ট** ৪২৯ পেত। `auth.e2e.spec.ts`-ও ঠিক এই কৌশলেই চলে।
     */
    const email = `locked-${uniqueSuffix()}@test.local`;
    const password = 'another-password-123';

    await h.prisma.user.create({
      data: {
        email,
        passwordHash: await hashPassword(password),
        fullName: 'Locked Out',
        role: UserRole.employee,
        employeeId,
        mustChangePw: false,
      },
    });

    /**
     * ⚠️⚠️ সংখ্যাটা আর হার্ডকোড নয় — এটা এখন `.env`-এর সেটিং। আগে "৫"
     * বসানো ছিল, তাই ডিফল্ট নরম করার সাথে সাথেই টেস্ট ভেঙেছে, অথচ
     * আচরণ ঠিকই ছিল। টেস্ট নিয়ম পাহারা দিক, একটা সংখ্যা নয়।
     */
    const codes: number[] = [];
    for (let i = 0; i <= THROTTLE.maxFails; i++) {
      const res = await enrollLogin({ ...facts(), email, password: `guess-${i}` });
      codes.push(res.status);
    }

    expect(codes.slice(0, THROTTLE.maxFails)).toEqual(
      Array(THROTTLE.maxFails).fill(401),
    );
    expect(codes[THROTTLE.maxFails]).toBe(429);

    // ⚠️ তালা পড়ার পর **ঠিক পাসওয়ার্ডও** আটকায় — নইলে তালাটার মানেই থাকত না
    const right = await enrollLogin({ ...facts(), email, password });
    expect(right.status).toBe(429);

    expect(await h.prisma.device.count()).toBe(0);
  });

  it('ব্যর্থ চেষ্টা audit_log-এ ওঠে', async () => {
    await h.prisma.auditLog.deleteMany({});

    await enrollLogin({
      ...facts(),
      email: STAFF_EMAIL,
      password: 'wrong-password',
    });

    const rows = await h.prisma.auditLog.findMany({
      where: { action: 'login_failed' },
    });
    expect(rows).toHaveLength(1);
  });

  it('ঘর বাদ দিলে ৪০০', async () => {
    const res = await enrollLogin({ email: STAFF_EMAIL, password: STAFF_PASSWORD });
    expect(res.status).toBe(400);
  });

  it('ইমেইল না হলে ৪০০', async () => {
    const res = await enrollLogin({
      ...facts(),
      email: 'rakib',
      password: STAFF_PASSWORD,
    });
    expect(res.status).toBe(400);
  });
});

describe('POST /agent/enroll-login — 2FA', () => {
  /**
   * ⚠️ 2FA চালু থাকলে প্রথম উত্তরে ডিভাইস তৈরি হয় **না**, শুধু
   * `needs_totp` — এজেন্ট তখন ছ-অঙ্কের ঘরটা দেখায়। ৪০১ দিলে স্টাফ
   * "পাসওয়ার্ড ভুল" পড়ে বারবার ঠিক পাসওয়ার্ডই টাইপ করে যেত।
   */
  it('2FA চালু থাকলে কোড চায়, ডিভাইস বসে না', async () => {
    await h.prisma.user.update({
      where: { email: STAFF_EMAIL },
      data: {
        // ⚠️ খামের আকৃতি `src/auth/totp.ts`-এর `TotpEnvelope` — ভুল
        //    আকৃতি দিলে `decodeEnvelope` ছোড়ে (fail-closed), আর টেস্টটা
        //    ৫০০ পেয়ে "2FA কাজ করছে" বলে ভুল আশ্বাস দিত
        totpSecret: JSON.stringify({
          v: 1,
          secret: 'JBSWY3DPEHPK3PXP',
          enabled: true,
          recoveryHashes: [],
          lastCounter: 0,
        }),
      },
    });

    const res = await enrollLogin({
      ...facts(),
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });

    expect(res.status).toBe(200);
    expect(res.body.status).toBe('needs_totp');
    expect(res.body.deviceToken).toBeUndefined();
    expect(await h.prisma.device.count()).toBe(0);
  });
});

/**
 * ⭐⭐ **একটা ডিভাইস-সারি একজনেরই — নীরবে হাতবদল হবে না।**
 *
 * ⚠️⚠️ আসল অফিসে ধরা পড়া বাগ: দুজন কর্মীর PC পালা করে "হঠাৎ offline"
 * হয়ে যেত, আর Staff পর্দায় তাঁদের সারি ফিরে যেত "Ready to install"-এ।
 * কারণ `upsert`-এর চাবি ছিল কেবল `machineGuid`, আর সংঘাতে `employeeId`
 * ও `tokenHash` দুটোই লিখে দেওয়া হতো — তাই একই GUID পাঠানো দুটো মেশিনের
 * মধ্যে একটাই সারি হাতবদল করত।
 *
 * ⚠️ `machineGuid` আসে Windows-এর রেজিস্ট্রি থেকে, আর সেটা **ডিস্ক-ইমেজ
 * ক্লোনে হুবহু কপি হয়** — অর্থাৎ অফিসে একটা PC সাজিয়ে বাকিগুলোয় ইমেজ
 * বসালেই সবার GUID এক।
 */
/**
 * ⭐⭐ **ডিভাইসের পরিচয়: মেশিন + যিনি বসেছেন।**
 *
 * ⚠️⚠️ আসল অফিসে ধরা পড়া বাগ: দুজন কর্মীর ট্র্যাকিং পালা করে "হঠাৎ
 * offline" হয়ে যেত, আর Staff পর্দায় তাঁদের সারি ফিরে যেত "Ready to
 * install"-এ। কারণ `upsert`-এর চাবি ছিল কেবল `machineGuid`, আর সংঘাতে
 * `employeeId` ও `tokenHash` দুটোই লিখে দেওয়া হতো — তাই একই GUID পাঠানো
 * দুটো এজেন্টের মধ্যে একটাই সারি হাতবদল করত।
 *
 * ⚠️ `machineGuid` **মেশিনের, ব্যবহারকারীর নয়** — তাই একই PC-তে দুজন
 * স্টাফ আলাদা Windows অ্যাকাউন্টে কাজ করলেও ওটা এক। অফিসের লগেই ধরা
 * পড়েছে: `DESKTOP-BJNQ6OF`-এ "Intern" ও "Intern 2"।
 */
describe('POST /agent/enroll-login — ডিভাইসের পরিচয়', () => {
  const OTHER_EMAIL = 'sadia@test.local';
  const OTHER_PASSWORD = 'other-password-123';

  /** দ্বিতীয় একজন কর্মী + তার portal লগইন */
  const addOtherStaff = async (): Promise<number> => {
    const policy = await h.prisma.workPolicy.findFirstOrThrow();
    const other = await h.prisma.employee.create({
      data: { empCode: 'OX-002', fullName: 'Sadia Akther', policyId: policy.id },
    });

    await h.prisma.user.create({
      data: {
        email: OTHER_EMAIL,
        passwordHash: await hashPassword(OTHER_PASSWORD),
        fullName: 'Sadia Akther',
        role: UserRole.employee,
        employeeId: other.id,
        mustChangePw: false,
      },
    });

    return other.id;
  };

  /**
   * ⭐⭐ **এটাই আসল দাবি** — অফিসে ঠিক এটাই ঘটছে: এক PC, দুজন স্টাফ,
   * আলাদা Windows অ্যাকাউন্ট। দুজনেরই আলাদা সারি হওয়া চাই।
   */
  it('এক PC, দুই Windows অ্যাকাউন্ট → দুজনেরই আলাদা ডিভাইস', async () => {
    const otherId = await addOtherStaff();
    const guid = randomUUID();

    const first = await enrollLogin({
      ...facts({ machineGuid: guid, hostname: 'PC-07', windowsUsername: 'Intern' }),
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });
    expect(first.status).toBe(200);

    const second = await enrollLogin({
      ...facts({ machineGuid: guid, hostname: 'PC-07', windowsUsername: 'Intern 2' }),
      email: OTHER_EMAIL,
      password: OTHER_PASSWORD,
    });

    expect(second.status).toBe(200);
    expect(second.body.deviceId).not.toBe(first.body.deviceId);
    expect(await h.prisma.device.count()).toBe(2);

    // ⭐ দুজনের ঘণ্টা আলাদা সারিতে — কেউ কারোটা কাড়ে না
    expect(await h.prisma.device.count({ where: { employeeId } })).toBe(1);
    expect(await h.prisma.device.count({ where: { employeeId: otherId } })).toBe(1);
  });

  /**
   * ⭐ ক্লোন করা ডিস্ক-ইমেজ — দুটো আলাদা PC, একই `MachineGuid`।
   * hostname আলাদা বলে দুটো সারি, দুজনেই চলেন।
   */
  it('একই GUID কিন্তু আলাদা PC → দুটো সারি', async () => {
    const otherId = await addOtherStaff();
    const guid = randomUUID();

    await enrollLogin({
      ...facts({ machineGuid: guid, hostname: 'PC-07' }),
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    }).expect(200);

    await enrollLogin({
      ...facts({ machineGuid: guid, hostname: 'PC-09', windowsUsername: 'sadia' }),
      email: OTHER_EMAIL,
      password: OTHER_PASSWORD,
    }).expect(200);

    expect(await h.prisma.device.count()).toBe(2);
    expect(await h.prisma.device.count({ where: { employeeId: otherId } })).toBe(1);
  });

  /**
   * ⚠️ যেটা এখনো আটকানো: **একই Windows অ্যাকাউন্ট** দুজন ভাগ করে নিলে।
   * তখন দুজনের ঘণ্টা এক সারিতে মিশে যেত আর আলাদা করা যেত না।
   */
  it('একই Windows অ্যাকাউন্টে দ্বিতীয় কর্মী এলে ৪০৯, প্রথমজনের সব অটুট', async () => {
    const otherId = await addOtherStaff();
    const same = facts({ hostname: 'PC-07', windowsUsername: 'shared' });

    const first = await enrollLogin({
      ...same,
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });
    expect(first.status).toBe(200);

    const before = await h.prisma.device.findUniqueOrThrow({
      where: { id: first.body.deviceId },
    });

    const second = await enrollLogin({
      ...same,
      machineGuid: randomUUID(),
      email: OTHER_EMAIL,
      password: OTHER_PASSWORD,
    });

    expect(second.status).toBe(409);

    const after = await h.prisma.device.findUniqueOrThrow({
      where: { id: first.body.deviceId },
    });
    expect(after.employeeId).toBe(employeeId);
    // ⭐ টোকেনও বদলায়নি — প্রথমজনের এজেন্ট চলতেই থাকে
    expect(after.tokenHash).toBe(before.tokenHash);
    expect(await h.prisma.device.count({ where: { employeeId: otherId } })).toBe(0);
  });

  /** ⭐ একই কর্মী আবার বসালে আগের মতোই চলে — এটা ভাঙা যাবে না */
  it('একই কর্মী আবার ইনস্টল করলে সারিটাই হালনাগাদ হয়', async () => {
    const same = facts({ monitors: 2 });

    const first = await enrollLogin({
      ...same,
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });
    expect(first.status).toBe(200);

    const again = await enrollLogin({
      ...same,
      monitors: 3,
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });

    expect(again.status).toBe(200);
    expect(again.body.deviceId).toBe(first.body.deviceId);
    expect(await h.prisma.device.count()).toBe(1);

    const device = await h.prisma.device.findUniqueOrThrow({
      where: { id: first.body.deviceId },
    });
    expect(device.monitors).toBe(3);
  });

  /**
   * ⭐ বৈধ হস্তান্তর — একই Windows অ্যাকাউন্ট অন্য কেউ পেলে মালিক আগে
   * revoke করবেন, তারপর নতুন কর্মী নিতে পারেন।
   */
  it('revoke করা ডিভাইস নতুন কর্মী নিতে পারেন', async () => {
    const otherId = await addOtherStaff();
    const same = facts({ hostname: 'PC-07', windowsUsername: 'shared' });

    const first = await enrollLogin({
      ...same,
      email: STAFF_EMAIL,
      password: STAFF_PASSWORD,
    });
    expect(first.status).toBe(200);

    await h.prisma.device.update({
      where: { id: first.body.deviceId },
      data: { status: 'revoked' },
    });

    const handover = await enrollLogin({
      ...same,
      email: OTHER_EMAIL,
      password: OTHER_PASSWORD,
    });

    expect(handover.status).toBe(200);

    const device = await h.prisma.device.findUniqueOrThrow({
      where: { id: first.body.deviceId },
    });
    expect(device.employeeId).toBe(otherId);
    expect(device.status).toBe('active');
  });
});
