import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { LoggerModule } from 'nestjs-pino';

import { ActivityModule } from './activity/activity.module';
import { AdjustmentsModule } from './adjustments/adjustments.module';
import { AdminModule } from './admin/admin.module';
import { AgentModule } from './agent/agent.module';
import { AlertsModule } from './alerts/alerts.module';
import { AuditModule } from './audit/audit.module';
import { AuthModule } from './auth/auth.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { DigestModule } from './digest/digest.module';
import { HealthModule } from './health/health.module';
import { DepositsModule } from './deposits/deposits.module';
import { MeModule } from './me/me.module';
import { OpsModule } from './ops/ops.module';
import { PrismaModule } from './prisma/prisma.module';
import { PayrollModule } from './payroll/payroll.module';
import { ReportsModule } from './reports/reports.module';
import { ScreenshotsModule } from './screenshots/screenshots.module';
import { SummaryModule } from './summary/summary.module';
import { TargetsModule } from './targets/targets.module';
import { UsersModule } from './users/users.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, cache: true }),
    LoggerModule.forRoot({
      pinoHttp: {
        // টেস্টে প্রতিটি রিকোয়েস্টের লগ আসল ফলাফল ঢেকে দেয়
        level: process.env.NODE_ENV === 'test' ? 'silent' : 'info',
        transport:
          process.env.NODE_ENV === 'production' ||
          process.env.NODE_ENV === 'test'
            ? undefined
            : { target: 'pino-pretty', options: { singleLine: true } },
        redact: {
          // এজেন্টের টোকেন, সেশন cookie বা কারো পাসওয়ার্ড যেন কখনো লগে না ওঠে
          paths: [
            'req.headers.authorization',
            'req.headers.cookie',
            'req.headers["x-csrf-token"]',
            'res.headers["set-cookie"]',
            'req.body.password',
            'req.body.currentPassword',
            'req.body.newPassword',
          ],
          remove: true,
        },
      },
    }),
    PrismaModule,
    AuditModule,
    AuthModule,
    UsersModule,
    AgentModule,
    ActivityModule,
    AdminModule,
    AdjustmentsModule,
    DashboardModule,
    PayrollModule,
    DepositsModule,
    ReportsModule,
    ScreenshotsModule,
    // ⚠️ SummaryModule নিজের ভেতরে ScheduleModule.forRoot() রাখে (টেস্টে বাদ পড়ে)।
    // এখানে আলাদা করে forRoot() বসিয়ো না — দুটো explorer একই @Cron দুবার
    // রেজিস্টার করতে গিয়ে bootstrap-এই "cron job already exists" দিয়ে ভাঙবে।
    SummaryModule,
    // ⭐ ডিজাইন-টার্গেট (২২ আগস্ট) — জমা · রোজকার বণ্টন · শেষ হওয়া
    TargetsModule,
    AlertsModule,
    // ⚠️ OpsModule ও DigestModule দুটোরই `@Cron` আছে, কিন্তু explorer আসে
    // উপরের SummaryModule-এর global forRoot() থেকে — তাই এদের **পরে** রাখা।
    // (নির্ভরতাটা DI-তে অদৃশ্য বলে BackupJob bootstrap-এ নিজেই মিলিয়ে দেখে।)
    MeModule,
    OpsModule,
    DigestModule,
    HealthModule,
  ],
})
export class AppModule {}
