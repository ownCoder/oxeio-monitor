import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { UserRole } from '@prisma/client';

import { AuditService } from '../audit/audit.service';
import { PrismaService } from '../prisma/prisma.service';
import { LoginThrottleService } from './login-throttle.service';
import { PasswordService } from './password.service';
import {
  decodeEnvelope,
  encodeEnvelope,
  verifySecondFactor,
  type TotpEnvelope,
} from './totp';
import type { SessionUser } from './types';
/**
 * ⚠️ পাহারার সূত্রটা **নিয়মের ফাইল থেকে ধার করা**, এখানে আবার লেখা নয় —
 * সার্ভারের গার্ড আর সেশনের পতাকা একই লাইনে বাঁধা থাকে।
 */
import { canUseTargets } from '../targets/targets.rules';

/**
 * ⭐ লগইনের ফল তিন রকম হতে পারে, তাই discriminated union — একটা optional
 *    ফিল্ড দিয়ে বোঝালে কল করার জায়গায় "needsTotp true অথচ user-ও আছে"
 *    এমন অসম্ভব অবস্থাও টাইপ-বৈধ হতো।
 */
export type LoginOutcome =
  | { status: 'needs_totp' }
  | {
      status: 'ok';
      user: Omit<SessionUser, 'issuedAt'>;
      mustChangePassword: boolean;
      /** রিকভারি কোড দিয়ে ঢুকেছে — ইউজারকে জানানো দরকার */
      usedRecoveryCode: boolean;
      /** 2FA চালু থাকলে আর কটা রিকভারি কোড বাকি; নইলে null */
      recoveryCodesLeft: number | null;
    };

export interface MeResult {
  userId: number;
  email: string;
  fullName: string;
  role: UserRole;
  employeeId: number | null;
  mustChangePassword: boolean;
  lastLoginAt: Date | null;
  /** I06 — Security পর্দা এটা দেখেই অবস্থা বোঝায় */
  twoFactorEnabled: boolean;
  /**
   * ⭐⭐ **এই ব্যবহারকারী ডিজাইন-টার্গেট জমা দিতে পারেন কি না** *(২২ আগস্ট)*।
   *
   * ⚠️⚠️ **কেন একটা তৈরি উত্তর, কাঁচা `staffType` নয়।** নিয়মটা হলো
   * "owner · manager · **অথবা** staffType = researcher" — সেটা পাঠালে
   * ওয়েবকে ওই শর্তটা **আবার লিখতে** হতো, আর একদিন সার্ভার ও পর্দা
   * দু-রকম বলত (কেউ মেনু দেখতেন কিন্তু ৪০৩ পেতেন, বা উল্টো)।
   * ⭐ সার্ভার সিদ্ধান্তটা নেয়, ওয়েব কেবল মানে। শর্তটা
   * `TargetsService.assertCanSubmit()`-এর হুবহু জোড়া।
   */
  canAddTargets: boolean;
  /**
   * ⭐ **বানান যাচাই করতে পারেন কি না** (ADR-038, ২৫ আগস্ট ২০২৬)।
   *
   * ⚠️ `canAddTargets`-এর থেকে **আলাদা** — সব গবেষক টার্গেট জমা দিতে
   * পারেন, কিন্তু বানান দেখেন কেবল যাঁকে মালিক টিক দিয়েছেন।
   */
  canProofread: boolean;
}

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly passwords: PasswordService,
    private readonly throttle: LoginThrottleService,
    private readonly audit: AuditService,
  ) {}

  /**
   * ⭐ 2FA-র দ্বিতীয় ধাপে ইমেইল+পাসওয়ার্ড **আবার** পাঠাতে হয় — মাঝপথের
   *    কোনো "half-logged-in" টোকেন নেই। সেরকম টোকেন মানেই আরেকটা জিনিস
   *    যা চুরি হতে পারে, মেয়াদ শেষ হতে পারে, ভুল করে পুরো সেশনের ক্ষমতা
   *    পেয়ে যেতে পারে। ব্রাউজার পাসওয়ার্ডটা ফর্মেই ধরে রাখে, তাই
   *    ব্যবহারকারীর দিক থেকে পার্থক্য নেই।
   */
  async login(
    email: string,
    password: string,
    ip: string,
    totp?: string,
    recoveryCode?: string,
  ): Promise<LoginOutcome> {
    this.throttle.assertNotLocked(email, ip);

    const user = await this.prisma.user.findUnique({
      where: { email: email.toLowerCase() },
    });

    // ইউজার নেই আর পাসওয়ার্ড ভুল — দুটোতেই একই বার্তা, নইলে
    // কোন ইমেইলগুলো আসল তা বাইরে থেকে বোঝা যেত (user enumeration)
    const ok =
      user !== null &&
      user.isActive &&
      (await this.passwords.verify(user.passwordHash, password));

    if (!ok) {
      this.throttle.recordFailure(email, ip);
      await this.audit.record({
        userId: user?.id ?? null,
        action: 'login_failed',
        ipAddress: ip,
        meta: { email },
      });
      throw new UnauthorizedException('Email or password is incorrect');
    }

    // I06 — 2FA। খাম ভাঙা থাকলে `decodeEnvelope` ছোড়ে, অর্থাৎ fail-closed।
    const env = decodeEnvelope(user.totpSecret);
    let usedRecoveryCode = false;
    let nextEnv: TotpEnvelope | null = null;

    if (env?.enabled) {
      const result = verifySecondFactor(env, { totp, recoveryCode });

      if (!result.ok && result.reason === 'missing') {
        // ⚠️ এখানে `recordSuccess` **নয়** — পাসওয়ার্ড ঠিক হলেও লগইন এখনো
        //    সম্পূর্ণ নয়, তাই ব্যর্থতার কাউন্টার মুছে ফেলা যাবে না।
        //    ব্যর্থতাও নয়: কোড না দেওয়াটা আক্রমণ নয়, স্বাভাবিক প্রথম ধাপ।
        return { status: 'needs_totp' };
      }

      if (!result.ok) {
        // ⚠️ 2FA ধাপেও throttle — নইলে পাসওয়ার্ড জানা আক্রমণকারী ৬ অঙ্কের
        //    ১০ লাখ সম্ভাবনা নির্বিঘ্নে চেষ্টা করে যেতে পারত।
        this.throttle.recordFailure(email, ip);
        await this.audit.record({
          userId: user.id,
          action: '2fa_failed',
          ipAddress: ip,
          meta: { reason: result.reason },
        });
        throw new UnauthorizedException(
          result.reason === 'replayed'
            ? 'This code has already been used — wait for the next code in your app'
            : 'Verification code is invalid',
        );
      }

      usedRecoveryCode = result.usedRecoveryCode;
      nextEnv = result.env;
    }

    this.throttle.recordSuccess(email, ip);

    // ⚠️ খরচ হওয়া কোড/counter আর `lastLoginAt` একই `UPDATE`-এ — আলাদা করলে
    //    একটা ব্যর্থ হলে "লগইন হয়েছে কিন্তু কোড খরচ হয়নি" অবস্থা তৈরি হতো,
    //    অর্থাৎ replay ঠেকানোই ভেঙে যেত।
    await this.prisma.user.update({
      where: { id: user.id },
      data: {
        lastLoginAt: new Date(),
        ...(nextEnv === null ? {} : { totpSecret: encodeEnvelope(nextEnv) }),
      },
    });

    await this.audit.record({
      userId: user.id,
      action: 'login',
      ipAddress: ip,
      meta: { twoFactor: env?.enabled === true, recovery: usedRecoveryCode },
    });

    if (usedRecoveryCode) {
      await this.audit.record({
        userId: user.id,
        action: '2fa_recovery_used',
        ipAddress: ip,
        meta: { left: nextEnv?.recoveryHashes.length ?? 0 },
      });
    }

    return {
      status: 'ok',
      user: {
        userId: user.id,
        email: user.email,
        role: user.role,
        employeeId: user.employeeId,
        mustChangePw: user.mustChangePw,
      },
      mustChangePassword: user.mustChangePw,
      usedRecoveryCode,
      recoveryCodesLeft: nextEnv?.recoveryHashes.length ?? null,
    };
  }

  async me(userId: number): Promise<MeResult> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      // ⚠️ কাজের ধরন লাগে `canAddTargets`-এর জন্য — গবেষক ঢোকেন
      //    `employee` রোলে, তাই রোল দেখে বোঝার উপায় নেই
      /**
       * ⚠️ আগে এখানে `include: { employee: ... }` ছিল — `canAddTargets`
       * ও `canProofread` **অন্য টেবিল** থেকে পড়তে হতো। ২৫ আগস্ট
       * `researcher` রোল আসার পর দুটোই ভূমিকা থেকেই বেরোয়, তাই
       * জয়েনটা ⭐ **প্রতিটা `/auth/me` কল থেকে উধাও**।
       */
    });
    if (!user || !user.isActive) {
      throw new UnauthorizedException('This account is no longer active');
    }

    return {
      userId: user.id,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      employeeId: user.employeeId,
      mustChangePassword: user.mustChangePw,
      lastLoginAt: user.lastLoginAt,
      twoFactorEnabled: decodeEnvelope(user.totpSecret)?.enabled === true,
      /**
       * ⚠️⚠️ দুটোর সূত্র **আজ এক**, তবু নাম দুটো — ইচ্ছাকৃত। পর্দায়
       * এগুলো দুটো আলাদা জিনিস ঢাকে (মেনুর আইটেম বনাম সারির বোতাম),
       * আর শর্তের নাম থাকলে ভবিষ্যতে একটা বদলাতে গিয়ে অন্যটা খুঁজে
       * বেড়াতে হয় না। ⭐ সূত্রটা `canUseTargets`-এ **এক জায়গায়** লেখা,
       * তাই নাম আলাদা হলেও দুটো কখনো নিঃশব্দে আলাদা হয়ে যাবে না।
       */
      canAddTargets: canUseTargets(user.role),
      canProofread: canUseTargets(user.role),
    };
  }

  async changePassword(
    userId: number,
    currentPassword: string,
    newPassword: string,
    ip: string,
  ): Promise<void> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new UnauthorizedException();

    const ok = await this.passwords.verify(user.passwordHash, currentPassword);
    if (!ok) throw new UnauthorizedException('Current password is incorrect');

    if (await this.passwords.verify(user.passwordHash, newPassword)) {
      throw new BadRequestException(
        'New password must be different from the current one',
      );
    }

    await this.prisma.user.update({
      where: { id: userId },
      data: {
        passwordHash: await this.passwords.hash(newPassword),
        mustChangePw: false,
        pwChangedAt: new Date(),
      },
    });

    await this.audit.record({
      userId,
      action: 'change_password',
      ipAddress: ip,
    });
  }

  /**
   * G33 — owner কারো পাসওয়ার্ড রিসেট করে।
   * নতুন পাসওয়ার্ড **একবারই** ফেরত যায়; কোথাও plaintext-এ জমা হয় না।
   * SMTP লাগে না, তাই Phase 1-এই কাজ করে।
   */
  async resetPassword(
    actorId: number,
    targetUserId: number,
    ip: string,
    /** ⭐ মালিক নিজে বসালে বাধ্যতামূলক বদল নেই (২৩ আগস্ট) */
    chosen?: string,
  ): Promise<{ email: string; tempPassword: string }> {
    const target = await this.prisma.user.findUnique({
      where: { id: targetUserId },
    });
    if (!target) throw new NotFoundException('User not found');

    /**
     * ⚠️⚠️ **নিষ্ক্রিয় অ্যাকাউন্টে রিসেট আটকানো হয়, আর কারণটা বলা হয়।**
     *
     * আগে এটা চুপচাপ সফল হতো — নতুন পাসওয়ার্ড পর্দায় দেখাত, অথচ
     * `login()` পাসওয়ার্ডের সাথে `isActive`-ও মেলায়, তাই ওই পাসওয়ার্ড
     * **কোনোদিন কাজ করত না**। আর লগইনের বার্তা ইচ্ছাকৃতভাবে সবসময় একই
     * (*"Email or password is incorrect"* — user enumeration ঠেকাতে),
     * তাই মালিকের কাছে ব্যাপারটা দাঁড়াত: রিসেট কাজ করছে, লগইন করছে না,
     * আর কেন — জানার কোনো উপায় নেই।
     *
     * ⭐ এখানে বার্তাটা লুকানোর কিছু নেই: এই রুটে ঢুকতেই owner হতে হয়,
     * অর্থাৎ তিনি এমনিতেই সব অ্যাকাউন্ট দেখতে পান।
     *
     * ⚠️ নিজে থেকে সক্রিয় করে দেওয়া হয় **না**। পাসওয়ার্ড রিসেট করতে গিয়ে
     * কেউ যেন ছেড়ে-যাওয়া কর্মীর অ্যাকাউন্ট অজান্তে খুলে না ফেলে —
     * সক্রিয় করাটা আলাদা, সচেতন কাজ (Staff → Reactivate)।
     */
    if (!target.isActive) {
      throw new ConflictException(
        'This login is disabled because the staff member is inactive. '
          + 'Reactivate them on the Staff screen first — then reset the password.',
      );
    }

    // ⚠️ একই নিয়ম রিসেটেও: মালিক বসালে বাধ্যতামূলক বদল নেই
    const tempPassword = chosen ?? this.passwords.generateTempPassword();

    await this.prisma.user.update({
      where: { id: targetUserId },
      data: {
        passwordHash: await this.passwords.hash(tempPassword),
        // ⚠️ রিসেটেও একই — কখনো বাধ্যতামূলক নয় (উপরের নোট দেখুন)
        mustChangePw: false,
        pwChangedAt: new Date(),
      },
    });

    await this.audit.record({
      userId: actorId,
      action: 'reset_password',
      targetType: 'user',
      targetId: targetUserId,
      ipAddress: ip,
      meta: { email: target.email },
    });

    return { email: target.email, tempPassword };
  }

  /**
   * স্টাফ ↔ ম্যানেজার — portal অ্যাকাউন্টের ভূমিকা বদলানো।
   *
   * ⚠️⚠️ **কেন এটা দরকার হলো:** ভূমিকা বসত কেবল অ্যাকাউন্ট **খোলার
   * সময়**, আর বদলানোর কোনো পথ ছিল না। কাউকে ম্যানেজার করতে হলে তাঁর
   * অ্যাকাউন্ট মুছে নতুন করে খুলতে হতো — অর্থাৎ নতুন পাসওয়ার্ড, আর
   * তাঁর সব `user_id`-নির্ভর ইতিহাস (audit log) ছিঁড়ে যেত।
   *
   * ⚠️ `owner` এখান থেকে **দেওয়াও যায় না, কাড়াও যায় না**:
   *
   *   · দেওয়া যায় না — owner মানে বেতন, audit log আর সেটিংসের চাবি।
   *     সেটা একটা ড্রপডাউনের এক ক্লিকে হাতবদল হওয়ার জিনিস নয় (ADR-011d,
   *     আর ওয়েবের `PORTAL_ROLES`-এও owner নেই)।
   *   · কাড়া যায় না — এই রুটে ঢুকতে owner হতে হয়, তাই নিজেকে বা শেষ
   *     owner-কে নামিয়ে দিলে **কেউ আর ঢুকতেই পারত না**, আর ফেরার পথ
   *     হতো সার্ভারে `recover-owner` স্ক্রিপ্ট।
   *
   * ⭐ ভূমিকা বদলালে চলতি সেশনেও খাটে — `JwtAuthGuard` টোকেন নতুন করে
   * দেওয়ার সময় ডাটাবেস থেকেই ভূমিকা পড়ে (৫ মিনিটের ভেতরে)।
   */
  async changeRole(
    actorId: number,
    targetUserId: number,
    /**
     * ⚠️ `owner` তালিকার বাইরে — উপরের টীকা দেখুন। বাকিগুলো হাতে লেখা,
     * `UserRole` ধার করা নয়: enum-এ কাল নতুন কিছু বসলে সেটা এখানে
     * **নিজে থেকে ঢুকে পড়া উচিত নয়** (কন্ট্রোলারের `@IsIn`-এও একই তালিকা)।
     */
    role: 'employee' | 'researcher' | 'manager',
    ip: string,
  ): Promise<{ id: number; email: string; role: UserRole }> {
    const target = await this.prisma.user.findUnique({
      where: { id: targetUserId },
      select: { id: true, email: true, role: true },
    });
    if (!target) throw new NotFoundException('User not found');

    if (target.role === UserRole.owner) {
      throw new ConflictException(
        'Owner accounts cannot be changed here. Owners are managed on the server.',
      );
    }

    // ⚠️ একই ভূমিকা হলে চুপচাপ ফেরা — audit log-এ "বদল" লেখা হবে না,
    //    নইলে ইতিহাসে এমন ঘটনা জমত যেখানে আসলে কিছুই বদলায়নি।
    if (target.role === role) {
      return { id: target.id, email: target.email, role: target.role };
    }

    const updated = await this.prisma.user.update({
      where: { id: targetUserId },
      data: { role },
      select: { id: true, email: true, role: true },
    });

    await this.audit.record({
      userId: actorId,
      action: 'change_setting',
      targetType: 'user',
      targetId: targetUserId,
      ipAddress: ip,
      // ⚠️ আগেরটাও লেখা — "কে কখন ম্যানেজার হলো" প্রশ্নের উত্তর
      //    দিতে হলে শুধু নতুন মানটা যথেষ্ট নয়
      meta: { op: 'change_role', from: target.role, to: role },
    });

    return updated;
  }

  /**
   * লগইনের ইমেইল বদলানো — অর্থাৎ স্টাফের "ইউজারনেম"।
   *
   * ⚠️⚠️ **কেন এটা দরকার হলো:** portal অ্যাকাউন্ট খোলার সময় ইমেইলটা হাতে
   * টাইপ করতে হয়, আর ভুল হলে ওই অ্যাকাউন্ট চিরকাল ভুল ঠিকানায় আটকে থাকত —
   * বদলানোর কোনো পথ ছিল না। ১৫ জনের জন্য একবার করে টাইপ করলে অন্তত একটা
   * টাইপো হওয়াই স্বাভাবিক।
   *
   * ⚠️ পাসওয়ার্ড এখানে ছোঁয়া হয় **না** — সেটা `resetPassword()`। দুটো
   * আলাদা রাখা ইচ্ছাকৃত: ইমেইলের বানান ঠিক করতে গিয়ে কারো পাসওয়ার্ড
   * অকারণে বদলে যাওয়া উচিত নয়।
   */
  async changeLoginEmail(
    actorId: number,
    targetUserId: number,
    email: string,
    ip: string,
  ): Promise<{ id: number; email: string }> {
    const next = email.trim().toLowerCase();
    if (!next.includes('@')) {
      throw new BadRequestException('That does not look like an email address');
    }

    const target = await this.prisma.user.findUnique({
      where: { id: targetUserId },
    });
    if (!target) throw new NotFoundException('User not found');

    if (target.email === next) return { id: target.id, email: target.email };

    // ⚠️ আগে থেকে দেখা হয়, শুধু unique constraint-এর ভরসায় নয় — নইলে
    //    পর্দায় যেত Prisma-র P2002, যেটা পড়ে কেউ বুঝত না কী ভুল হয়েছে।
    const taken = await this.prisma.user.findUnique({ where: { email: next } });
    if (taken) {
      throw new ConflictException('Another account already uses that email');
    }

    const updated = await this.prisma.user.update({
      where: { id: targetUserId },
      data: { email: next },
    });

    await this.audit.record({
      userId: actorId,
      action: 'change_login_email',
      targetType: 'user',
      targetId: targetUserId,
      ipAddress: ip,
      // ⭐ আগেরটাও লেখা থাকে — কে কার লগইন বদলেছে, সেটা পরে মেলানোর
      //    একমাত্র উপায় এটাই
      meta: { from: target.email, to: next },
    });

    return { id: updated.id, email: updated.email };
  }

  /** স্টাফের self-view অ্যাকাউন্ট (J04/J05) — owner খোলে */
  /**
   * ⭐⭐ **`chosen` দিলে সেটাই বসে, আর বদলানোর পর্দা আসে না**
   * *(২৩ আগস্ট, মালিকের সিদ্ধান্ত)*।
   *
   * ⚠️⚠️ না দিলে **আগের আচরণই অক্ষত** — এলোমেলো পাসওয়ার্ড + প্রথম
   * লগইনে বাধ্যতামূলক বদল। ওই ধাপটার আসল উদ্দেশ্য ছিল "মালিকের জানা
   * পাসওয়ার্ড চিরকাল না থাকা"; মালিক নিজে বসালে সেটা তিনি **জেনেবুঝে**
   * ছাড়ছেন, কিন্তু ডিফল্টটা নিরাপদ থাকাই উচিত।
   */
  async createPortalAccount(
    actorId: number,
    employeeId: number,
    email: string,
    role: UserRole,
    ip: string,
    chosen?: string,
  ): Promise<{ userId: number; email: string; tempPassword: string }> {
    const employee = await this.prisma.employee.findUnique({
      where: { id: employeeId },
    });
    if (!employee) throw new NotFoundException('Staff member not found');

    const normalized = email.toLowerCase();
    const existing = await this.prisma.user.findUnique({
      where: { email: normalized },
    });
    if (existing) {
      throw new BadRequestException('An account with this email already exists');
    }

    // ⚠️ মালিক নিজে বসালে সেটাই; নইলে আগের মতো এলোমেলো
    const tempPassword = chosen ?? this.passwords.generateTempPassword();

    const created = await this.prisma.user.create({
      data: {
        email: normalized,
        passwordHash: await this.passwords.hash(tempPassword),
        fullName: employee.fullName,
        role,
        employeeId,
        /**
         * ⚠️⚠️ **কখনো বাধ্যতামূলক নয়** *(২৩ আগস্ট, মালিকের সিদ্ধান্ত —
         * দ্বিতীয়বার)*।
         *
         * প্রথমে ঘরটা খালি রাখলে পুরোনো আচরণ (বাধ্যতামূলক বদল) রেখে
         * দেওয়া হয়েছিল, "নিরাপত্তার জাল ছিঁড়ব না" যুক্তিতে। ⚠️ কিন্তু
         * মালিক পরদিনই আবার ওই দেয়ালে আটকালেন — Reset চেপে, ঘরটা খালি
         * রেখে। **তিনি যা চেয়েছিলেন সেটাই করা হয়নি**, আর আধা-মানা
         * সিদ্ধান্ত মানে অর্ধেক সময় পুরোনো আচরণই ফিরে আসা।
         *
         * ⭐ পাসওয়ার্ড না দিলে এলোমেলো একটা বানানো হয় (মালিককে একবার
         * দেখানো হয়) — কিন্তু বদলাতে **বলা হয় না**। কর্মী চাইলে
         * Security পাতায় নিজেই বদলাবেন।
         */
        mustChangePw: false,
        pwChangedAt: new Date(),
      },
    });

    await this.audit.record({
      userId: actorId,
      action: 'create_portal_account',
      targetType: 'employee',
      targetId: employeeId,
      ipAddress: ip,
      meta: { email: normalized, role },
    });

    return { userId: created.id, email: normalized, tempPassword };
  }
}
