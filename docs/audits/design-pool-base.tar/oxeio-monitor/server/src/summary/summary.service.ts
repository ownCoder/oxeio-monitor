import { Injectable, Logger } from '@nestjs/common';
import { SegmentState, type Prisma } from '@prisma/client';

import { workDateOf } from '../agent/util/dhaka-time';
import { PrismaService } from '../prisma/prisma.service';
import { TargetsService } from '../targets/targets.service';
import { designFirstSeenInDay, keepKnownLongIds, KNOWN_JOB_FROM } from './design.rules';
import { trackedFromBy } from './tracking-start';
import { prorate } from './proration';
import {
  elapsedWorkdays,
  observedWorkdays,
  hoursToSec,
  isWorkday,
  monthBounds,
  rollupMonth,
  summarizeDay,
  type Span,
} from './summary.math';

/** work policy না থাকলে স্পেকের ডিফল্ট (07 § ১) */
const DEFAULT_TARGET_HOURS = 208;

/**
 * ⚠️ পলিসি না থাকলে ২৬ — কারণ ২০৮ ÷ ২৬ = ৮ ঘণ্টা, স্পেকের দৈনিক টার্গেট।
 * দুটো ডিফল্ট আলাদা হয়ে গেলে দৈনিক টার্গেট নীরবে অন্য সংখ্যা হয়ে যেত।
 */
const DEFAULT_POLICY_WORKDAYS = 26;

interface EmployeePolicy {
  id: number;
  /** পলিসির মাসিক টার্গেট (২০৮ঘ) — ⚠️ এটা আর সরাসরি target_sec নয়, G37-এর পর */
  targetSec: number;
  /** পলিসির `expected_workdays` (২৬) — দৈনিক টার্গেট এটা দিয়েই ভাগ হয় */
  policyWorkdays: number;
  /** ISO দিন (শুক্র = ৫), null = প্রতিটি দিনই কর্মদিবস */
  weeklyOffDay: number | null;
  /** G37 — `null` = আগে থেকেই আছে / এখনো আছে */
  joinedOn: Date | null;
  leftOn: Date | null;
}

/**
 * ⭐ একটা টিকে সর্বোচ্চ কতগুলো পুরোনো দিন গোনা হবে।
 *
 * ⚠️ ১৪ — অর্থাৎ দু-সপ্তাহের ব্যাকলগ একটা টিকেই মিটে যায়, অথচ একটা টিক
 *    ১৫ মিনিটের বাজেট ছাড়ায় না (একটা দিন গুনতে লাগে সেকেন্ডের ভগ্নাংশ)।
 */
export const DIRTY_PER_TICK = 14;

/** ⭐ নিষ্কাশনের ফল — লগে ও টেস্টে দুটোতেই পড়া হয় */
export interface DrainResult {
  /** কতগুলো দিন সত্যিই আবার গোনা হলো */
  refreshed: number;
  /** বন্ধ মাসে পড়ায় বাদ (R1) — চিহ্ন তবু তোলা হয়েছে */
  closed: number;
  /** এখনো কিউতে বাকি — ছাদে আটকালে শূন্যের বেশি */
  pending: number;
}

export interface RefreshResult {
  workDate: Date;
  employees: number;
}

/**
 * ⭐ `daily_summary` ও `monthly_summary` — rollup লেখার একমাত্র জায়গা।
 *
 * K06 (প্রতি ১৫ মিনিট) আর K05 (দিন-ক্লোজ) দুটোই এই একই কোড ডাকে। আলাদা
 * করে লিখলে দিন-ক্লোজে কোনো একটা কলাম অন্যভাবে হিসাব হতো, আর দিনের বেলার
 * সংখ্যা মাঝরাতে নীরবে বদলে যেত — যে বাগ ধরা পড়তে মাস লেগে যায়।
 *
 * ⚠️ এই সার্ভিস `activity_segments`-এ **কখনো হাত দেয় না**। কাঁচা ডেটা
 * অপরিবর্তনীয় (§ ২.১-ঙ, নিয়ম ৪) — সারাংশ যেকোনো সময় শূন্য থেকে আবার
 * বানানো যায়, আর সেজন্যই upsert, insert নয়।
 */
@Injectable()
export class SummaryService {
  private readonly logger = new Logger(SummaryService.name);

  constructor(
    private readonly prisma: PrismaService,
    /** ⭐ ফাইলের নামে পাওয়া নম্বর দিয়ে বরাদ্দ করা টার্গেট বন্ধ করতে (২২ আগস্ট) */
    private readonly targets: TargetsService,
  ) {}

  /** ঢাকার আজকের কর্মদিবস — K06-এর প্রবেশপথ। */
  refreshToday(now: Date = new Date()): Promise<RefreshResult> {
    return this.refreshDate(workDateOf(now), now);
  }

  /**
   * ⭐⭐⭐ **দেরিতে আসা দিনগুলো আবার গুনে নেওয়া** *(৬ সেপ্টেম্বর ২০২৬)*।
   *
   * ⚠️⚠️ **যে বাগটা এটা সারায়:** rollup চলত কেবল **দুটো** দিনের উপর — আজ
   * (K06) আর গতকাল (K05, ০০:১৫-তে **একবার**)। এর বাইরের কোনো দিনের
   * সেগমেন্ট পরে এলে `daily_summary`-তে কোনোদিন উঠত না, আর সেখান থেকে
   * মাসিক সারি ও বেতনের ঘাটতি। মাঠে মাপা ক্ষতি: **৩৯টা (কর্মী, দিন)
   * জোড়া, ১৭.৭৮ ঘণ্টা**।
   *
   * ⚠️ **একবারে কতগুলো, তার ছাদ আছে** — একটা দিন গুনতে গোটা দলের সেগমেন্ট
   * merge করতে হয়, আর জবটা চলে ১৫ মিনিট পরপর। ছাদ না থাকলে বড় ব্যাকলগে
   * একটা টিক পরের টিককে ছাড়িয়ে যেত, আর `RunLock` ওগুলো একে একে বাদ দিত।
   * ⭐ ছাদে আটকালে বাকিগুলো পরের টিকে আসে — কারণ চিহ্ন মোছা হয় **গোনার
   * পরে**।
   *
   * ⚠️⚠️ **বন্ধ মাস ছোঁয়া হয় না** (R1)। ⭐ কিন্তু চিহ্নটা তবু **তুলে
   * দেওয়া হয়** — নইলে ওই সারিটা চিরকাল কিউয়ের মাথায় বসে থাকত আর
   * প্রতিটা টিকে একবার করে বৃথা চেষ্টা হতো।
   */
  async drainDirty(
    now: Date = new Date(),
    limit = DIRTY_PER_TICK,
  ): Promise<DrainResult> {
    const marks = await this.prisma.summaryDirty.findMany({
      // ⚠️ পুরোনো আগে — নইলে ব্যাকলগ থাকলে সবচেয়ে পুরোনো দিনটা
      //    চিরকাল অপেক্ষা করত
      orderBy: { markedAt: 'asc' },
      take: limit,
      select: { workDate: true },
    });

    let refreshed = 0;
    let closed = 0;

    for (const mark of marks) {
      const { yearMonth } = monthBounds(mark.workDate);
      const shut = await this.prisma.monthClosure.findUnique({
        where: { yearMonth },
        select: { yearMonth: true },
      });

      if (shut === null) {
        await this.refreshDate(mark.workDate, now);
        refreshed += 1;
      } else {
        closed += 1;
      }

      // ⚠️ চিহ্ন মোছা হয় **গোনার পরে** — মাঝপথে থেমে গেলে দিনটা যেন
      //    পরের টিকে আবার আসে
      await this.prisma.summaryDirty.delete({
        where: { workDate: mark.workDate },
      });
    }

    const pending = await this.prisma.summaryDirty.count();
    return { refreshed, closed, pending };
  }

  /**
   * একটা কর্মদিবসের সারাংশ নতুন করে বসায়, তারপর ওই দিনের মাসটাও।
   *
   * ⚠️ **সব active কর্মীর** জন্য চলে, শুধু যাদের ডেটা আছে তাদের নয়। খরচ
   * নগণ্য (১৫ জন), আর বিনিময়ে যে দিন কেউ একেবারেই কাজ করেনি সেদিনও একটা
   * `no_activity` সারি তৈরি হয় — হিটম্যাপে ওই ফাঁকা ঘরটা তখন "ডেটা আসেনি"
   * নাকি "কাজ হয়নি" সেই সন্দেহ আর থাকে না।
   */
  async refreshDate(
    workDate: Date,
    now: Date = new Date(),
    /**
     * ⭐⭐⭐ **যাঁরা active নন, তবু এবার গুনতে হবে** *(৬ সেপ্টেম্বর ২০২৬)*।
     *
     * ⚠️⚠️ **যে বাগটা এটা সারায়:** নিষ্ক্রিয় কর্মীর জন্য সময়-সংশোধন
     * ডাটাবেসে বসত, পর্দায় দেখাও যেত, কিন্তু rollup কেবল **active**
     * কর্মীদের নিয়ে চলে — তাই সংখ্যাটা `daily_summary`-তে কোনোদিন
     * পৌঁছাত না, আর বেতনেও নয়। কোনো এরর নয়, শুধু একটা সংশোধন যা
     * কিছুই বদলাত না।
     *
     * ⚠️ চলে যাওয়া কর্মীর **শেষ মাসের** হিসাব ঠিক করা একটা বৈধ কাজ
     *    (চূড়ান্ত পাওনা মেটানোর আগে), তাই পথটা বন্ধ করা হয়নি — কেবল
     *    ওই একজনকে এই রানে যোগ করা হয়।
     */
    also: readonly number[] = [],
  ): Promise<RefreshResult> {
    const employees = await this.activeEmployees(also);
    if (employees.length === 0) {
      return { workDate, employees: 0 };
    }

    const ids = employees.map((e) => e.id);

    const [segments, shots, adjustments, usage, holiday, designTitles] =
      await Promise.all([
      this.prisma.activitySegment.findMany({
        where: { workDate, employeeId: { in: ids } },
        select: {
          employeeId: true,
          state: true,
          startedAt: true,
          endedAt: true,
          durationSec: true,
        },
      }),
      this.prisma.screenshot.groupBy({
        by: ['employeeId'],
        // ⚠️ retention যেগুলো মুছে ফেলার জন্য মার্ক করেছে সেগুলো বাদ —
        //    গ্যালারিতে যা দেখা যায় না, গোনাতেও তা থাকা উচিত নয়
        where: { workDate, employeeId: { in: ids }, deletedAt: null },
        _count: { _all: true },
      }),
      this.prisma.timeAdjustment.groupBy({
        by: ['employeeId'],
        // ⚠️ revoke করা সংশোধন বাদ (§ ২.১-ঙ) — ডিলিট হয় না, তাই ফিল্টারই ভরসা
        where: { workDate, employeeId: { in: ids }, revokedAt: null },
        _sum: { deltaSec: true },
      }),
      this.prisma.appUsage.findMany({
        // ⭐ R22a — শুধু ACTIVE-এ দেখা খণ্ড (idle সারি হিসাবে যায় না)
        where: {
          workDate,
          employeeId: { in: ids },
          categoryId: { not: null },
          segmentState: SegmentState.active,
        },
        select: {
          employeeId: true,
          startedAt: true,
          endedAt: true,
          category: { select: { category: true } },
        },
      }),
      this.prisma.holiday.findUnique({ where: { holidayDate: workDate } }),
      /**
       * ⭐⭐ **ডিজাইনের নম্বর** *(২১ আগস্ট)* — ডিজাইন-অ্যাপের শিরোনাম।
       *
       * ⚠️ উপরের `usage` কোয়েরিটা কাজে লাগানো যেত না: ওটা `categoryId`
       * থাকা ও **ACTIVE** সারিই আনে (productivity-র হিসাব), অথচ ডিজাইনের
       * নম্বর ওই দুটো শর্তের বাইরেও থাকে — Illustrator ক্যাটাগরিতে না
       * পড়লেই ডিজাইন গোনা বন্ধ হয়ে যেত, আর কেউ বুঝতেই পারত না কেন।
       *
       * ⚠️ `windowTitle` এখানে আসে ঠিকই, কিন্তু **কোথাও জমা হয় না** —
       * `designIdsInDay()` কেবল সামনের নম্বরটা ফেরত দেয় (মালিকের শর্ত)।
       */
      this.prisma.appUsage.findMany({
        where: {
          workDate,
          employeeId: { in: ids },
          processName: { in: ['Illustrator.exe', 'Photoshop.exe'] },
        },
        /**
         * ⚠️ `startedAt`-ও আসে *(G163)* — টার্গেটে "কাজ শুরু" চিহ্নটা ঠিক
         *    এই মুহূর্তটাই। আগে আনা হতো না, তাই কলার বাধ্য হয়ে কর্মদিবসের
         *    লেবেলটা বসাত, আর সবার "শুরু" হয়ে যেত ভোর ৬টা।
         */
        select: {
          employeeId: true,
          processName: true,
          windowTitle: true,
          startedAt: true,
        },
      }),
    ]);

    const segmentsBy = groupBy(segments, (s) => s.employeeId);
    const shotsBy = new Map(shots.map((s) => [s.employeeId, s._count._all]));
    const adjustBy = new Map(
      adjustments.map((a) => [a.employeeId, a._sum.deltaSec ?? 0]),
    );

    const productiveBy = new Map<number, Span[]>();
    const unproductiveBy = new Map<number, Span[]>();
    for (const u of usage) {
      const bucket =
        u.category?.category === 'productive'
          ? productiveBy
          : u.category?.category === 'unproductive'
            ? unproductiveBy
            : null;
      // neutral আর ক্যাটাগরিহীন — দুটোই productivity ভগ্নাংশের বাইরে
      if (bucket === null) continue;
      push(bucket, u.employeeId, u);
    }

    const holidays = new Set(holiday ? [workDate.getTime()] : []);

    const designsBy = await this.claimDesigns(designTitles, workDate);

    const ops: Prisma.PrismaPromise<unknown>[] = [];

    for (const e of employees) {
      const numbers = summarizeDay({
        segments: segmentsBy.get(e.id) ?? [],
        screenshotCount: shotsBy.get(e.id) ?? 0,
        adjustmentSec: adjustBy.get(e.id) ?? 0,
        productiveSpans: productiveBy.get(e.id) ?? [],
        unproductiveSpans: unproductiveBy.get(e.id) ?? [],
        isOffDay: !isWorkday(workDate, e.weeklyOffDay, holidays),
      });

      // ⚠️ `summarizeDay`-র ভেতরে ঢোকানো হয়নি — ওটা **সময়ের** খাঁটি অঙ্ক,
      //    আর ডিজাইনের সংখ্যা সময় নয়। মিশিয়ে দিলে ওই ফাংশনের টেস্টগুলোয়
      //    হঠাৎ ডাটাবেসের দরকার পড়ত।
      const designsDone = designsBy.get(e.id) ?? 0;

      ops.push(
        this.prisma.dailySummary.upsert({
          where: { employeeId_workDate: { employeeId: e.id, workDate } },
          create: {
            employeeId: e.id,
            workDate,
            ...numbers,
            designsDone,
            computedAt: now,
          },
          update: { ...numbers, designsDone, computedAt: now },
        }),
      );
    }

    // এক ট্রানজেকশনে — ১৫টা আলাদা রাউন্ড-ট্রিপের বদলে একটাই, আর ড্যাশবোর্ড
    // কখনো "অর্ধেক কর্মীর হালনাগাদ, বাকিদের পুরোনো" অবস্থায় দেখে না
    await this.prisma.$transaction(ops);

    await this.refreshMonth(workDate, employees, now);

    return { workDate, employees: employees.length };
  }

  /**
   * ⭐⭐ **আজ কতগুলো নতুন ডিজাইন** — কর্মী ধরে।
   *
   * ⚠️⚠️ **"খোলা" আর "নতুন" এক নয়, আর তফাতটা বড়।** গতকালের ফাইল আজ আবার
   * খুললে সেটা আজকের কাজ নয়। মাঠে মেপে দেখা গেছে একজনের ৩৯ নেমে দাঁড়ায়
   * **২৪**-এ — অর্থাৎ সরল "আজ যতগুলো দেখা গেছে" নিয়মটা টার্গেটের চেয়ে
   * ৫০%-ও বেশি দেখাতে পারত, আর সেই সংখ্যার উপর কারো মূল্যায়ন দাঁড়াত।
   *
   * ⭐ তাই প্রতিটা (কর্মী, ডিজাইন) জোড়া `design_credits`-এ **একবারই** বসে;
   * প্রাথমিক কী-ই দ্বিতীয়বার বসতে দেয় না (`skipDuplicates`)। "আজকের
   * সংখ্যা" = আজকের তারিখে দাবি করা সারি।
   *
   * ⚠️⚠️ **ক্রমের একটা সীমা লিখে রাখা দরকার:** ক্রেডিট দাবি হয় *যে দিনটা
   * আগে হিসাব হয়* তার নামে। স্বাভাবিক চলায় দিন এগোয় সামনের দিকে, তাই
   * ঠিকই থাকে — কিন্তু কেউ **পুরোনো** একটা দিন নতুন করে হিসাব করালে ওই
   * দিনের ডিজাইনগুলো ইতিমধ্যে পরের দিনের নামে বসে থাকতে পারে, আর তখন
   * পুরোনো দিনটা কম দেখাবে। ব্যাকফিল করলে **পুরোনো থেকে নতুন** ক্রমে।
   *
   * ⚠️ কখনো throw করে না — ডিজাইনের সংখ্যা একটা বাড়তি মাপ; ওটার জন্য
   * ঘণ্টার সারাংশ আটকে যাওয়া চলবে না।
   */
  private async claimDesigns(
    titles: readonly {
      employeeId: number;
      processName: string;
      windowTitle: string | null;
      startedAt: Date;
    }[],
    workDate: Date,
  ): Promise<Map<number, number>> {
    const counts = new Map<number, number>();
    if (titles.length === 0) return counts;

    const byEmployee = groupBy(titles, (t) => t.employeeId);

    try {
      for (const [employeeId, rows] of byEmployee) {
        // ⭐ G163 — নম্বরের সাথে "কখন প্রথম দেখা গেল" মুহূর্তটাও
        const firstSeen = designFirstSeenInDay(rows);
        if (firstSeen.size === 0) continue;

        const raw = new Set(firstSeen.keys());

        /**
         * ⭐⭐ **সাত অঙ্ক বা বেশি হলে নম্বরটা সত্যিই বরাদ্দ করা হতে হবে**
         * *(২২ আগস্ট ২০২৬)*।
         *
         * ⚠️⚠️ শিরোনাম-নিয়মটা সাত অঙ্ক পর্যন্ত নেয় (কাজের নম্বর
         * ১০,০০,০০০ থেকে শুরু), কিন্তু সাত অঙ্কের **স্টক-আইডিও** আছে —
         * `1536601_4406`, `5524618`, `9937760`। মাঠে এক দিনেই চারটে
         * ঢুকেছিল, আর ওগুলো ডিজাইন বলে গোনা হচ্ছিল।
         *
         * ⭐ অঙ্ক গুনে অনুমান করার বদলে **তালিকায় আছে কি না** দেখা হয় —
         * এটাই একমাত্র নিখুঁত পার্থক্য।
         *
         * ⚠️ কুয়েরিটা কেবল লম্বা নম্বরগুলোর জন্য; দিনে সাধারণত ০–৪টা।
         */
        const longOnes = [...raw]
          .map((id) => Number.parseInt(id, 10))
          .filter((n) => Number.isSafeInteger(n) && n >= KNOWN_JOB_FROM);

        const known = new Set<string>();
        if (longOnes.length > 0) {
          const found = await this.prisma.designTarget.findMany({
            where: { jobNumber: { in: longOnes } },
            select: { jobNumber: true },
          });
          for (const f of found) {
            if (f.jobNumber !== null) known.add(String(f.jobNumber));
          }
        }

        const ids = keepKnownLongIds(raw, known);
        if (ids.size === 0) continue;

        await this.prisma.designCredit.createMany({
          data: [...ids].map((designId) => ({
            employeeId,
            designId,
            firstWorkDate: workDate,
          })),
          skipDuplicates: true,
        });

        /**
         * ⭐⭐ **বরাদ্দ করা টার্গেটে "কাজ শুরু" চিহ্ন** *(২৩ আগস্ট)*।
         *
         * ⚠️⚠️ আগে এখানে টার্গেট **বন্ধ** করা হতো, আর সেটা ভুল ছিল:
         * শিরোনামে নম্বরটা দেখা যায় ফাইল **খোলার** মুহূর্তে, শেষ করার
         * নয়। শেষ হওয়া এখন ডিজাইনার নিজে বলেন।
         *
         * ⚠️ একই `ids` সেট — দুবার শিরোনাম পড়া হয় না।
         */
        /**
         * ⚠️⚠️ **কর্মদিবসের লেবেল নয়, আসল মুহূর্ত** *(G163)*। এখানে আগে
         * `workDate` যেত — অর্থাৎ ঢাকার ভোর ৬টা — আর MyTargets-এ জব
         * খোলামাত্র লেখা উঠত *"Started 5 hours ago"*।
         */
        await this.targets.markStartedByJobNumbers(
          employeeId,
          new Map([...ids].map((id) => [id, firstSeen.get(id)!])),
        );
      }

      // ⚠️ দাবি করার **পরে** গোনা হয়, আগে নয় — নইলে আজ প্রথমবার দেখা
      //    ডিজাইনগুলো এই রানে গোনায় পড়ত না, আর সংখ্যাটা একদিন পিছিয়ে থাকত।
      const claimed = await this.prisma.designCredit.groupBy({
        by: ['employeeId'],
        where: { firstWorkDate: workDate, employeeId: { in: [...byEmployee.keys()] } },
        _count: { _all: true },
      });

      for (const row of claimed) counts.set(row.employeeId, row._count._all);
    } catch (err) {
      this.logger.warn(
        `Could not count designs for ${workDate.toISOString().slice(0, 10)}: ${
          err instanceof Error ? err.message : String(err)
        }`,
      );
    }

    return counts;
  }

  /**
   * ওই তারিখ যে মাসে পড়ে, সেই মাসের rollup।
   *
   * ⚠️ মাস বের হয় **`workDate` থেকে, `now` থেকে নয়**। ১ তারিখ রাত ০০:১৫-তে
   * দিন-ক্লোজ আগের মাসের শেষ দিনটা বন্ধ করে; `now` ধরলে হালনাগাদ হতো সদ্য
   * শুরু হওয়া নতুন মাসের সারিতে, আর আগের মাসের শেষ দিনের ঘণ্টা পে-রোলে
   * কোনোদিনই যোগ হতো না।
   */
  private async refreshMonth(
    workDate: Date,
    employees: readonly EmployeePolicy[],
    now: Date,
  ): Promise<void> {
    const { start, end, yearMonth } = monthBounds(workDate);
    const ids = employees.map((e) => e.id);

    /**
     * ⭐⭐ **R1 — বন্ধ মাস আর গোনা হয় না।** এটাই পুরো ফিচারটার একমাত্র
     * কার্যকর লাইন; বাকি সব (endpoint, ৪০৯, পর্দা) এর চারপাশের মোড়ক।
     *
     * ⚠️⚠️ কেন দরকার: নিচের হিসাবটা **প্রতিবার ওই মুহূর্তের `holidays`
     *    টেবিল পড়ে** আর `prorate()` দিয়ে d ও D আবার গোনে। তাই ছুটির একটা
     *    তারিখ নড়লেই গত মাসের `target_sec` · `expected_sec` ·
     *    `expected_workdays` · `month_workdays` চারটেই পিছন ফিরে বদলাত —
     *    আর পে-রোল ওই সারি থেকেই d ও D পড়ে, অর্থাৎ **বেতন দিয়ে দেওয়ার
     *    পরেও হিসাব নড়ত**, নীরবে।
     *
     * ⚠️ ফেরত যাওয়া হয় **নীরবে নয়** — লগে লেখা হয়, নইলে "সংখ্যা আপডেট
     *    হচ্ছে না কেন" খুঁজতে গিয়ে কেউ এখানে পৌঁছাত না।
     */
    const closed = await this.prisma.monthClosure.findUnique({
      where: { yearMonth },
      select: { closedAt: true },
    });
    if (closed) {
      this.logger.log(
        `${yearMonth} is closed (${closed.closedAt.toISOString()}) — monthly figures left untouched`,
      );
      return;
    }

    const [days, holidayRows, leaveRows, existing, firstSeen] = await Promise.all([
      this.prisma.dailySummary.findMany({
        where: { employeeId: { in: ids }, workDate: { gte: start, lte: end } },
        select: {
          employeeId: true,
          // ⭐ ৬ সেপ্টেম্বর — কোন দিনগুলো সত্যিই **দেখা** হয়েছে, সেটা
          //    জানতে সারির তারিখটাই একমাত্র সূত্র (`observedWorkdays`)
          workDate: true,
          workedSec: true,
          adjustmentSec: true,
        },
      }),
      this.prisma.holiday.findMany({
        where: { holidayDate: { gte: start, lte: end } },
        select: { holidayDate: true },
      }),
      /**
       * ⭐⭐ R2 — **এই মাসে এই কর্মীদের ছুটি**, কর্মীপ্রতি।
       *
       * ⚠️⚠️ `holidays`-এর সাথে এক সেটে মেশানো হয় **না**। `holidays`
       *    সংস্থার, আর ওটা দিয়েই D গোনা হয় — একজনের ছুটি ওখানে ঢুকলে
       *    গোটা দলের বেতনের হর বদলে যেত।
       */
      this.prisma.leave.findMany({
        where: { employeeId: { in: ids }, leaveDate: { gte: start, lte: end } },
        select: { employeeId: true, leaveDate: true },
      }),
      this.prisma.monthlySummary.findMany({
        where: { employeeId: { in: ids }, yearMonth },
        select: { employeeId: true, targetMetAt: true },
      }),
      /**
       * ⭐⭐ **সার্ভার কবে থেকে এই কর্মীকে নিয়ে হিসাব করছে** — তার সবচেয়ে
       * পুরোনো `daily_summary` সারি।
       *
       * ⚠️⚠️ নামটা যেন বিভ্রান্ত না করে: এটা **"এজেন্ট কবে বসেছে" নয়**।
       *    ঠিক নিচের লুপটাই (`refreshDate()`) প্রতিটি active কর্মীর সারি
       *    লেখে, ডেটা থাক বা না থাক — তাই কেউ active হওয়ার দিনেই তার
       *    প্রথম সারি বসে যায়, এজেন্ট তখনো না পৌঁছালেও।
       *
       * ⚠️⚠️ **কর্মীপ্রতি, সংস্থা-স্তরে নয়** — এখানে আগে `where` ছাড়া
       *    একটাই `findFirst` ছিল, অর্থাৎ পুরো সংস্থার প্রথম দিন। তাতে
       *    দুটো ভুল হতো:
       *      ১· পরে যোগ হওয়া কর্মীর জানালা সংস্থার প্রথম দিন থেকে শুরু
       *         হতো — অর্থাৎ সে সিস্টেমে আসার **আগের** মাসগুলোও তার
       *         ঘাটতিতে ঢুকত (`joined_on` খালি বা ঢিলে হলে যা খুবই সম্ভব)।
       *      ২· কোয়েরিটা নিষ্ক্রিয় কর্মীর সারিও পড়ত, তাই বহু আগে চলে
       *         যাওয়া কারো ডেটা গোটা দলের জানালা পিছিয়ে দিত।
       *
       * ⚠️⚠️ **যেটা এটা সারায় না:** ১ অক্টোবর যোগ দিয়ে ৮ অক্টোবর এজেন্ট
       *    পাওয়া কর্মীর ৫টা এজেন্টহীন দিন এখনো পুরো ঘাটতি — কারণ ১
       *    তারিখেই তার `no_activity` সারি লেখা হয়ে যায়। আগে এখানে ঠিক
       *    এই কেসটা "সারানো হয়েছে" বলে দাবি করা ছিল; দাবিটা মিথ্যা ছিল।
       *    ⭐ সারাতে হলে গোনা শুরু করতে হতো প্রথম **`worked`** সারি থেকে,
       *    আর তাতে সত্যিকারের প্রথম-দিকের অনুপস্থিতিও অদৃশ্য হয়ে যেত।
       *
       * ⚠️ **মাস দিয়ে ছাঁকা হয় না** — ইচ্ছাকৃত। প্রশ্নটা "এই মাসে তার
       *    ডেটা আছে কি" নয়, "তাকে কবে থেকে দেখছি"। মাস দিয়ে ছাঁকলে প্রতিটি
       *    মাসের ১ তারিখেই ট্র্যাকিং নতুন করে "শুরু" হতো, আর সেপ্টেম্বরের
       *    প্রত্যাশা আগস্টের মতোই ভুল কাটা পড়ত।
       */
      trackedFromBy(this.prisma, ids),
    ]);

    const holidays = new Set(holidayRows.map((h) => h.holidayDate.getTime()));

    const leaveBy = new Map<number, Set<number>>();
    for (const l of leaveRows) {
      let set = leaveBy.get(l.employeeId);
      if (!set) leaveBy.set(l.employeeId, (set = new Set()));
      set.add(l.leaveDate.getTime());
    }
    const daysBy = groupBy(days, (d) => d.employeeId);
    const metAtBy = new Map(existing.map((m) => [m.employeeId, m.targetMetAt]));

    /**
     * ⚠️ `refreshDate()` আজকের দৈনিক সারি **আগে** লিখে তারপর এখানে আসে,
     * তাই একেবারে প্রথম রানে এটা আজকের তারিখই হবে — আর তখন প্রত্যাশা ০,
     * যেটাই সৎ: শেষ হয়ে যাওয়া একটা দিনও এখনো দেখা হয়নি।
     */
    // ⭐ হেল্পার Map-ই ফেরত দেয় — এখানে আর জোড়া লাগানোর কিছু নেই

    const today = workDateOf(now);

    const ops: Prisma.PrismaPromise<unknown>[] = [];

    for (const e of employees) {
      const rows = daysBy.get(e.id) ?? [];
      const leaveDates = leaveBy.get(e.id);

      /**
       * ⭐⭐ **G37 · ADR-025** — টার্গেট আর ফ্ল্যাট ২০৮ নয়, **তার কর্মদিবস
       * × দৈনিক টার্গেট**। যে ১৫ তারিখে যোগ দিয়েছে তার টার্গেট ১৪ × ৮।
       *
       * ⚠️ `expectedWorkdays` কলামটার **মানে এখানেই বদলায়** — "মাসের
       * কর্মদিবস" থেকে "তার কর্মদিবস"। D আলাদা কলামে যায়, কারণ পে-রোলে
       * d ÷ D লাগে আর দুটো একই সময়ের হিসাব হওয়া চাই।
       */
      const p = prorate({
        monthStart: start,
        monthEnd: end,
        joinedOn: e.joinedOn,
        leftOn: e.leftOn,
        weeklyOffDay: e.weeklyOffDay,
        holidays,
        monthlyTargetSec: e.targetSec,
        policyWorkdays: e.policyWorkdays,
        leaveDates,
      });

      /**
       * ⚠️ `workdaysElapsed`-ও তার কর্মকালের ভেতরেই গোনা হয়। নইলে ১৫
       * তারিখে যোগ দেওয়া কর্মী মাসের শুরু থেকে "পিছিয়ে" দেখাত — প্রথম
       * দিনেই ৮০ ঘণ্টা ঘাটতি নিয়ে শুরু করত।
       *
       * ⭐⭐ জানালার তিনটে সীমাই (**তার** ট্র্যাকিং-শুরু, যোগ/ছাড়ার দিন,
       *    আর আজকের দিনটা বাদ) `elapsedWorkdays()`-এ — কেন, সেখানকার নোট
       *    দেখুন। tray (`progress.service.ts`), Live Board আর রিপোর্ট
       *    (F01/F02) **এই একই ফাংশনটাই** ডাকে, তাই চার পর্দায় সংখ্যাটা
       *    আর আলাদা হতে পারে না। হিসাবটা খাঁটি ফাংশনে রাখা হয়েছে বলেই
       *    `tracking-start.spec.ts` ডাটাবেস ছাড়াই প্রতিটা ধার পরীক্ষা করে।
       */
      const numbers = rollupMonth({
        workedSec: sum(rows.map((r) => r.workedSec)),
        adjustmentSec: sum(rows.map((r) => r.adjustmentSec)),
        targetSec: p.targetSec,
        expectedWorkdays: p.employeeWorkdays,
        monthWorkdays: p.monthWorkdays,
        /**
         * ⭐⭐ R2 — ছুটি **তিন জায়গায় একসাথে** যেতে হয়, নয়তো সংখ্যাগুলো
         * পরস্পরবিরোধী হয়: টার্গেটে (`prorate` — কমে), প্রত্যাশার হরে
         * (এখানে — কমে), আর প্রত্যাশার লবে (`elapsedWorkdays`-এর দ্বিতীয়
         * আর্গুমেন্ট — কমে)। **d ও D-তে যায় না** — ছুটি সবেতন।
         */
        leaveWorkdays: p.leaveWorkdays,
        workdaysElapsed: elapsedWorkdays({
          periodStart: start,
          periodEnd: end,
          today,
          joinedOn: e.joinedOn,
          leftOn: e.leftOn,
          /**
           * ⚠️⚠️ **`?? today`, `?? null` নয়** — এটাই G120-এর আসল লাইন।
           * `null` মানে `maxDate()`-এ "সীমা নেই", তাই যার এজেন্ট কোনোদিন
           * কিছু পাঠায়নি তার জানালা **পুরো মাস** জুড়ে খুলে যেত — অর্থাৎ
           * আগের চেয়েও বেশি ঘাটতি। `today` দিলে জানালা খালি, প্রত্যাশা ০।
           */
          trackingStartedOn: firstSeen.get(e.id) ?? today,
          weeklyOffDay: e.weeklyOffDay,
          holidays,
        }, leaveDates),
        /**
         * ⭐⭐⭐ **যতগুলো কর্মদিবস আমরা সত্যিই দেখেছি** *(৬ সেপ্টেম্বর
         * ২০২৬, মালিকের সিদ্ধান্ত: "না-দেখা দিনের জন্য কর্তন হবে না")*।
         *
         * ⚠️⚠️ উপরের `workdaysElapsed` গোনে **ক্যালেন্ডার** কর্মদিবস, তাই
         * সিস্টেম যেদিন একেবারেই চলেনি সেদিনও পুরো ৮ ঘণ্টার প্রত্যাশা
         * হয়েই থাকত। মাঠে তার দাম: আগস্টে ট্র্যাকিং শুরু ১৩–১৫ তারিখে,
         * অথচ বেতনের টার্গেট পুরো মাসের — ১২ জনের কর্তন দাঁড়াত ৳৭৯,৭৮৮,
         * যার ৳৬১,২৮০ না-দেখা দিনের জন্য।
         *
         * ⭐ "দেখা" মানে ওই দিনের `daily_summary` সারিটা লেখা হয়েছিল।
         * ⚠️ সারি **আছে অথচ ০ ঘণ্টা** মানে অনুপস্থিতি — সেটা ঘাটতিই
         *    থাকে, নইলে উল্টো দিকের ভুল হতো।
         */
        observedWorkdays: observedWorkdays(
          {
            periodStart: start,
            periodEnd: end,
            today,
            joinedOn: e.joinedOn,
            leftOn: e.leftOn,
            trackingStartedOn: firstSeen.get(e.id) ?? today,
            weeklyOffDay: e.weeklyOffDay,
            holidays,
          },
          new Set(rows.map((r) => r.workDate.getTime())),
          leaveDates,
        ),
        daysWithWork: rows.filter((r) => r.workedSec > 0).length,
      });

      /**
       * ⭐ প্রথমবার টার্গেট ছোঁয়ার সময়টা ধরে রাখা হয় — বারবার লেখা হয় না,
       * নইলে প্রতি ১৫ মিনিটে "এইমাত্র টার্গেট পূরণ হলো" হয়ে যেত।
       *
       * ⚠️ আবার টার্গেটের নিচে নেমে গেলে (কোনো সংশোধন revoke হলে) সময়টা
       * মুছে দেওয়া হয়। রেখে দিলে সারিটা এমন একটা অর্জনের দাবি করত যেটা
       * আর সত্যি নয়।
       */
      const targetMetAt = numbers.targetMet
        ? (metAtBy.get(e.id) ?? now)
        : null;

      ops.push(
        this.prisma.monthlySummary.upsert({
          where: { employeeId_yearMonth: { employeeId: e.id, yearMonth } },
          create: {
            employeeId: e.id,
            yearMonth,
            ...numbers,
            targetMetAt,
            computedAt: now,
          },
          update: { ...numbers, targetMetAt, computedAt: now },
        }),
      );
    }

    await this.prisma.$transaction(ops);
  }

  /**
   * ⚠️ শুধু `active` কর্মী — `payroll.service.ts`-এর মতোই। চলে যাওয়া কারো
   * পুরোনো rollup সারি থেকে যায় (রিপোর্টের জন্য দরকার), কিন্তু নতুন করে
   * হিসাব হয় না — তাঁর তো আর ডেটাই আসছে না।
   */
  private async activeEmployees(
    also: readonly number[] = [],
  ): Promise<EmployeePolicy[]> {
    const rows = await this.prisma.employee.findMany({
      /**
       * ⚠️ `also` খালি হলে শর্তটা হুবহু আগের মতোই — `OR`-এর দ্বিতীয়
       *    শাখা তখন `id in []`, যা কাউকেই মেলায় না।
       */
      where:
        also.length === 0
          ? { status: 'active' }
          : { OR: [{ status: 'active' }, { id: { in: [...also] } }] },
      select: {
        id: true,
        joinedOn: true,
        leftOn: true,
        policy: {
          select: {
            monthlyTargetHours: true,
            weeklyOffDay: true,
            expectedWorkdays: true,
          },
        },
      },
      orderBy: { id: 'asc' },
    });

    return rows.map((r) => ({
      id: r.id,
      targetSec: hoursToSec(
        Number(r.policy?.monthlyTargetHours ?? DEFAULT_TARGET_HOURS),
      ),
      policyWorkdays: r.policy?.expectedWorkdays ?? DEFAULT_POLICY_WORKDAYS,
      weeklyOffDay: r.policy?.weeklyOffDay ?? null,
      joinedOn: r.joinedOn,
      leftOn: r.leftOn,
    }));
  }
}

function groupBy<T>(rows: readonly T[], key: (row: T) => number): Map<number, T[]> {
  const map = new Map<number, T[]>();
  for (const row of rows) push(map, key(row), row);
  return map;
}

function push<T>(map: Map<number, T[]>, key: number, value: T): void {
  const existing = map.get(key);
  if (existing) existing.push(value);
  else map.set(key, [value]);
}

function sum(values: readonly number[]): number {
  return values.reduce((total, v) => total + v, 0);
}
