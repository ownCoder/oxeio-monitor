import { Injectable } from '@nestjs/common';
import { Prisma } from '@prisma/client';

import { PrismaService } from '../prisma/prisma.service';
import {
  DESIGN_APPS_SQL,
  DESIGN_ID_SQL_EXPR,
} from '../summary/design.rules';

/**
 * **ফাইলের চিহ্ন** *(৯ সেপ্টেম্বর ২০২৬)* — একটা জব-নম্বরের ফাইল
 * ডিজাইন-অ্যাপে মোট কতক্ষণ পর্দায় ছিল।
 *
 * ⚠️⚠️ **কেন এটা দরকার হলো।** টার্গেটের "শেষ" চিহ্নটা কর্মীর **নিজের
 * দাবি** — কেউ যাচাই করে না, আর সিস্টেম সেটা প্রশ্ন না করেই বোর্ডে তোলে।
 * ৮ সেপ্টেম্বরে একজনের ৩২টা "শেষ" নিয়ে প্রশ্ন উঠেছিল, আর উত্তর দিতে
 * ডাটাবেসে হাতে কোয়েরি লিখতে হয়েছিল — কারণ পর্দায় দাবিটা ছিল,
 * দাবির পাশে কিছু ছিল না।
 *
 * ⭐⭐ নতুন কোনো ডেটা জমা করতে হয়নি: এজেন্ট শিরোনাম **আগে থেকেই** রাখে,
 * আর ফাইলের নাম শুরু হয় জব-নম্বর দিয়ে। অর্থাৎ প্রশ্নটার উত্তর ইতিমধ্যেই
 * টেবিলে ছিল, কেউ জিজ্ঞেস করত না।
 *
 * ⚠️⚠️ **এটা "কাজ হয়েছে কি না" মাপে না।** যা মাপে তা হলো *ওই নম্বরওয়ালা
 * একটা ফাইল Illustrator/Photoshop-এ খোলা ছিল কি না*। চিহ্ন না থাকার
 * নির্দোষ কারণ অনেক — ফাইলটা সেভ করা হয়নি (`Untitled-20*`), নামের সামনে
 * নম্বর বসানো হয়নি, বা কাজটা অন্য কোনো অ্যাপে হয়েছে। ⭐ তাই সংখ্যাটা
 * **অভিযোগ নয়, প্রসঙ্গ** — আর সেজন্যই এর কোনো অ্যালার্ট নেই।
 */
@Injectable()
export class FileTraceService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * ⭐⭐ **কোন দিন থেকে শিরোনাম জমা আছে** — `'YYYY-MM-DD'`, কিছু না
   * থাকলে `null`।
   *
   * ⚠️⚠️ **এই তারিখটার আগের কোনো সারি নিয়ে "ফাইল খোলা হয়নি" বলা যায় না**,
   * কারণ তখন আমরা দেখতামই না। মাঠে `app_usage` শুরু হয়েছে ১৩ আগস্ট
   * ২০২৬-এ, অথচ শেষ-হওয়া টার্গেট আছে ২০২৫ সাল থেকে — ওই ২৭ হাজার সারি
   * "চিহ্ন নেই" বলে দেখানো হতো, আর তালিকাটা অর্থহীন হয়ে যেত।
   *
   * ⭐ তারিখটা **ডেটা থেকেই** আসে, ধ্রুবক নয় — কোনোদিন পুরোনো সারি ছাঁটা
   * শুরু হলে সীমানাটা নিজে থেকেই এগিয়ে যাবে, কারো মনে রাখতে হবে না।
   *
   * ### ⚠️ খরচ — মেপে রাখা *(৯ সেপ্টেম্বর ২০২৬)*
   *
   * `min(work_date)`-এর কোনো সূচক নেই, তাই এটা গোটা `app_usage`-এর উপর
   * সমান্তরাল seq scan: প্রোডাকশনে ১,৫৪,০০০ সারিতে **৩২–৫৪ ms**, আর
   * প্রতিবার তালিকা খুললেই একবার। টেবিলটা দিনে ~৭ হাজার সারি বাড়ে।
   *
   * ⚠️⚠️ **একটা ১০-মিনিটের ক্যাশ লেখা হয়েছিল, তারপর তুলে নেওয়া হয়** —
   * কারণ সার্ভিসটা টেস্টে **একটাই ইনস্ট্যান্স**, আর `resetDatabase()`
   * ওই ক্যাশ মোছে না; ফলে এক টেস্টের সীমানা পরের টেস্টে চলে যেত।
   * ⭐ আর যে ক্যাশ ঠিক রাখতে টেস্টকে খোঁচাতে হয়, সেটা প্রোডাকশনেও
   * ভুল হতে পারে — ৩২ ms-এর জন্য ওই লুকোনো অবস্থাটা কেনার মতো নয়।
   *
   * ⭐ কোনোদিন সত্যিই সমস্যা হলে ঠিক পথ দুটো, আর দুটোই লুকোনো অবস্থা
   * ছাড়া: `app_usage(work_date)`-এ একটা সূচক, নয়তো সংখ্যাটা
   * `summary_dirty`-র মতো একটা ছোট টেবিলে লিখে রাখা।
   */
  async since(): Promise<string | null> {
    const rows = await this.prisma.$queryRaw<{ d: string | null }[]>`
      SELECT min(work_date)::text AS d FROM app_usage`;

    return rows[0]?.d ?? null;
  }

  /**
   * ⭐⭐⭐ **শেষ বলা হয়েছে, অথচ ওই নম্বরের ফাইল কোনোদিন খোলা হয়নি** —
   * `from`-এর পর থেকে, জব-নম্বরের তালিকা।
   *
   * ⚠️⚠️ **প্রশ্নটা `design_targets` থেকে জিজ্ঞেস করা হয়, `app_usage`
   * থেকে নয় — আর এই দিকটাই গোটা খরচের পার্থক্য** *(৯ সেপ্টেম্বর ২০২৬,
   * প্রোডাকশনে মাপা)*।
   *
   * | কোন দিক থেকে | কী ঘটে | সময় |
   * |---|---|---|
   * | `app_usage` → সব নম্বর, তারপর `NOT IN` | ১৪,২২৫ সারিতে regex **আবার** গোনা | **৯৩০ ms** |
   * | `design_targets` → প্রতিটার জন্য একটা প্রোব | ১,৮২১টা ইনডেক্স-লুকআপ, ৫µs করে | **২৫ ms** |
   *
   * ⭐ সূচকে হিসাবটা **আগে থেকেই বসানো**; প্রথম পথটা সেটা ব্যবহারই করত
   * না — সূচক দিয়ে কেবল সারিগুলো বেছে নিয়ে তারপর হিপ থেকে পড়ে regex
   * নতুন করে চালাত (`Bitmap Heap Scan`, ৩,৮৮৪ ব্লক)।
   *
   * ⚠️ ফেরত তালিকাটা `IN (…)` হয়ে Prisma-য় যায়। আজ **৪৭০**টা; ধীরে
   * বাড়বে (আর ফাইলের নাম দেওয়ার অভ্যাস ভালো হলে **কমবে**)। ৩০ হাজার
   * ছাড়ালে Postgres-এর প্যারামিটার-সীমা কাছে আসবে, আর তখন ছাঁকনি ও
   * পাতা-ভাগ দুটোই SQL-এ নামাতে হবে।
   *
   * ⚠️ ছয় অঙ্ক বা তার কম **এখানেও ধরা পড়ে**: `keepKnownLongIds` কেবল
   * ক্রেডিট বসানোর সময় লম্বা নম্বর ছাঁকে, আর এখানে মিলানো হচ্ছে
   * `design_targets.job_number`-এর সাথে — যা সংজ্ঞা অনুযায়ীই "জানা নম্বর"।
   */
  async unseenJobNumbers(from: Date): Promise<number[]> {
    /**
     * ⚠️ ভেতরের কোয়েরিতে `window_title`/`process_name` **যোগ্যতা ছাড়া**
     * লেখা — ঠিক যেভাবে `migration.sql`-এর সূচকে আছে। ভেতরের স্কোপ
     * আগে খোঁজা হয়, তাই ওগুলো `app_usage`-এরই কলাম।
     */
    const rows = await this.prisma.$queryRaw<{ job_number: number }[]>`
      SELECT t.job_number
      FROM design_targets t
      WHERE t.completed_at >= ${from}
        AND t.job_number IS NOT NULL
        AND NOT EXISTS (
          SELECT 1 FROM app_usage a
          WHERE ${Prisma.raw(DESIGN_APPS_SQL)}
            AND ${Prisma.raw(DESIGN_ID_SQL_EXPR)} = t.job_number::text
        )`;

    return rows.map((r) => r.job_number);
  }

  /**
   * ⭐ **এই নম্বরগুলোর প্রতিটায় মোট কত সেকেন্ড** — না পাওয়া নম্বর
   * ম্যাপে **থাকে না** (শূন্য বসে না; পার্থক্যটা কলার ঠিক করে)।
   *
   * ⚠️ কেবল পর্দায় থাকা পাতাটুকুর জন্য ডাকা হয় (৫০টা সারি), তাই
   * ইনডেক্স ধরে ৫০টা লুকআপ — গোটা টেবিল নয়।
   */
  async secondsFor(
    jobNumbers: readonly number[],
  ): Promise<Map<number, number>> {
    const out = new Map<number, number>();
    if (jobNumbers.length === 0) return out;

    const ids = jobNumbers.map((n) => String(n));

    const rows = await this.prisma.$queryRaw<{ did: string; sec: number }[]>`
      SELECT ${Prisma.raw(DESIGN_ID_SQL_EXPR)} AS did,
             sum(duration_sec)::int AS sec
      FROM app_usage
      WHERE ${Prisma.raw(DESIGN_APPS_SQL)}
        AND ${Prisma.raw(DESIGN_ID_SQL_EXPR)} IN (${Prisma.join(ids)})
      GROUP BY 1`;

    for (const r of rows) {
      const n = Number.parseInt(r.did, 10);
      if (Number.isSafeInteger(n)) out.set(n, r.sec);
    }

    return out;
  }
}
