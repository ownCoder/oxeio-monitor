import { Module } from '@nestjs/common';

import { AgentDownCheck } from './agent-down.check';
import { AgentTamperCheck } from './agent-tamper.check';
import { AlertsController } from './alerts.controller';
import { TelegramChannel } from './telegram.channel';
import { TelegramSettingsController } from './telegram.controller';
import { AlertDispatcher } from './alerts.dispatcher';
import { AlertMailer } from './alerts.mailer';
import { AlertsScheduler } from './alerts.scheduler';
import { AlertsService } from './alerts.service';
import { DeviceOverlapCheck } from './device-overlap.check';
import { SyntheticInputCheck } from './synthetic-input.check';
import { DiskCheck } from './disk.check';
import { NoActivityCheck } from './no-activity.check';

/**
 * G01–G07 — অ্যালার্ট।
 *
 * `AlertsService` export করা হয়েছে যাতে অন্য মডিউল (যেমন ব্যাকআপ জব → G04,
 * বা overlap সনাক্তকরণ → `device_overlap`) নিজেরা `prisma.alert.create()` না
 * লিখে এখান দিয়েই অ্যালার্ট বসায় — ⭐ throttle-টা তখন আপনাআপনি পেয়ে যায়।
 *
 * ⚠️ PrismaModule `@Global`, তাই এখানে আলাদা করে import করার দরকার নেই।
 */
@Module({
  controllers: [AlertsController, TelegramSettingsController],
  providers: [
    AlertsService,
    AlertMailer,
    // ⭐ কন্ট্রোলারের `test` রুটটা এটা ডাকে — ops-এর ইনস্ট্যান্স নয়,
    //    কারণ ওটা অন্য মডিউলে আর sweep চালায়
    TelegramChannel,
    AlertDispatcher,
    AgentDownCheck,
    AgentTamperCheck,
    DeviceOverlapCheck,
    SyntheticInputCheck,
    DiskCheck,
    NoActivityCheck,
    AlertsScheduler,
  ],
  exports: [AlertsService],
})
export class AlertsModule {}
