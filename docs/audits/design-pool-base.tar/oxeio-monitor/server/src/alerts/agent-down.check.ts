import { Injectable, Logger } from '@nestjs/common';

import { workDateOf } from '../agent/util/dhaka-time';
import { PrismaService } from '../prisma/prisma.service';
import { AGENT_SILENCE_MIN } from './alerts.constants';
import {
  agentDownCandidates,
  isAgentWatchOpen,
  recoveredAlertIds,
  silentMinutes,
  CLEAN_STOP_EVENTS,
  type DeviceSilence,
} from './alerts.rules';
import { AlertsService, type RaiseInput } from './alerts.service';

/** ⚠️ কত পুরোনো বিদায়ী ইভেন্ট পর্যন্ত দেখা হবে — কুয়েরিটা ছোট রাখার জন্য */
const STOP_LOOKBACK_DAYS = 7;

/**
 * G01 — কোনো এজেন্ট ১০ মিনিট ধরে চুপ (স্পেক § ৬.৪, প্রতি ৫ মিনিটে)।
 *
 * ⚠️ "চুপ" মানেই "সমস্যা" নয়। PC বন্ধ করে বাড়ি যাওয়াও চুপ। পার্থক্যটা
 *    alerts.rules.ts-এর `isExpectedSilence()` করে — বিস্তারিত কারণ ওখানে।
 */
@Injectable()
export class AgentDownCheck {
  private readonly logger = new Logger(AgentDownCheck.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly alerts: AlertsService,
  ) {}

  async runOnce(now = new Date()): Promise<number> {
    const silenceFloor = new Date(now.getTime() - AGENT_SILENCE_MIN * 60_000);

    const [devices, holiday, fallbackPolicy, leaves] = await Promise.all([
      this.prisma.device.findMany({
        where: {
          // ⚠️ revoke করা ডিভাইস বাদ — ওগুলোর চুপ থাকাটাই তো উদ্দেশ্য
          status: 'active',
          lastSeenAt: { not: null, lt: silenceFloor },
        },
        select: {
          id: true,
          hostname: true,
          lastSeenAt: true,
          employeeId: true,
          employee: {
            select: {
              fullName: true,
              policy: {
                select: {
                  officeFrom: true,
                  officeTo: true,
                  weeklyOffDay: true,
                },
              },
            },
          },
        },
      }),
      this.prisma.holiday.findUnique({
        where: { holidayDate: workDateOf(now) },
        select: { name: true },
      }),
      /**
       * ⚠️ যে ডিভাইস কোনো কর্মীর সাথে বাঁধা নয় (employeeId null) তার জন্য
       *    ফলব্যাক — নইলে ওই ডিভাইসগুলো অফিস-সময়ের নিয়মের বাইরে থেকে
       *    যেত, আর রাতেও অ্যালার্ট দিত।
       */
      this.prisma.workPolicy.findFirst({
        where: { isActive: true },
        select: { officeFrom: true, officeTo: true, weeklyOffDay: true },
      }),
      /**
       * ⭐⭐⭐ **আজ কে ছুটিতে** *(৬ সেপ্টেম্বর ২০২৬, G157)*।
       *
       * ⚠️⚠️ এই কোয়েরিটা **এক মাস ধরে অনুপস্থিত ছিল**। ছুটির খাতা এসেছে
       * R2/G130-তে, কিন্তু কোনো অ্যালার্ট-পরীক্ষা কোনোদিন `leaves` পড়েনি —
       * তাই মালিকের অনুমোদন করা ছুটির দিনেও *"এজেন্ট চুপ"* খবর যেত।
       * মাঠে: ৩টা ছুটির দিনে ১১টা মিথ্যা অ্যালার্ট, তার ৮টা এই ঘরানার।
       */
      this.prisma.leave.findMany({
        where: { leaveDate: workDateOf(now) },
        select: { employeeId: true },
      }),
    ]);

    if (devices.length === 0) return 0;

    /**
     * ⭐⭐ **অফিস বন্ধ থাকলে চুপ** *(২২ আগস্ট ২০২৬, মালিকের সিদ্ধান্ত)*।
     *
     * ⚠️ ছাঁকাটা এখানে, `agentDownCandidates()`-এর ভেতরে নয় — ওই ফাংশনের
     *    প্রশ্ন "এই নীরবতার ব্যাখ্যা আছে কি?", আর এটার প্রশ্ন "এই মুহূর্তে
     *    প্রশ্নটাই কি অর্থপূর্ণ?"। দুটো আলাদা, তাই আলাদাই থাকল।
     *
     * ⚠️⚠️ ডিভাইস **সরানো হয় না, শুধু অ্যালার্ট তোলা হয় না** — `lastSeenAt`
     *    আগের মতোই লেখা থাকে, তাই সকালে অফিস খুললে যে PC তখনো চুপ, তার
     *    জন্য অ্যালার্ট ঠিকই উঠবে।
     */
    /**
     * ⚠️⚠️ **ছুটিতে থাকা কর্মীর PC চুপ থাকাই স্বাভাবিক** — ছাঁকনিটা এখানে,
     * `isAgentWatchOpen()`-এ নয়। ⭐ ওই ফাংশনটা **অফিসের** প্রশ্নের উত্তর দেয়
     * (*"এখন কি কাজের সময়?"*), আর ছুটি **একজনের** ব্যাপার। দুটো এক জায়গায়
     * মিশিয়ে ফেললে একজনের ছুটি গোটা দলের পাহারা বন্ধ করে দিতে পারত।
     */
    const onLeave = new Set(leaves.map((l) => l.employeeId));

    const open = devices
      .filter((d) => d.employeeId === null || !onLeave.has(d.employeeId))
      .filter((d) =>
        isAgentWatchOpen({
          now,
          officeFrom:
            d.employee?.policy?.officeFrom ??
            fallbackPolicy?.officeFrom ??
            null,
          officeTo:
            d.employee?.policy?.officeTo ?? fallbackPolicy?.officeTo ?? null,
          weeklyOffDay:
            d.employee?.policy?.weeklyOffDay ??
            fallbackPolicy?.weeklyOffDay ??
            null,
          isHoliday: holiday !== null,
        }),
      );

    if (open.length === 0) {
      this.logger.debug(
        `${devices.length} devices silent, but nobody is expected yet — not raising`,
      );
      return 0;
    }

    const lastStops = await this.lastCleanStops(
      open.map((d) => d.id),
      now,
    );

    const silences: DeviceSilence[] = open.map((d) => ({
      deviceId: d.id,
      lastSeenAt: d.lastSeenAt,
      lastCleanStopAt: lastStops.get(d.id) ?? null,
    }));

    const down = new Set(
      agentDownCandidates(silences, now).map((s) => s.deviceId),
    );
    if (down.size === 0) return 0;

    const inputs: RaiseInput[] = open
      .filter((d) => down.has(d.id))
      .map((d) => {
        const minutes = silentMinutes(d.lastSeenAt, now) ?? 0;
        return {
          type: 'agent_down' as const,
          severity: 'warning' as const,
          deviceId: d.id,
          employeeId: d.employeeId,
          title: `Agent silent — ${d.hostname}`,
          detail:
            `${d.hostname}${d.employee ? ` (${d.employee.fullName})` : ''} ` +
            `has sent nothing for ${minutes} minutes, and no shutdown event arrived either. ` +
            'Check whether the PC is on, the network is working, and the agent is running.',
          meta: { silentMinutes: minutes, hostname: d.hostname },
        };
      });

    this.logger.warn(`${inputs.length} devices silent with no explanation`);
    return this.alerts.raiseMany(inputs, now);
  }

  /**
   * ⭐ ফিরে আসা এজেন্ট — খোলা agent_down alert নিজে বন্ধ করা।
   *
   * `runOnce`-এর **আয়না**: ওটা চুপ ডিভাইসে alert **তোলে**, এটা আবার-কথা-বলা
   * ডিভাইসের খোলা alert **বন্ধ** করে (`recoveredAlertIds`)। ফলে সকালে মালিক
   * শুধু এখন-সত্যিই-down PC দেখেন — রাতে বন্ধ হয়ে আবার চালু হওয়া বারোটা বাসি
   * warning নয়।
   *
   * ⚠️ ingest hot path (device-auth.guard) ছোঁয়া হয় না — একই `lastSeenAt`
   *    কলাম, একই শিডিউলার, প্রতি-রিকোয়েস্টে বাড়তি কোনো খরচ নেই।
   */
  async resolveReturned(now = new Date()): Promise<number> {
    const open = await this.prisma.alert.findMany({
      where: {
        type: 'agent_down',
        acknowledgedAt: null,
        resolvedAt: null,
        deviceId: { not: null },
      },
      select: {
        id: true,
        device: { select: { status: true, lastSeenAt: true } },
      },
    });
    if (open.length === 0) return 0;

    const ids = recoveredAlertIds(
      open.map((a) => ({
        alertId: a.id,
        deviceActive: a.device?.status === 'active',
        lastSeenAt: a.device?.lastSeenAt ?? null,
      })),
      now,
    );
    return this.alerts.resolveMany(ids, 'agent returned', now);
  }

  /**
   * প্রতিটা ডিভাইসের **সর্বশেষ বিদায়ী ইভেন্ট**।
   *
   * ⚠️ `groupBy` ব্যবহার করা হয়েছে, `findMany + distinct` নয় — Prisma-র
   *    `distinct` সব সারি টেনে এনে মেমোরিতে ছাঁকে, আর ইভেন্ট টেবিল দ্রুত
   *    বড় হয়। এখানে কাজটা ডাটাবেসেই `MAX(occurred_at)` দিয়ে হয়।
   */
  private async lastCleanStops(
    deviceIds: number[],
    now: Date,
  ): Promise<Map<number, Date>> {
    const rows = await this.prisma.event.groupBy({
      by: ['deviceId'],
      where: {
        deviceId: { in: deviceIds },
        type: { in: [...CLEAN_STOP_EVENTS] },
        occurredAt: {
          gte: new Date(now.getTime() - STOP_LOOKBACK_DAYS * 86_400_000),
        },
      },
      _max: { occurredAt: true },
    });

    const map = new Map<number, Date>();
    for (const row of rows) {
      if (row.deviceId !== null && row._max.occurredAt) {
        map.set(row.deviceId, row._max.occurredAt);
      }
    }
    return map;
  }
}
