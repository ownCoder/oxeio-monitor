using System.Globalization;
using System.Runtime.Versioning;

using oXeio.Core.Time;
using oXeio.Core.Watchdog;
using oXeio.Watchdog.Native;
using oXeio.Watchdog.Platform;

namespace oXeio.Watchdog;

/// <summary>
/// ⭐ ৩০ সেকেন্ডের লুপ — দেখা, সিদ্ধান্ত, কাজ।
///
/// সিদ্ধান্তের সব যুক্তি <see cref="WatchdogPolicy"/> আর <see cref="RestartLadder"/>-এ,
/// অর্থাৎ Windows ছাড়াই টেস্ট করা যায়। এখানে শুধু বাইরের দুনিয়া পড়া আর
/// সিদ্ধান্ত কার্যকর করা।
///
/// ⚠️ এই লুপ থেকে কোনো এক্সসেপশন বেরোতে পারবে না। পাহারাদার মরে গেলে কেউ আর
/// কাউকে তোলে না, আর সেটা টের পাওয়া যায় সার্ভারে দশ মিনিট চুপ থাকার পর —
/// যদি কেউ অ্যালার্ট পড়ে।
/// </summary>
[SupportedOSPlatform("windows")]
internal sealed class WatchdogLoop
{
    /// <summary>kill করার পর প্রসেসটাকে মরার জন্য কতটা সময় দেওয়া হয়।</summary>
    private static readonly TimeSpan KillGrace = TimeSpan.FromSeconds(10);

    /// <summary>কিছু না বদলালেও এতক্ষণ পরপর একটা করে লাইন — লগ যেন "মৃত" না লাগে।</summary>
    private static readonly TimeSpan HeartbeatLogEvery = TimeSpan.FromHours(1);

    private readonly AgentPaths _paths;
    private readonly RollingLog _log;
    private readonly string? _agentExeOverride;

    private readonly RestartLadder _ladder = new();
    private readonly HeartbeatReader _heartbeat = new();

    // ⚠️ MonotonicClock, DateTimeOffset.Now নয়। কেউ PC-র ঘড়ি পিছিয়ে দিলে
    //    ঠান্ডা হওয়ার সময় কোনোদিন শেষ হতো না, আর watchdog নীরবে অকেজো
    //    হয়ে বসে থাকত — লগে সব স্বাভাবিক দেখিয়ে।
    private readonly MonotonicClock _clock = MonotonicClock.StartNow();

    private (WatchdogAction Action, WatchdogReason Reason, AgentHealth Health) _lastLogged;
    private DateTimeOffset _lastLogAt = DateTimeOffset.MinValue;
    private bool _alarmOnDisk;

    public WatchdogLoop(AgentPaths paths, RollingLog log, string? agentExeOverride)
    {
        _paths = paths;
        _log = log;
        _agentExeOverride = agentExeOverride;
    }

    public void Run(WaitHandle stop, TimeSpan period)
    {
        _log.Write($"Watch started — every {period.TotalSeconds:F0} seconds, data folder {_paths.DataDirectory}");
        _alarmOnDisk = File.Exists(_paths.Alarm);

        do
        {
            try
            {
                Tick();
            }
            catch (Exception ex)
            {
                // এখানে পৌঁছানোর কথা নয় — নিচের প্রতিটা ধাপ নিজেই ধরে। তবু
                // এই catch-টাই শেষ ভরসা: একটা অপ্রত্যাশিত বাগ যেন পাহারাদারকে
                // চিরতরে থামিয়ে না দেয়।
                _log.Write($"❌ Unexpected error in the tick: {ex.GetType().Name} — {ex.Message}");
            }

            // থামার অনুরোধ এলে সাথে সাথেই বেরোনো যায় — Sleep হলে ৩০ সেকেন্ড
            // অপেক্ষা করতে হতো, আর শাটডাউনে Windows ততক্ষণ অপেক্ষা করে না।
        } while (!stop.WaitOne(period) && !StopRequested());

        _log.Write("Watch stopped");
    }

    // ── এক টিক ──────────────────────────────────────────────────────────────

    private void Tick()
    {
        var now = _clock.Now;
        var observation = Observe();

        if (observation is null)
        {
            // ঘড়িই পড়া গেল না — এই টিকে কোনো সিদ্ধান্ত নেওয়া নিরাপদ নয়।
            LogIfChanged(WatchdogAction.Hold, WatchdogReason.ProbeFailed, AgentHealth.Unknown,
                "Could not read the unbiased clock — skipping this tick", now);
            return;
        }

        var decision = WatchdogPolicy.Decide(observation, _ladder, now);
        LogIfChanged(decision.Action, decision.Reason, decision.Health, Describe(decision), now);

        switch (decision.Action)
        {
            case WatchdogAction.None:
                if (_alarmOnDisk && !_ladder.AlarmRaised)
                {
                    AlarmFile.Clear(_paths.Alarm);
                    _alarmOnDisk = false;
                    _log.Write("✅ The agent is running steadily again — the alarm was cleared");
                }
                break;

            case WatchdogAction.GiveUp:
                AlarmFile.Raise(
                    _paths.Alarm,
                    $"The agent did not survive {_ladder.Failures} launches " +
                    $"({Describe(decision.Reason)}). Next attempt in ~{_ladder.Policy.CoolOff.TotalHours:F0} hours.");
                _alarmOnDisk = true;
                _ladder.MarkAlarmRaised();
                _log.Write("🔴 Giving up — watchdog.alarm was written, waiting for the cool-off");
                break;

            case WatchdogAction.Restart:
                Restart(decision.KillProcessId, now);
                break;

            case WatchdogAction.Start:
                Start(now);
                break;

            case WatchdogAction.Hold:
            default:
                break;
        }
    }

    /// <summary>বাইরের দুনিয়া থেকে এক টিকের সব তথ্য। ঘড়ি পড়া না গেলে null।</summary>
    private AgentObservation? Observe()
    {
        if (Kernel32.UnbiasedMs() is not { } nowUnbiased) return null;

        var session = SessionCheck.Check();
        var lockState = InstanceLock.Probe(_paths.AgentLock);
        var beat = _heartbeat.Read(_paths.Heartbeat);

        return new AgentObservation
        {
            ProbeSucceeded = lockState != LockProbe.Unknown,
            InstanceLockHeld = lockState == LockProbe.Held,
            ProcessId = beat?.ProcessId,
            ProcessAlive = beat is not null && AgentProcess.IsAlive(beat.ProcessId),
            HeartbeatUnbiasedMs = beat?.UnbiasedMs,
            NowUnbiasedMs = nowUnbiased,
            SessionUsable = session.CanSupervise,
            ShuttingDown = User32.IsShuttingDown(),
        };
    }

    // ── কাজ ─────────────────────────────────────────────────────────────────

    private void Restart(int? pid, DateTimeOffset now)
    {
        if (pid is not { } victim)
        {
            _log.Write("⚠️ The agent is wedged, but the pid is unknown — nothing was done");
            return;
        }

        _log.Write($"⛔ The agent is wedged (heartbeat older than {AgentLiveness.StaleAfter.TotalSeconds:F0} s) — killing it");

        if (!AgentProcess.TryKill(victim, KillGrace, out var killDetail))
        {
            // ⚠️ ব্যর্থ kill-ও মইয়ের একটা ধাপ খরচ করে। না করলে watchdog প্রতি
            //    ৩০ সেকেন্ডে চিরকাল একটা না-মরা প্রসেসকে মারতে চেষ্টা করে যেত,
            //    কোনো অ্যালার্ম না তুলেই — অর্থাৎ সমস্যাটা চিরকাল অদৃশ্য থাকত।
            _ladder.RecordLaunch(now);
            _log.Write($"⚠️ {killDetail} (attempt {_ladder.Failures}/{_ladder.Policy.GiveUpAfter})");
            return;
        }

        _log.Write($"   {killDetail}");

        // ⚠️ মরতে থাকা প্রসেস কয়েক মিলিসেকেন্ড agent.lock ধরে রাখতে পারে।
        //    সাথে সাথে চালু করলে নতুন এজেন্ট লক না পেয়ে বেরিয়ে যেত, আর মই
        //    সেটাকে ব্যর্থতা হিসেবে গুনত। লক খালি হয়েছে দেখেই কেবল এগোনো।
        if (InstanceLock.Probe(_paths.AgentLock) != LockProbe.Free)
        {
            _log.Write("   The lock has not been released yet — it will be started on the next tick");
            return;
        }

        Start(now);
    }

    private void Start(DateTimeOffset now)
    {
        var exe = AgentPaths.ResolveAgentExecutable(_agentExeOverride);

        // ⚠️ মই <b>আগে</b> এগোনো হয়, চালু করার আগে। exe নেই বা AV ব্লক করেছে —
        //    এসব ক্ষেত্রে পরে গুনলে গোনা কখনো বাড়ত না আর লুপটা প্রতি ৩০ সেকেন্ডে
        //    চিরকাল চেষ্টা করে যেত। ঠিক যে ঝড়টা ঠেকানোর কথা।
        _ladder.RecordLaunch(now);

        if (exe is null)
        {
            _log.Write($"❌ {AgentPaths.AgentExeName} was not found ({AppContext.BaseDirectory}) — " +
                       $"attempt {_ladder.Failures}/{_ladder.Policy.GiveUpAfter}");
            return;
        }

        var ok = AgentProcess.TryStart(exe, out _, out var detail);

        _log.Write($"{(ok ? "▶" : "❌")} Agent start: {detail} " +
                   $"(attempt {_ladder.Failures}/{_ladder.Policy.GiveUpAfter}, " +
                   $"next one in {_ladder.TimeUntilNextLaunch(now).TotalSeconds:F0} s)");
    }

    // ── থামার অনুরোধ ────────────────────────────────────────────────────────

    /// <summary>
    /// ইনস্টলার/আনইনস্টলার <c>watchdog.stop</c> ফাইল বানিয়ে ভদ্রভাবে থামাতে পারে।
    ///
    /// নামযুক্ত event ব্যবহার করা যেত না: SYSTEM হিসেবে চলা ইনস্টলার আর ইউজার
    /// সেশনে চলা watchdog আলাদা namespace-এ থাকে, আর <c>Global\</c> নাম
    /// তৈরি করতে স্ট্যান্ডার্ড ইউজারের privilege নেই।
    /// </summary>
    private bool StopRequested()
    {
        try
        {
            if (!File.Exists(_paths.StopFile)) return false;

            _log.Write("🛑 watchdog.stop found — stopping");
            File.Delete(_paths.StopFile);
            return true;
        }
        catch (Exception)
        {
            // মুছতে না পারলেও থামা হচ্ছে — নইলে ফাইলটা রয়ে গিয়ে প্রতিবার
            // চালু হওয়ার সাথে সাথেই থামাত।
            return true;
        }
    }

    // ── লগ ──────────────────────────────────────────────────────────────────

    /// <summary>
    /// শুধু <b>বদল</b> লেখা হয়। প্রতি টিকে লিখলে দিনে ২,৮৮০টা লাইন হতো,
    /// লগ দিনে দুবার ঘুরত, আর দুই সপ্তাহ আগের যে ক্র্যাশটা খুঁজতে অ্যাডমিন
    /// লগ খুলেছেন সেটাই মুছে যেত।
    /// </summary>
    private void LogIfChanged(
        WatchdogAction action, WatchdogReason reason, AgentHealth health, string message, DateTimeOffset now)
    {
        var key = (action, reason, health);
        var stale = now - _lastLogAt >= HeartbeatLogEvery;

        if (key == _lastLogged && !stale) return;

        _lastLogged = key;
        _lastLogAt = now;
        _log.Write(message);
    }

    private static string Describe(WatchdogDecision decision)
    {
        var retry = decision.RetryIn is { } left && left > TimeSpan.Zero
            ? $" ({left.TotalSeconds:F0} s left)"
            : string.Empty;

        return string.Create(
            CultureInfo.InvariantCulture,
            $"{Symbol(decision.Health)} {Describe(decision.Health)} — {Describe(decision.Reason)}{retry}");
    }

    private static string Symbol(AgentHealth health) => health switch
    {
        AgentHealth.Healthy => "✅",
        AgentHealth.NotRunning => "⛔",
        AgentHealth.Wedged => "🧊",
        AgentHealth.Unreachable => "❓",
        _ => "❓",
    };

    private static string Describe(AgentHealth health) => health switch
    {
        AgentHealth.Healthy => "the agent is healthy",
        AgentHealth.NotRunning => "the agent is not running",
        AgentHealth.Wedged => "the agent is wedged",
        AgentHealth.Unreachable => "the agent is there but out of reach",
        _ => "the state is unknown",
    };

    private static string Describe(WatchdogReason reason) => reason switch
    {
        WatchdogReason.Healthy => "the heartbeat is fresh",
        WatchdogReason.AgentMissing => "nobody is holding agent.lock",
        WatchdogReason.HeartbeatStale => "the heartbeat has stopped",
        WatchdogReason.ForeignInstance => "the lock is held but the process is unknown",
        WatchdogReason.BackoffPending => "backoff in progress",
        WatchdogReason.CoolOffPending => "gave up, cooling off",
        WatchdogReason.CoolOffProbe => "one attempt after the cool-off",
        WatchdogReason.LadderExhausted => "the agent did not survive repeated attempts",
        WatchdogReason.ShuttingDown => "Windows is shutting down",
        WatchdogReason.SessionNotUsable => "the agent cannot be started from this session",
        WatchdogReason.ProbeFailed => "the lock file could not be read at all",
        _ => reason.ToString(),
    };
}
